"use client";

import { useEffect, useState, type CSSProperties } from "react";
import type { Airline, MediaAsset } from "@/types/volantis";

function useResolvedAirlineLogo(airline: Airline): MediaAsset | null {
  const [asset, setAsset] = useState<MediaAsset | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch(`/api/media/cache?kind=airline-logo&code=${encodeURIComponent(airline.iata)}`, { cache: "force-cache" });
        if (!res.ok) return;
        const data = (await res.json()) as { found?: boolean; asset?: MediaAsset };
        if (!cancelled && data.found && data.asset) {
          setAsset(data.asset);
        }
        if (!cancelled && !(data.found && data.asset)) {
          // try live acquisition (cached)
          const live = await fetch(`/api/media/airline-logo/${encodeURIComponent(airline.iata)}`);
          if (live.ok) {
            const liveData = (await live.json()) as { asset?: MediaAsset };
            if (!cancelled && liveData.asset?.commercialUse) {
              setAsset(liveData.asset);
            }
          }
        }
      } catch {
        /* stay with fallback */
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [airline.iata]);

  return asset;
}

export function AirlineLogo({ airline, size = "md" }: { airline: Airline; size?: "sm" | "md" | "lg" }) {
  const resolved = useResolvedAirlineLogo(airline);

  const dimensions = {
    sm: "h-9 w-9 text-xs",
    md: "h-12 w-12 text-sm",
    lg: "h-16 w-16 text-base",
  }[size];
  const style = {
    "--logo-primary": airline.brandColors.primary,
    "--logo-secondary": airline.brandColors.secondary ?? "#111827",
  } as CSSProperties;

  if (resolved) {
    return (
      <div
        className={`${dimensions} relative grid shrink-0 place-items-center overflow-hidden rounded-2xl border border-white/15 bg-white/95 p-1.5 shadow-[0_18px_40px_rgba(0,0,0,0.35)]`}
        style={style}
        title={`${airline.name} · real logo · ${resolved.license}`}
        aria-label={`${airline.name} logo`}
      >
        {/* Next.js <Image> avoided because the URL set is dynamic and runtime-resolved across many remote sources */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={resolved.thumbnailUrl ?? resolved.url} alt={`${airline.name} logo`} className="h-full w-full object-contain" />
      </div>
    );
  }

  return (
    <div
      className={`${dimensions} relative grid shrink-0 place-items-center overflow-hidden rounded-2xl border border-white/10 bg-[linear-gradient(135deg,var(--logo-primary),var(--logo-secondary))] font-black tracking-[-0.04em] text-white shadow-[0_18px_40px_rgba(0,0,0,0.35)]`}
      style={style}
      title={`${airline.name} (${airline.iata}/${airline.icao})`}
      aria-label={`${airline.name} logo`}
    >
      <span className="absolute -right-4 -top-4 h-10 w-10 rounded-full bg-white/20 blur-sm" />
      <span className="relative z-10">{airline.logo.label}</span>
    </div>
  );
}
