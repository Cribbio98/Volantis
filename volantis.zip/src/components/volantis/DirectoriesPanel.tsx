import { AirlineLogo } from "@/components/volantis/AirlineLogo";
import { formatDistance } from "@/lib/formatters";
import { getAircraftFleetDirectory } from "@/services/aircraftService";
import { getAirlineDirectory } from "@/services/airlineService";
import type { Flight } from "@/types/volantis";

export async function DirectoriesPanel({ flights }: { flights: Flight[] }) {
  const airlines = (await getAirlineDirectory(flights)).slice(0, 5);
  const aircraft = getAircraftFleetDirectory(flights).slice(0, 5);

  return (
    <section className="grid gap-4 md:grid-cols-2">
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Airline directory</h2>
          <span className="text-xs uppercase tracking-[0.18em] text-white/40">Real data</span>
        </div>
        <div className="mt-4 space-y-3">
          {airlines.map((airline) => (
            <div key={airline.iata} className="flex items-center gap-3 rounded-2xl bg-black/25 p-3">
              <AirlineLogo airline={airline} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-white">{airline.name}</p>
                <p className="text-xs text-white/45">{airline.iata} · {airline.icao} · {airline.alliance} {airline.countryFlag ? airline.countryFlag : ""}</p>
              </div>
              <span className="rounded-full bg-white/10 px-2 py-1 text-xs font-bold text-white/70">{airline.userFlightCount}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Aircraft fleet</h2>
          <span className="text-xs uppercase tracking-[0.18em] text-white/40">Model directory</span>
        </div>
        <div className="mt-4 space-y-3">
          {aircraft.map((item) => (
            <div key={item.model} className="rounded-2xl bg-black/25 p-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-white">{item.model}</p>
                  <p className="text-xs text-white/45">{item.manufacturer} · {item.typicalSeats} seats</p>
                </div>
                <span className="rounded-full bg-[#FACC15]/15 px-2 py-1 text-xs font-bold text-[#FACC15]">{item.userFlightCount}</span>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-[0.68rem] text-white/55">
                <span>{item.typicalCruiseKt} kt</span>
                <span>{formatDistance(item.rangeKm)} range</span>
                <span>{item.ceilingFt.toLocaleString("en")} ft</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
