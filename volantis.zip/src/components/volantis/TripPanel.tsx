import { formatDistance, formatDuration } from "@/lib/formatters";
import { getTrips } from "@/services/tripService";

export function TripPanel() {
  const trips = getTrips();

  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Trips / journeys</h2>
        <span className="text-xs uppercase tracking-[0.18em] text-white/40">Multi-leg ready</span>
      </div>
      <div className="mt-4 space-y-3">
        {trips.map((trip) => (
          <div key={trip.id} className="rounded-2xl bg-black/25 p-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-semibold text-white">{trip.name}</p>
                <p className="text-sm text-white/45">{trip.origin.iata} → {trip.destination.iata} · {trip.flights.length} leg</p>
              </div>
              <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-bold text-white/65">{formatDuration(trip.totalDurationMinutes)}</span>
            </div>
            <p className="mt-3 text-xs text-white/45">{formatDistance(trip.totalDistanceKm)} total journey distance</p>
          </div>
        ))}
      </div>
    </section>
  );
}
