import { formatTime } from "@/lib/formatters";
import type { Flight } from "@/types/volantis";

export function FlightTimeline({ flight }: { flight: Flight }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Flight timeline</h2>
        <span className="text-xs uppercase tracking-[0.18em] text-white/40">Operational flow</span>
      </div>
      <div className="space-y-3">
        {flight.timeline.map((event) => (
          <div key={`${event.label}-${event.at}`} className="grid grid-cols-[auto_1fr_auto] items-center gap-3">
            <span
              className={`h-3 w-3 rounded-full ${
                event.state === "active" ? "animate-pulse bg-[#FACC15] shadow-[0_0_18px_rgba(250,204,21,0.7)]" : event.state === "complete" ? "bg-emerald-300" : "bg-white/20"
              }`}
            />
            <div>
              <p className="text-sm font-semibold text-white">{event.label}</p>
              {event.detail ? <p className="text-xs text-white/45">{event.detail}</p> : null}
            </div>
            <p className="text-xs font-semibold text-white/55">{formatTime(event.at)}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
