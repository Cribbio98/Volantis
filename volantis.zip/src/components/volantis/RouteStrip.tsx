import type { Flight } from "@/types/volantis";

export function RouteStrip({ flight, emphasis = false }: { flight: Flight; emphasis?: boolean }) {
  return (
    <div className="relative py-4">
      <div className="absolute left-3 right-3 top-1/2 h-px -translate-y-1/2 bg-white/15" />
      <div
        className="absolute left-3 top-1/2 h-0.5 -translate-y-1/2 bg-[#FACC15] shadow-[0_0_18px_rgba(250,204,21,0.55)]"
        style={{ width: `${Math.max(8, Math.min(96, flight.progressPercent))}%` }}
      />
      <div className="relative flex items-center justify-between">
        <div className="grid h-6 w-6 place-items-center rounded-full border border-[#FACC15]/50 bg-[#FACC15]/20">
          <span className="h-2 w-2 rounded-full bg-[#FACC15]" />
        </div>
        <div className={`${emphasis ? "text-lg" : "text-sm"} rounded-full border border-white/10 bg-black/50 px-3 py-1 font-black tracking-[0.22em] text-[#FACC15]`}>
          {flight.origin.iata} → {flight.destination.iata}
        </div>
        <div className="grid h-6 w-6 place-items-center rounded-full border border-white/25 bg-white/10">
          <span className="h-2 w-2 rounded-full bg-white/70" />
        </div>
      </div>
    </div>
  );
}
