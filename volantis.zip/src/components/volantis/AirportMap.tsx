"use client";

import { useEffect, useRef } from "react";
import { createVolantisMapStyle } from "@/services/map/mapService";
import type { Airport } from "@/types/volantis";

export function AirportMap({ airport }: { airport: Airport }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<{ remove: () => void } | null>(null);

  useEffect(() => {
    let disposed = false;

    async function boot() {
      if (!containerRef.current || disposed) return;
      const maplibre = await import("maplibre-gl");
      const style = createVolantisMapStyle() as ConstructorParameters<typeof maplibre.Map>[0]["style"];
      const map = new maplibre.Map({
        container: containerRef.current,
        style,
        center: [airport.longitude, airport.latitude],
        zoom: 9,
        pitch: 52,
        bearing: -15,
      });
      mapRef.current = map;

      map.on("load", () => {
        const markerElement = document.createElement("div");
        markerElement.className = "volantis-airport-marker";
        markerElement.innerHTML = `<span>AIRPORT</span><strong>${airport.iata}</strong>`;
        new maplibre.Marker({ element: markerElement, anchor: "bottom" })
          .setLngLat([airport.longitude, airport.latitude])
          .addTo(map);
      });
    }

    void boot();

    return () => {
      disposed = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, [airport.iata, airport.latitude, airport.longitude]);

  return (
    <section className="overflow-hidden rounded-[2rem] border border-white/10 bg-[#02040a] shadow-[0_30px_90px_rgba(0,0,0,0.45)]">
      <div className="flex items-center justify-between px-5 pt-4">
        <h2 className="text-lg font-bold text-white">Geographic view</h2>
        <span className="text-[0.62rem] uppercase tracking-[0.16em] text-white/35">Embedded MapLibre globe</span>
      </div>
      <div ref={containerRef} className="mt-3 h-72 w-full bg-[radial-gradient(circle_at_50%_35%,rgba(30,64,175,0.35),rgba(2,6,23,0.98)_58%)]" />
    </section>
  );
}
