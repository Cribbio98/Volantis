import Link from "next/link";
import { AirlineLogo } from "@/components/volantis/AirlineLogo";
import { DataSourceBadge } from "@/components/volantis/DataSourceBadge";
import { RouteStrip } from "@/components/volantis/RouteStrip";
import { countdownTo, formatTime, statusLabel } from "@/lib/formatters";
import type { Flight } from "@/types/volantis";

export function FlightCard({ flight }: { flight: Flight }) {
  const active = ["EnRoute", "Departed", "Approaching"].includes(flight.status);

  return (
    <Link
      href={`/flights/${encodeURIComponent(flight.flightNumber)}`}
      className="group block rounded-[2rem] border border-white/10 bg-white/[0.055] p-4 shadow-[0_16px_50px_rgba(0,0,0,0.28)] backdrop-blur-xl transition hover:border-[#FACC15]/45 hover:bg-white/[0.08]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <AirlineLogo airline={flight.airline} size="sm" />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{flight.airline.name}</p>
            <p className="text-xs uppercase tracking-[0.16em] text-white/45">{flight.flightNumber}</p>
          </div>
        </div>
        <DataSourceBadge source={flight.dataSource} compact />
      </div>

      <RouteStrip flight={flight} />

      <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-3">
        <div>
          <p className="text-3xl font-black tracking-[-0.05em] text-white">{flight.origin.iata}</p>
          <p className="truncate text-xs text-white/50">{flight.origin.city}</p>
          <p className="mt-1 text-sm font-semibold text-white/80">{formatTime(flight.estimatedDeparture ?? flight.scheduledDeparture)}</p>
        </div>
        <div className="rounded-full border border-white/10 bg-black/30 px-2.5 py-1 text-[0.64rem] font-bold uppercase tracking-[0.18em] text-white/55">
          {active ? `${flight.progressPercent}%` : countdownTo(flight.scheduledDeparture)}
        </div>
        <div className="text-right">
          <p className="text-3xl font-black tracking-[-0.05em] text-white">{flight.destination.iata}</p>
          <p className="truncate text-xs text-white/50">{flight.destination.city}</p>
          <p className="mt-1 text-sm font-semibold text-white/80">{formatTime(flight.estimatedArrival ?? flight.scheduledArrival)}</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-white/40">Status</p>
          <p className="mt-1 font-semibold text-[#FACC15]">{statusLabel(flight.status)}</p>
        </div>
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-white/40">Gate</p>
          <p className="mt-1 font-semibold text-white">{flight.terminal ? `T${flight.terminal}` : "—"} {flight.gate ?? ""}</p>
        </div>
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-white/40">Aircraft</p>
          <p className="mt-1 truncate font-semibold text-white">{flight.aircraft.type}</p>
        </div>
      </div>
    </Link>
  );
}
