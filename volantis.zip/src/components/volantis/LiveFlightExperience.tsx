"use client";

import { useEffect, useRef, useState } from "react";
import { FlightMap } from "@/components/volantis/FlightMap";
import type { Flight } from "@/types/volantis";

type FlightApiResponse = {
  ok: boolean;
  flight?: Flight;
};

export function LiveFlightExperience({ initialFlight, pollMs = 30_000 }: { initialFlight: Flight; pollMs?: number }) {
  const [flight, setFlight] = useState(initialFlight);
  const [connectionState, setConnectionState] = useState<"online" | "refreshing" | "offline">("online");
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    let stopped = false;

    async function refresh() {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      try {
        setConnectionState("refreshing");
        const response = await fetch(`/api/flights?flightNumber=${encodeURIComponent(initialFlight.flightNumber)}`, {
          cache: "no-store",
          signal: controller.signal,
        });
        if (!response.ok) {
          throw new Error(`Flight refresh failed: ${response.status}`);
        }
        const payload = (await response.json()) as FlightApiResponse;
        if (!stopped && payload.ok && payload.flight) {
          setFlight(payload.flight);
          setConnectionState("online");
        }
      } catch (error) {
        if (!stopped && !(error instanceof DOMException && error.name === "AbortError")) {
          setConnectionState("offline");
        }
      }
    }

    const timeout = window.setTimeout(refresh, 2400);
    const interval = window.setInterval(refresh, pollMs);

    return () => {
      stopped = true;
      window.clearTimeout(timeout);
      window.clearInterval(interval);
      abortRef.current?.abort();
    };
  }, [initialFlight.flightNumber, pollMs]);

  return (
    <div className="space-y-3">
      <FlightMap flight={flight} connectionState={connectionState} />
      <div className="flex items-center justify-between gap-3 px-1 text-[0.68rem] uppercase tracking-[0.16em] text-white/38">
        <span>Auto-refresh {Math.round(pollMs / 1000)}s</span>
        <span>{flight.dataSource === "LIVE_DATA" ? "Authoritative coordinates" : "Transparent non-live state"}</span>
      </div>
    </div>
  );
}
