import { DataSourceBadge } from "@/components/volantis/DataSourceBadge";
import type { DataSourceState } from "@/types/volantis";

export function AppHeader({ source, offline }: { source: DataSourceState; offline: boolean }) {
  return (
    <header className="sticky top-0 z-30 -mx-4 border-b border-white/10 bg-[#04070f]/80 px-4 py-4 backdrop-blur-2xl sm:-mx-6 sm:px-6">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
        <div>
          <p className="text-[0.62rem] font-black uppercase tracking-[0.32em] text-[#FACC15]">Volantis</p>
          <h1 className="text-xl font-black tracking-[-0.06em] text-white">Flight command</h1>
        </div>
        <div className="flex items-center gap-2">
          {offline ? <span className="rounded-full border border-orange-300/30 bg-orange-300/10 px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-orange-100">Offline</span> : null}
          <DataSourceBadge source={source} compact />
        </div>
      </div>
    </header>
  );
}
