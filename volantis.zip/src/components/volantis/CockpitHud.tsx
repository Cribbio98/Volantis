"use client";

import { useMemo, useState } from "react";
import { DataSourceBadge } from "@/components/volantis/DataSourceBadge";
import { formatAltitude, formatDateTime, formatDistance, formatHeading, formatSpeed, statusLabel } from "@/lib/formatters";
import { getAircraftTelemetrySnapshot } from "@/services/flightTelemetryService";
import { resolveAircraftPosition } from "@/lib/geo";
import type { Flight } from "@/types/volantis";

export function CockpitHud({ flight, connectionState }: { flight: Flight; connectionState: "online" | "refreshing" | "offline" }) {
  const [expanded, setExpanded] = useState(false);
  const telemetry = useMemo(() => getAircraftTelemetrySnapshot(flight), [flight]);
  const positionResolution = useMemo(() => resolveAircraftPosition(flight), [flight]);

  return (
    <div className="absolute inset-x-3 bottom-3 z-20 rounded-[1.5rem] border border-white/10 bg-[#04070f]/78 p-3 text-white shadow-[0_24px_80px_rgba(0,0,0,0.55)] backdrop-blur-2xl">
      <button type="button" onClick={() => setExpanded((value) => !value)} className="flex w-full items-center justify-between gap-3 text-left">
        <div className="flex min-w-0 items-center gap-2">
          <DataSourceBadge source={telemetry.source} compact />
          <span className="truncate text-xs font-semibold text-white/60">{statusLabel(flight.status)} · {telemetry.progressPercent}% complete</span>
        </div>
        <span className="rounded-full border border-white/10 px-2 py-1 text-[0.6rem] font-bold uppercase tracking-[0.12em] text-white/55">
          {connectionState === "refreshing" ? "Updating" : connectionState}
        </span>
      </button>

      <div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs">
        <div className="rounded-2xl bg-white/[0.06] p-2">
          <p className="text-white/35">Remain</p>
          <p className="mt-1 font-black text-white">{formatDistance(telemetry.remainingDistanceKm)}</p>
        </div>
        <div className="rounded-2xl bg-white/[0.06] p-2">
          <p className="text-white/35">ETA</p>
          <p className="mt-1 font-black text-white">{formatDateTime(telemetry.eta).split(" · ").pop()}</p>
        </div>
        <div className="rounded-2xl bg-white/[0.06] p-2">
          <p className="text-white/35">Alt</p>
          <p className="mt-1 font-black text-white">{formatAltitude(telemetry.altitudeFt)}</p>
        </div>
        <div className="rounded-2xl bg-white/[0.06] p-2">
          <p className="text-white/35">HDG</p>
          <p className="mt-1 font-black text-white">{formatHeading(telemetry.headingDeg)}</p>
        </div>
      </div>

      {positionResolution.lastPositionUpdate ? (
        <p className="mt-2 text-center text-[0.62rem] text-white/35">Last position update: {formatDateTime(positionResolution.lastPositionUpdate)}</p>
      ) : (
        <p className="mt-2 text-center text-[0.62rem] text-orange-200/60">No live position update received</p>
      )}

      {expanded ? (
        <div className="mt-3 grid gap-2 border-t border-white/10 pt-3 text-xs text-white/58">
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-2xl bg-black/30 p-3">
              <p className="text-white/35">Ground speed</p>
              <p className="mt-1 font-semibold text-white">{formatSpeed(telemetry.groundSpeedKt)}</p>
            </div>
            <div className="rounded-2xl bg-black/30 p-3">
              <p className="text-white/35">Position age</p>
              <p className="mt-1 font-semibold text-white">{typeof telemetry.freshnessSeconds === "number" ? `${telemetry.freshnessSeconds}s` : "—"}</p>
            </div>
          </div>
          <div className="rounded-2xl bg-black/30 p-3">
            <p className="text-white/35">Aircraft position</p>
            <p className="mt-1 font-mono text-white">{telemetry.latitude.toFixed(5)}, {telemetry.longitude.toFixed(5)}</p>
            <p className="mt-2 text-white/55">{positionResolution.positionExplanation}</p>
          </div>
          {flight.aircraft.dataSourceInfo ? (
            <div className="rounded-2xl border border-emerald-300/15 bg-emerald-300/5 p-3 text-emerald-100/70">
              Aircraft data: {flight.aircraft.dataSourceInfo.source} · {flight.aircraft.dataSourceInfo.license} · {flight.aircraft.dataSourceInfo.dataConfidence}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
