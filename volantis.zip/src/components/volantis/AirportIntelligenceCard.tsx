import Link from "next/link";
import { getAirportIntelligence } from "@/services/airportService";
import { getAirportPhoto } from "@/services/repositories/airportMediaRepository";

export async function AirportIntelligenceCard({ code, title = "Airport intelligence" }: { code: string; title?: string }) {
  const { airport, country, flagSvgUrl, operational } = await getAirportIntelligence(code);
  let photo = null;
  try {
    photo = await getAirportPhoto(airport.iata);
  } catch {
    photo = null;
  }

  return (
    <section className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.055] backdrop-blur-xl">
      {photo?.url ? (
        <div className="relative h-40 sm:h-52">
          <img src={photo.thumbnailUrl ?? photo.url} alt={airport.name} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#02040a] via-transparent to-transparent" />
          {photo.sourcePageUrl ? (
            <a href={photo.sourcePageUrl} target="_blank" rel="noreferrer" className="absolute bottom-2 right-3 rounded-full bg-black/50 px-2 py-0.5 text-[0.6rem] text-white/55 backdrop-blur hover:text-[#FACC15]">
              Photo: {photo.attribution || "Wikimedia Commons"} · {photo.license}
            </a>
          ) : null}
        </div>
      ) : null}

      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#FACC15]">{title}</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.05em] text-white">{airport.iata}</h2>
            <p className="text-sm text-white/60">{airport.name}</p>
            {country ? <p className="mt-1 text-xs text-white/40">{country.flagEmoji} {country.name}</p> : null}
          </div>
          <Link href={`/airports/${airport.iata}`} className="rounded-full border border-white/10 px-3 py-1.5 text-xs font-bold text-white/70 transition hover:border-[#FACC15]/50 hover:text-[#FACC15]">
            Details
          </Link>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 text-sm">
          <div className="rounded-2xl bg-black/25 p-3">
            <p className="text-white/40">City</p>
            <p className="mt-1 font-semibold text-white">{airport.city || "Data unavailable"}, {airport.country || ""}</p>
          </div>
          <div className="rounded-2xl bg-black/25 p-3">
            <p className="text-white/40">Runways</p>
            {operational.availableRunways !== null ? (
              <p className="mt-1 font-semibold text-white">{operational.availableRunways}</p>
            ) : (
              <p className="mt-1 text-sm italic text-white/30">Data unavailable</p>
            )}
          </div>
        </div>

        {airport.dataSourceInfo ? (
          <div className="mt-3 rounded-2xl border border-emerald-300/20 bg-emerald-300/5 p-2.5 text-xs text-emerald-100/80">
            Source: {airport.dataSourceInfo.provider} · License: {airport.dataSourceInfo.license} · Commercial: {airport.dataSourceInfo.commercialUse ? "Yes" : "No"}
          </div>
        ) : null}

        <div className="mt-4 flex flex-wrap gap-2">
          <Link href={`/airports/${airport.iata}`} className="inline-flex rounded-full bg-[#FACC15] px-4 py-2 text-xs font-black uppercase tracking-[0.16em] text-black">
            View airport
          </Link>
          {flagSvgUrl ? <img src={flagSvgUrl} alt={`${airport.country} flag`} className="h-8 w-auto self-center rounded" /> : null}
        </div>
      </div>
    </section>
  );
}
