import { formatDistance, formatDuration } from "@/lib/formatters";
import { getTravelPassport } from "@/services/tripService";

export function TravelPassportPanel() {
  const passport = getTravelPassport();

  return (
    <section className="rounded-[2rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.055)_42%,rgba(255,255,255,0.04))] p-5 backdrop-blur-xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Travel passport</p>
          <h2 className="mt-2 text-2xl font-black tracking-[-0.05em] text-white">Aviation passport</h2>
        </div>
        <div className="rounded-2xl border border-[#FACC15]/30 bg-[#FACC15]/10 px-3 py-2 text-right">
          <p className="text-2xl font-black text-[#FACC15]">{passport.flightCount}</p>
          <p className="text-[0.62rem] uppercase tracking-[0.16em] text-white/45">Flights</p>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-xs text-white/40">Total distance</p>
          <p className="mt-1 text-lg font-black text-white">{formatDistance(passport.totalDistanceKm)}</p>
        </div>
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-xs text-white/40">Time aloft</p>
          <p className="mt-1 text-lg font-black text-white">{formatDuration(passport.totalFlightTimeMinutes)}</p>
        </div>
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-xs text-white/40">Countries</p>
          <p className="mt-1 text-lg font-black text-white">{passport.countriesVisited.length}</p>
        </div>
        <div className="rounded-2xl bg-black/25 p-3">
          <p className="text-xs text-white/40">Airports</p>
          <p className="mt-1 text-lg font-black text-white">{passport.airportsVisited.length}</p>
        </div>
      </div>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {passport.stamps.map((stamp) => (
          <div key={`${stamp.country}-${stamp.airport}`} className="min-w-28 rounded-2xl border border-white/10 bg-black/30 p-3 text-center">
            <p className="text-lg font-black text-[#FACC15]">{stamp.airport}</p>
            <p className="mt-1 text-[0.65rem] uppercase tracking-[0.12em] text-white/45">{stamp.country}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
