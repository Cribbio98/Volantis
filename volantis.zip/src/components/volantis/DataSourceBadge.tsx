import { sourceLabel, sourceTone } from "@/lib/formatters";
import type { DataSourceState } from "@/types/volantis";

export function DataSourceBadge({ source, compact = false }: { source: DataSourceState; compact?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.62rem] font-black uppercase tracking-[0.18em] ${sourceTone(source)}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${source === "LIVE_DATA" ? "animate-pulse bg-emerald-300" : "bg-current"}`} />
      {compact ? sourceLabel(source).replace(" POSITION", "") : sourceLabel(source)}
    </span>
  );
}
