"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { GeoJSONSource, Map as MapLibreMap, Marker } from "maplibre-gl";
import { CockpitHud } from "@/components/volantis/CockpitHud";
import { bearingDegrees, midpoint } from "@/lib/geo";
import { formatAltitude, formatDistance, formatHeading, formatSpeed } from "@/lib/formatters";
import { cameraModeLabel, createVolantisMapStyle, type MapCameraMode } from "@/services/map/mapService";
import { coordinatesToLngLat, getFlightRouteTelemetry } from "@/services/flightTelemetryService";
import type { Coordinate, Flight } from "@/types/volantis";

type MapLibreModule = typeof import("maplibre-gl");
type LineFeature = {
  type: "Feature";
  properties: Record<string, string>;
  geometry: {
    type: "LineString";
    coordinates: [number, number][];
  };
};

function lineFeature(coordinates: Coordinate[]): LineFeature {
  return {
    type: "Feature",
    properties: {},
    geometry: {
      type: "LineString",
      coordinates: coordinatesToLngLat(coordinates),
    },
  };
}

function sourceData(feature: LineFeature) {
  return feature as Parameters<GeoJSONSource["setData"]>[0];
}

function createAirportMarker(label: string, code: string) {
  const element = document.createElement("div");
  element.className = "volantis-airport-marker";
  element.innerHTML = `<span>${label}</span><strong>${code}</strong>`;
  return element;
}

function createAircraftMarker(flight: Flight, heading: number) {
  const element = document.createElement("div");
  element.className = "volantis-aircraft-marker";
  element.style.setProperty("--airline-primary", flight.airline.brandColors.primary);
  element.style.setProperty("--airline-secondary", flight.airline.brandColors.secondary ?? "#0f172a");
  element.style.setProperty("--aircraft-heading", `${heading}deg`);
  element.innerHTML = `<span aria-hidden="true">✈</span>`;
  return element;
}

function setAircraftHeading(marker: Marker | null, heading: number) {
  marker?.getElement().style.setProperty("--aircraft-heading", `${heading}deg`);
}

function upsertLineSource(map: MapLibreMap, id: string, coordinates: Coordinate[]) {
  const existing = map.getSource(id) as GeoJSONSource | undefined;
  const data = sourceData(lineFeature(coordinates));

  if (existing) {
    existing.setData(data);
    return;
  }

  map.addSource(id, {
    type: "geojson",
    data,
  } as Parameters<MapLibreMap["addSource"]>[1]);
}

function addRouteLayers(map: MapLibreMap) {
  if (!map.getLayer("volantis-route-full-layer")) {
    map.addLayer({
      id: "volantis-route-full-layer",
      type: "line",
      source: "volantis-route-full",
      paint: {
        "line-color": "#ffffff",
        "line-opacity": 0.2,
        "line-width": 1.5,
      },
    } as Parameters<MapLibreMap["addLayer"]>[0]);
  }

  if (!map.getLayer("volantis-route-remaining-layer")) {
    map.addLayer({
      id: "volantis-route-remaining-layer",
      type: "line",
      source: "volantis-route-remaining",
      paint: {
        "line-color": "#FACC15",
        "line-opacity": 0.56,
        "line-width": 3,
        "line-dasharray": [1.5, 1.2],
      },
    } as Parameters<MapLibreMap["addLayer"]>[0]);
  }

  if (!map.getLayer("volantis-route-completed-layer")) {
    map.addLayer({
      id: "volantis-route-completed-layer",
      type: "line",
      source: "volantis-route-completed",
      paint: {
        "line-color": "#FACC15",
        "line-opacity": 0.98,
        "line-width": 4.5,
        "line-blur": 0.25,
      },
    } as Parameters<MapLibreMap["addLayer"]>[0]);
  }
}

function syncFlightGeometry(map: MapLibreMap, flight: Flight) {
  const telemetry = getFlightRouteTelemetry(flight);
  upsertLineSource(map, "volantis-route-full", telemetry.fullRoute);
  upsertLineSource(map, "volantis-route-remaining", telemetry.remainingRoute);
  upsertLineSource(map, "volantis-route-completed", telemetry.completedRoute);
  addRouteLayers(map);
}

function applyCameraMode(maplibre: MapLibreModule, map: MapLibreMap, flight: Flight, mode: MapCameraMode) {
  const telemetry = getFlightRouteTelemetry(flight);
  const aircraft = telemetry.aircraft.position;
  const heading = telemetry.aircraft.headingDeg;

  if (mode === "FOLLOW") {
    map.easeTo({
      center: [aircraft.longitude, aircraft.latitude],
      zoom: 5.35,
      pitch: 68,
      bearing: heading,
      duration: 1400,
    });
    return;
  }

  if (mode === "GLOBAL") {
    const center = midpoint([flight.origin, aircraft, flight.destination]);
    map.easeTo({
      center: [center.longitude, center.latitude],
      zoom: 1.15,
      pitch: 18,
      bearing: -22,
      duration: 1400,
    });
    return;
  }

  const bounds = new maplibre.LngLatBounds();
  [flight.origin, aircraft, flight.destination].forEach((point) => bounds.extend([point.longitude, point.latitude]));
  map.fitBounds(bounds, {
    padding: { top: 74, right: 38, bottom: 136, left: 38 },
    duration: 1400,
    maxZoom: 5.2,
  });
  window.setTimeout(() => {
    map.easeTo({
      pitch: 58,
      bearing: bearingDegrees(flight.origin, flight.destination) - 18,
      duration: 650,
    });
  }, 420);
}

export function FlightMap({ flight, connectionState = "online" }: { flight: Flight; connectionState?: "online" | "refreshing" | "offline" }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MapLibreMap | null>(null);
  const maplibreRef = useRef<MapLibreModule | null>(null);
  const aircraftMarkerRef = useRef<Marker | null>(null);
  const departureMarkerRef = useRef<Marker | null>(null);
  const destinationMarkerRef = useRef<Marker | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);
  const [cameraMode, setCameraMode] = useState<MapCameraMode>("ROUTE");
  const telemetry = useMemo(() => getFlightRouteTelemetry(flight), [flight]);

  useEffect(() => {
    let disposed = false;

    async function bootMap() {
      try {
        const maplibre = await import("maplibre-gl");
        if (!containerRef.current || disposed) return;

        maplibreRef.current = maplibre;
        const style = createVolantisMapStyle() as ConstructorParameters<typeof maplibre.Map>[0]["style"];
        const map = new maplibre.Map({
          container: containerRef.current,
          style,
          center: [telemetry.aircraft.position.longitude, telemetry.aircraft.position.latitude],
          zoom: 1.8,
          pitch: 42,
          bearing: -18,
          attributionControl: { compact: true },
        });

        mapRef.current = map;
        map.addControl(new maplibre.NavigationControl({ visualizePitch: true }), "top-right");
        map.touchZoomRotate.enable();
        map.touchZoomRotate.enableRotation();

        map.on("load", () => {
          const globeController = map as unknown as {
            setProjection?: (projection: { type: "globe" }) => void;
            setFog?: (fog: Record<string, unknown>) => void;
          };
          globeController.setProjection?.({ type: "globe" });
          globeController.setFog?.({
            color: "rgb(8, 12, 22)",
            "high-color": "rgb(36, 58, 92)",
            "horizon-blend": 0.18,
            "space-color": "rgb(0, 0, 4)",
            "star-intensity": 0.55,
          });

          syncFlightGeometry(map, flight);
          departureMarkerRef.current = new maplibre.Marker({ element: createAirportMarker("DEP", flight.origin.iata), anchor: "bottom" })
            .setLngLat([flight.origin.longitude, flight.origin.latitude])
            .addTo(map);
          destinationMarkerRef.current = new maplibre.Marker({ element: createAirportMarker("ARR", flight.destination.iata), anchor: "bottom" })
            .setLngLat([flight.destination.longitude, flight.destination.latitude])
            .addTo(map);
          aircraftMarkerRef.current = new maplibre.Marker({ element: createAircraftMarker(flight, telemetry.aircraft.headingDeg), anchor: "center" })
            .setLngLat([telemetry.aircraft.position.longitude, telemetry.aircraft.position.latitude])
            .addTo(map);
          setMapReady(true);
          applyCameraMode(maplibre, map, flight, "ROUTE");
        });
      } catch (error) {
        setMapError(error instanceof Error ? error.message : "Map engine unavailable");
      }
    }

    void bootMap();

    return () => {
      disposed = true;
      aircraftMarkerRef.current?.remove();
      departureMarkerRef.current?.remove();
      destinationMarkerRef.current?.remove();
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const maplibre = maplibreRef.current;
    if (!map || !mapReady || !maplibre) return;

    syncFlightGeometry(map, flight);
    departureMarkerRef.current?.setLngLat([flight.origin.longitude, flight.origin.latitude]);
    destinationMarkerRef.current?.setLngLat([flight.destination.longitude, flight.destination.latitude]);
    aircraftMarkerRef.current?.setLngLat([telemetry.aircraft.position.longitude, telemetry.aircraft.position.latitude]);
    setAircraftHeading(aircraftMarkerRef.current, telemetry.aircraft.headingDeg);

    if (cameraMode === "FOLLOW") {
      applyCameraMode(maplibre, map, flight, cameraMode);
    }
  }, [cameraMode, flight, mapReady, telemetry.aircraft.headingDeg, telemetry.aircraft.position.latitude, telemetry.aircraft.position.longitude]);

  function chooseCameraMode(mode: MapCameraMode) {
    setCameraMode(mode);
    const map = mapRef.current;
    const maplibre = maplibreRef.current;
    if (map && maplibre) {
      applyCameraMode(maplibre, map, flight, mode);
    }
  }

  return (
    <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#02040a] shadow-[0_30px_90px_rgba(0,0,0,0.55)]">
      <div ref={containerRef} className="h-[520px] w-full bg-[radial-gradient(circle_at_50%_35%,rgba(30,64,175,0.35),rgba(2,6,23,0.98)_58%)]" />

      {!mapReady ? (
        <div className="absolute inset-0 grid place-items-center bg-[#02040a]/55 text-center backdrop-blur-sm">
          <div>
            <div className="mx-auto h-12 w-12 animate-spin rounded-full border-2 border-[#FACC15]/20 border-t-[#FACC15]" />
            <p className="mt-4 text-sm font-semibold text-white">Initializing geographic globe</p>
            <p className="mt-1 text-xs text-white/45">Satellite imagery and terrain are optional, non-secret map providers.</p>
            {mapError ? <p className="mt-2 text-xs text-orange-200">{mapError}</p> : null}
          </div>
        </div>
      ) : null}

      <div className="absolute left-3 top-3 z-20 flex rounded-full border border-white/10 bg-[#04070f]/78 p-1 backdrop-blur-xl">
        {(["GLOBAL", "ROUTE", "FOLLOW"] as const).map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => chooseCameraMode(mode)}
            className={`rounded-full px-3 py-2 text-[0.62rem] font-black uppercase tracking-[0.14em] transition ${cameraMode === mode ? "bg-[#FACC15] text-black" : "text-white/55 hover:text-white"}`}
          >
            {cameraModeLabel(mode)}
          </button>
        ))}
      </div>

      <div className="absolute right-3 top-16 z-20 w-36 rounded-3xl border border-white/10 bg-[#04070f]/70 p-3 text-xs text-white/55 backdrop-blur-xl">
        <p className="font-black uppercase tracking-[0.16em] text-[#FACC15]">Aircraft</p>
        <p className="mt-2">Alt {formatAltitude(flight.telemetry?.altitudeFt)}</p>
        <p>GS {formatSpeed(flight.telemetry?.groundSpeedKt)}</p>
        <p>HDG {formatHeading(telemetry.aircraft.headingDeg)}</p>
        <p className="mt-2 text-white/40">Remain {formatDistance(telemetry.aircraft.remainingDistanceKm)}</p>
      </div>

      <CockpitHud flight={flight} connectionState={connectionState} />
    </div>
  );
}
