import { AirlineLogo } from "@/components/volantis/AirlineLogo";
import { DataSourceBadge } from "@/components/volantis/DataSourceBadge";
import { LiveFlightExperience } from "@/components/volantis/LiveFlightExperience";
import { RouteStrip } from "@/components/volantis/RouteStrip";
import { countdownTo, formatDateTime, formatDistance, formatDuration, formatTime, statusLabel } from "@/lib/formatters";
import type { Flight } from "@/types/volantis";

export function NextFlightHero({ flight }: { flight: Flight }) {
  return (
    <section id="home" className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.2),rgba(255,255,255,0.075)_36%,rgba(255,255,255,0.045)_72%)] p-4 shadow-[0_32px_120px_rgba(0,0,0,0.5)] backdrop-blur-2xl sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex min-w-0 items-center gap-4">
          <AirlineLogo airline={flight.airline} size="lg" />
          <div className="min-w-0">
            <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Next flight</p>
            <h2 className="mt-1 truncate text-3xl font-black tracking-[-0.07em] text-white sm:text-5xl">{flight.flightNumber}</h2>
            <p className="truncate text-sm text-white/58">{flight.airline.name} · {flight.aircraft.type}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <DataSourceBadge source={flight.dataSource} />
          <span className="rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-xs font-black uppercase tracking-[0.16em] text-white/60">
            {statusLabel(flight.status)}
          </span>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-[1fr_auto_1fr] items-end gap-4">
        <div>
          <p className="text-5xl font-black tracking-[-0.08em] text-white sm:text-7xl">{flight.origin.iata}</p>
          <p className="mt-1 text-sm font-medium text-white/52">{flight.origin.city}</p>
          <p className="text-xs text-white/35">{flight.origin.name}</p>
        </div>
        <div className="pb-3 text-center">
          <div className="rounded-full bg-[#FACC15] px-3 py-1 text-xs font-black uppercase tracking-[0.18em] text-black">
            {countdownTo(flight.scheduledDeparture)}
          </div>
          <p className="mt-2 text-[0.65rem] uppercase tracking-[0.18em] text-white/40">Departure</p>
        </div>
        <div className="text-right">
          <p className="text-5xl font-black tracking-[-0.08em] text-white sm:text-7xl">{flight.destination.iata}</p>
          <p className="mt-1 text-sm font-medium text-white/52">{flight.destination.city}</p>
          <p className="text-xs text-white/35">{flight.destination.name}</p>
        </div>
      </div>

      <RouteStrip flight={flight} emphasis />

      <div className="mt-2 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
        <div className="rounded-3xl bg-black/25 p-4">
          <p className="text-white/38">Departure</p>
          <p className="mt-1 text-lg font-black text-white">{formatTime(flight.estimatedDeparture ?? flight.scheduledDeparture)}</p>
          <p className="text-xs text-white/40">{formatDateTime(flight.scheduledDeparture).split(" · ")[0]}</p>
        </div>
        <div className="rounded-3xl bg-black/25 p-4">
          <p className="text-white/38">Arrival</p>
          <p className="mt-1 text-lg font-black text-white">{formatTime(flight.estimatedArrival ?? flight.scheduledArrival)}</p>
          <p className="text-xs text-white/40">{formatDuration(flight.durationMinutes)}</p>
        </div>
        <div className="rounded-3xl bg-black/25 p-4">
          <p className="text-white/38">Terminal / Gate</p>
          <p className="mt-1 text-lg font-black text-white">{flight.terminal ? `T${flight.terminal}` : "—"} {flight.gate ?? ""}</p>
          <p className="text-xs text-white/40">Boarding {formatTime(flight.boarding?.startsAt)}</p>
        </div>
        <div className="rounded-3xl bg-black/25 p-4">
          <p className="text-white/38">Distance</p>
          <p className="mt-1 text-lg font-black text-white">{formatDistance(flight.distanceKm)}</p>
          <p className="text-xs text-white/40">Remaining {formatDistance(flight.remainingDistanceKm)}</p>
        </div>
      </div>

      <div className="mt-5">
        <LiveFlightExperience initialFlight={flight} />
      </div>
    </section>
  );
}
