"use client";

import { useState } from "react";
import type { Flight } from "@/types/volantis";

const views = ["Perspective", "Front", "Side", "Top"] as const;

type ViewMode = (typeof views)[number];

function transformFor(view: ViewMode, rotation: number, zoom: number) {
  const base = `scale(${zoom})`;
  if (view === "Front") return `${base} rotateX(0deg) rotateY(90deg) rotateZ(0deg)`;
  if (view === "Side") return `${base} rotateX(0deg) rotateY(0deg) rotateZ(0deg)`;
  if (view === "Top") return `${base} rotateX(64deg) rotateY(0deg) rotateZ(${rotation}deg)`;
  return `${base} rotateX(56deg) rotateZ(${rotation}deg)`;
}

export function AircraftViewer({ flight }: { flight: Flight }) {
  const [rotation, setRotation] = useState(18);
  const [zoom, setZoom] = useState(1);
  const [view, setView] = useState<ViewMode>("Perspective");
  const [wireframe, setWireframe] = useState(false);

  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#FACC15]">3D aircraft viewer</p>
          <h2 className="mt-2 text-xl font-black tracking-[-0.04em] text-white">{flight.aircraft.type}</h2>
          <p className="text-sm text-white/48">{flight.aircraft.registration ?? "Registration pending"} · {flight.airline.name}</p>
        </div>
        <button type="button" onClick={() => setWireframe((value) => !value)} className="rounded-full border border-white/10 px-3 py-1.5 text-xs font-bold text-white/65">
          {wireframe ? "Solid" : "Wire"}
        </button>
      </div>

      <div className="aircraft-viewer-stage mt-5 h-72 overflow-hidden rounded-[1.5rem] border border-white/10 bg-[radial-gradient(circle_at_50%_35%,rgba(250,204,21,0.14),rgba(15,23,42,0.25)_38%,rgba(0,0,0,0.35))]">
        <div
          className={`aircraft-model ${wireframe ? "aircraft-wireframe" : ""}`}
          style={{
            transform: transformFor(view, rotation, zoom),
            "--airline-primary": flight.airline.brandColors.primary,
            "--airline-secondary": flight.airline.brandColors.secondary ?? "#0f172a",
          } as React.CSSProperties}
        >
          <span className="aircraft-fuselage" />
          <span className="aircraft-nose" />
          <span className="aircraft-tail" />
          <span className="aircraft-wing aircraft-wing-left" />
          <span className="aircraft-wing aircraft-wing-right" />
          <span className="aircraft-stabilizer aircraft-stabilizer-left" />
          <span className="aircraft-stabilizer aircraft-stabilizer-right" />
          <span className="aircraft-engine aircraft-engine-left" />
          <span className="aircraft-engine aircraft-engine-right" />
          <span className="aircraft-nav aircraft-nav-red" />
          <span className="aircraft-nav aircraft-nav-green" />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2">
        {views.map((item) => (
          <button key={item} type="button" onClick={() => setView(item)} className={`rounded-full px-2 py-2 text-[0.65rem] font-bold uppercase tracking-[0.1em] ${view === item ? "bg-[#FACC15] text-black" : "bg-white/10 text-white/60"}`}>
            {item}
          </button>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <label className="rounded-2xl bg-black/25 p-3 text-xs text-white/55">
          Rotation
          <input className="mt-2 w-full accent-[#FACC15]" type="range" min="-180" max="180" value={rotation} onChange={(event) => setRotation(Number(event.target.value))} />
        </label>
        <label className="rounded-2xl bg-black/25 p-3 text-xs text-white/55">
          Zoom
          <input className="mt-2 w-full accent-[#FACC15]" type="range" min="0.7" max="1.45" step="0.05" value={zoom} onChange={(event) => setZoom(Number(event.target.value))} />
        </label>
      </div>

      {flight.aircraft.specs ? (
        <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-white/55">
          <span className="rounded-2xl bg-black/25 p-3">Cruise {flight.aircraft.specs.typicalCruiseKt} kt</span>
          <span className="rounded-2xl bg-black/25 p-3">Range {flight.aircraft.specs.rangeKm.toLocaleString("en")} km</span>
          <span className="rounded-2xl bg-black/25 p-3">Ceiling {flight.aircraft.specs.ceilingFt.toLocaleString("en")} ft</span>
          <span className="rounded-2xl bg-black/25 p-3">Seats {flight.aircraft.specs.typicalSeats}</span>
        </div>
      ) : null}
    </section>
  );
}
