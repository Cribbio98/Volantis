const items = [
  { label: "Home", href: "/" },
  { label: "Map", href: "/#home" },
  { label: "Search", href: "/search" },
  { label: "Trips", href: "/#trips" },
  { label: "More", href: "/more" },
];

export function BottomNav({ current = "/" }: { current?: string }) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#04070f]/90 px-4 py-3 backdrop-blur-2xl md:hidden">
      <div className="mx-auto grid max-w-md grid-cols-5 gap-1 rounded-full border border-white/10 bg-white/[0.04] p-1">
        {items.map((item) => {
          const active = current === item.href || (item.href === "/" && current === "/");
          return (
            <a key={item.label} href={item.href} className={`rounded-full px-2 py-2 text-center text-[0.62rem] font-bold uppercase tracking-[0.1em] ${active ? "bg-[#FACC15] text-black" : "text-white/50"}`}>
              {item.label}
            </a>
          );
        })}
      </div>
    </nav>
  );
}
