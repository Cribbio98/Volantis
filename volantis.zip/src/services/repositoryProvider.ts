import { AeroDataBoxFlightRepository } from "@/services/repositories/aeroDataBoxFlightRepository";
import type { FlightRepository } from "@/services/repositories/flightRepository";
import { MockFlightRepository } from "@/services/repositories/mockFlightRepository";

const VOLANTIS_FORCE_DEMO = true;

export class RepositoryProvider {
  private readonly aeroDataBox = new AeroDataBoxFlightRepository();
  private readonly mock = new MockFlightRepository();

  flightRepository(): FlightRepository {
    if (VOLANTIS_FORCE_DEMO) {
      return this.mock;
    }
    return this.aeroDataBox.configured ? this.aeroDataBox : this.mock;
  }

  fallbackFlightRepository(): FlightRepository {
    return this.mock;
  }

  get isLiveMode() {
    return !VOLANTIS_FORCE_DEMO && this.aeroDataBox.configured;
  }
}

const globalForRepository = globalThis as typeof globalThis & {
  __volantisRepositoryProvider?: RepositoryProvider;
};

export const repositoryProvider =
  globalForRepository.__volantisRepositoryProvider ?? new RepositoryProvider();

if (process.env.NODE_ENV !== "production") {
  globalForRepository.__volantisRepositoryProvider = repositoryProvider;
}
