import type { Coordinate, PositionUpdate } from "@/types/volantis";
import { greatCircleInterpolate } from "@/lib/geo";

const MAX_INTERPOLATION_AGE_MS = 120_000;
const DEFAULT_HEADING_SMOOTHING = 0.7;

function shortestAngleDelta(from: number, to: number) {
  let delta = ((to - from + 540) % 360) - 180;
  return delta;
}

function lerpAngle(from: number, to: number, fraction: number) {
  const delta = shortestAngleDelta(from, to);
  return ((from + delta * fraction) % 360 + 360) % 360;
}

export class PositionInterpolator {
  private previous: PositionUpdate | null = null;
  private current: PositionUpdate | null = null;

  push(update: PositionUpdate) {
    if (this.current && update.timestampMs <= this.current.timestampMs) {
      return;
    }
    this.previous = this.current;
    this.current = update;
  }

  getInterpolatedPosition(nowMs: number): Coordinate & { headingDeg: number; altitudeFt?: number; groundSpeedKt?: number; isInterpolated: boolean } {
    if (!this.current) {
      return { latitude: 0, longitude: 0, headingDeg: 0, isInterpolated: true };
    }

    if (!this.previous || nowMs >= this.current.timestampMs) {
      return {
        latitude: this.current.latitude,
        longitude: this.current.longitude,
        headingDeg: this.current.headingDeg ?? 0,
        altitudeFt: this.current.altitudeFt,
        groundSpeedKt: this.current.groundSpeedKt,
        isInterpolated: false,
      };
    }

    const spanMs = this.current.timestampMs - this.previous.timestampMs;
    if (spanMs <= 0 || spanMs > MAX_INTERPOLATION_AGE_MS) {
      return {
        latitude: this.current.latitude,
        longitude: this.current.longitude,
        headingDeg: this.current.headingDeg ?? 0,
        altitudeFt: this.current.altitudeFt,
        groundSpeedKt: this.current.groundSpeedKt,
        isInterpolated: false,
      };
    }

    const fraction = Math.max(0, Math.min(1, (nowMs - this.previous.timestampMs) / spanMs));
    const position = greatCircleInterpolate(this.previous, this.current, fraction);

    const previousHeading = this.previous.headingDeg ?? 0;
    const currentHeading = this.current.headingDeg ?? previousHeading;
    const headingDeg = lerpAngle(previousHeading, currentHeading, fraction);

    const previousAlt = this.previous.altitudeFt ?? this.current.altitudeFt ?? 0;
    const currentAlt = this.current.altitudeFt ?? previousAlt;
    const altitudeFt = previousAlt + (currentAlt - previousAlt) * fraction;

    const previousSpeed = this.previous.groundSpeedKt ?? this.current.groundSpeedKt ?? 0;
    const currentSpeed = this.current.groundSpeedKt ?? previousSpeed;
    const groundSpeedKt = previousSpeed + (currentSpeed - previousSpeed) * fraction;

    return {
      latitude: position.latitude,
      longitude: position.longitude,
      headingDeg,
      altitudeFt: Math.round(altitudeFt),
      groundSpeedKt: Math.round(groundSpeedKt),
      isInterpolated: fraction > 0.01,
    };
  }

  getSmoothedHeading(rawHeading: number): number {
    if (!this.current?.headingDeg) return rawHeading;
    const smoothed = lerpAngle(rawHeading, this.current.headingDeg, DEFAULT_HEADING_SMOOTHING);
    return smoothed;
  }

  getLastUpdate(): PositionUpdate | null {
    return this.current;
  }

  getTimeSinceLastUpdateMs(nowMs: number): number | undefined {
    if (!this.current) return undefined;
    return nowMs - this.current.timestampMs;
  }

  isStale(nowMs: number, thresholdMs = 60_000): boolean {
    if (!this.current) return true;
    return nowMs - this.current.timestampMs > thresholdMs;
  }
}
