import { createDemoLogbook, computeLogbookStatistics } from "@/data/demoLogbook";
import type { LogbookEntry, LogbookStatistics } from "@/data/demoLogbook";

export function getLogbook(): LogbookEntry[] {
  return createDemoLogbook();
}

export function getLogbookStatistics(): LogbookStatistics {
  return computeLogbookStatistics(createDemoLogbook());
}
