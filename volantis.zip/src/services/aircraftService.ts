import { aircraftFleetDirectory } from "@/data/aircraft";
import type { Flight } from "@/types/volantis";

export function getAircraftFleetDirectory(flights: Flight[] = []) {
  return aircraftFleetDirectory.map((aircraft) => ({
    ...aircraft,
    userFlightCount: flights.filter((flight) => flight.aircraft.type.includes(aircraft.model.split(" ").slice(-1)[0] ?? aircraft.model)).length,
  }));
}
