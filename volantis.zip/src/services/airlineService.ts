import { getAirlineRepository } from "@/services/repositories/airlineRepository";
import { countryRepository } from "@/services/repositories/countryRepository";
import type { Flight } from "@/types/volantis";

export async function getAirlineDirectory(flights: Flight[] = []) {
  const repository = getAirlineRepository();
  const allAirlines = repository.getAll();

  return allAirlines.map((airline) => {
    const country = airline.countryIso ? countryRepository.findByAlpha2(airline.countryIso) : undefined;
    return {
      ...airline,
      countryFlag: country ? country.flagEmoji : undefined,
      countryFlagSvg: country ? countryRepository.flagSvgUrl(country.isoAlpha2) : undefined,
      userFlightCount: flights.filter((flight) => flight.airline.iata === airline.iata || flight.airline.icao === airline.icao).length,
    };
  });
}

export function getAllianceFilters() {
  return ["Star Alliance", "SkyTeam", "oneworld", "Independent"] as const;
}
