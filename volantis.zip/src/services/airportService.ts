import { getAirportRepository } from "@/services/repositories/airportRepository";
import { countryRepository } from "@/services/repositories/countryRepository";

export async function getAirportIntelligence(code: string) {
  const repository = getAirportRepository();
  const byIata = await repository.findByIata(code);
  const byIcao = !byIata ? await repository.findByIcao(code) : null;
  const bySearch = !byIata && !byIcao ? await repository.search({ iata: code }, 1) : [];
  const fallback = !byIata && !byIcao && bySearch.length === 0 ? repository.getAll()[0] : null;
  const airport = byIata ?? byIcao ?? bySearch[0] ?? fallback;
  const country = airport.countryIso ? countryRepository.findByAlpha2(airport.countryIso) : undefined;

  // No fabricated operational statistics. Only fields backed by real data are populated.
  // Real departure/arrival boards require an aviation data provider (AeroDataBox FIDS),
  // which is implemented but not activated in DEMO mode.
  const operational = {
    availableRunways: airport.runways?.length ?? airport.runwayCount ?? null,
    scheduledService: airport.scheduledService ?? null,
    terminalInfo: airport.terminals?.length ? airport.terminals.join(", ") : null,
    liveFeedAvailable: false,
    feedNote: "Live departure/arrival boards require an activated flight data provider. AeroDataBox FIDS integration is implemented but not enabled in DEMO mode.",
  };

  return {
    airport,
    country,
    flagSvgUrl: country ? countryRepository.flagSvgUrl(country.isoAlpha2) : undefined,
    operational,
    googleMapsUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${airport.name} ${airport.latitude},${airport.longitude}`)}`,
  };
}

export async function getAirportDirectory() {
  const repository = getAirportRepository();
  return repository.getAll();
}
