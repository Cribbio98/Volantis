import { normalizeLicense, resultMatchesSubject, type MediaKind, type MediaProvider, type MediaProviderResult, type MediaSubject } from "@/services/providers/mediaProvider";
import type { DataSourceInfo, MediaAsset } from "@/types/volantis";

interface ExtMeta {
  LicenseShortName?: { value?: string };
  Artist?: { value?: string };
  LicenseUrl?: { value?: string };
}
interface ImgInfo {
  url?: string;
  thumburl?: string;
  descriptionurl?: string;
  extmetadata?: ExtMeta;
}
interface Page {
  title?: string;
  imageinfo?: ImgInfo[];
}

const UA = "Volantis/1.0 (premium aviation companion; respectful, sparse bot traffic)";

export class WikimediaMediaProvider implements MediaProvider {
  readonly name = "wikimedia-commons";
  private readonly base = "https://commons.wikimedia.org/w/api.php";
  private maxRetries = 4;
  private baseDelayMs = 800;

  private async fetchJson(query: string, limit: number): Promise<{ pages: Page[]; status?: number }> {
    const url =
      `${this.base}?action=query&generator=search` +
      `&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=${limit}` +
      `&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=900&format=json&origin=*`;

    for (let attempt = 0; attempt < this.maxRetries; attempt++) {
      let res: Response;
      try {
        res = await fetch(url, { cache: "no-store", headers: { "User-Agent": UA } });
      } catch (error) {
        console.warn(`[wikimedia] network error (${query.slice(0, 28)}…) attempt ${attempt + 1}`, error);
        res = null as unknown as Response;
      }

      const status = res?.status;
      if (res && status === 200) {
        const data = (await res.json()) as { query?: { pages?: Record<string, Page> } };
        return { pages: Object.values(data.query?.pages ?? {}) };
      }
      if (status === 429 || (status && status >= 500)) {
        const jitter = Math.random() * 200;
        const delay = Math.pow(2, attempt) * this.baseDelayMs + jitter;
        console.warn(`[wikimedia] HTTP ${status} — backing off ${Math.round(delay)}ms before retry ${attempt + 1}/${this.maxRetries}`);
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      return { pages: [], status };
    }
    return { pages: [], status: 429 };
  }

  private toAsset(info: ImgInfo, title: string, subject: MediaSubject, kind: MediaKind): MediaAsset | null {
    if (!title) return null;
    const url = info.thumburl ?? info.url;
    if (!url) return null;

    if (!resultMatchesSubject(title, subject, kind)) {
      return null;
    }

    const license = normalizeLicense(info.extmetadata?.LicenseShortName?.value);
    const author = info.extmetadata?.Artist?.value?.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
    const now = new Date().toISOString();

    return {
      url,
      thumbnailUrl: info.thumburl,
      sourcePageUrl: info.descriptionurl,
      author: author || undefined,
      license: license.normalized,
      licenseUrl: info.extmetadata?.LicenseUrl?.value,
      attribution: author ? `${author}, ${license.normalized}, via Wikimedia Commons` : `${license.normalized}, via Wikimedia Commons`,
      commercialUse: license.commercialOk,
      retrievedAt: now,
    };
  }

  private async find(queryTerms: string[], subject: MediaSubject, kind: MediaKind, limit = 6): Promise<MediaProviderResult> {
    let providerError = false;
    let lastStatus = 0;
    for (const term of queryTerms) {
      const { pages, status } = await this.fetchJson(term, limit);
      if (status === 429 || (status && status >= 500)) providerError = true;
      lastStatus = status ?? 0;
      for (const page of pages) {
        const info = page.imageinfo?.[0];
        const title = page.title ?? "";
        if (!info) continue;
        const asset = this.toAsset(info, title, subject, kind);
        if (asset) return { asset };
      }
      await new Promise((r) => setTimeout(r, 220));
    }
    return { asset: null, providerError, statusCode: lastStatus || undefined };
  }

  async findAirportPhoto(subject: MediaSubject): Promise<MediaProviderResult> {
    const queries = [
      `${subject.name} airport terminal`,
      `${subject.code} airport`,
      `${subject.name} airport`,
      ...(subject.city ? [`${subject.city} ${subject.name} airport`] : []),
      `${subject.name} aerodrome`,
    ];
    return this.find(queries, subject, "airport-photo");
  }

  async findAirlineLogo(subject: MediaSubject): Promise<MediaProviderResult> {
    const queries = [
      `${subject.name} logo svg`,
      `${subject.name} logo`,
      `${subject.name} airline logo`,
      `${subject.name} emblem`,
    ];
    return this.find(queries, subject, "airline-logo", 5);
  }

  async findAircraftPhoto(subject: MediaSubject): Promise<MediaProviderResult> {
    const queries = [`${subject.name} aircraft`, `${subject.name} airplane`];
    return this.find(queries, subject, "aircraft-photo");
  }
}

export const wikimediaMediaProvider = new WikimediaMediaProvider();
