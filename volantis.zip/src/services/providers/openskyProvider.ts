import type { DataSourceInfo, Coordinate } from "@/types/volantis";

export interface OpenSkyStateVector {
  icao24: string;
  callsign?: string;
  originCountry?: string;
  timePosition?: number;
  lastContact?: number;
  longitude?: number;
  latitude?: number;
  baroAltitude?: number;
  onGround?: boolean;
  velocity?: number;
  trueTrack?: number;
  verticalRate?: number;
  geoAltitude?: number;
  squawk?: string;
}

function takeNumber(value: string | number | boolean | null): number | undefined {
  return typeof value === "number" ? value : undefined;
}

function takeBoolean(value: string | number | boolean | null): boolean | undefined {
  return typeof value === "boolean" ? value : undefined;
}

function takeString(value: string | number | boolean | null): string | undefined {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : undefined;
}

export type OpenSkyState = Array<string | number | boolean | null>;

export interface OpenSkyResponse {
  time: number;
  states: OpenSkyState[] | null;
}

export interface OpenSkySearchResult {
  icao24: string;
  callsign?: string;
  latitude?: number;
  longitude?: number;
  baroAltitude?: number;
  velocityKts?: number;
  trueTrack?: number;
  verticalRateFpm?: number;
  onGround?: boolean;
  lastContactMs?: number;
  dataSourceInfo: DataSourceInfo;
}

export class OpenSkyProvider {
  readonly sourceName = "opensky";
  private readonly baseUrl = "https://opensky-network.org/api";
  private lastRequestAt = 0;
  private readonly minRequestIntervalMs = 10_000;
  private readonly maxRetries = 3;
  private readonly baseRetryDelayMs = 1000;
  private cache = new Map<string, { data: OpenSkyResponse; fetchedAt: number }>();
  private static readonly ACCEPTED_USER_AGENT = "volantis/1.0 opensky-app";

  private formatCoordinates(bounds: { minLat: number; maxLat: number; minLon: number; maxLon: number }) {
    return `${bounds.minLon.toFixed(1)},${bounds.minLat.toFixed(1)},${bounds.maxLon.toFixed(1)},${bounds.maxLat.toFixed(1)}`;
  }

  private async throttle() {
    const elapsed = Date.now() - this.lastRequestAt;
    if (elapsed < this.minRequestIntervalMs) {
      await new Promise((r) => setTimeout(r, this.minRequestIntervalMs - elapsed));
    }
    this.lastRequestAt = Date.now();
  }

  private async fetchWithRetry(url: string, attempt = 0): Promise<OpenSkyResponse | null> {
    try {
      await this.throttle();
      const response = await fetch(url, {
        cache: "no-store",
        headers: { "User-Agent": OpenSkyProvider.ACCEPTED_USER_AGENT },
      });

      if (response.status === 400 || response.status === 429) {
        const delay = this.baseRetryDelayMs * Math.pow(2, attempt);
        if (attempt < this.maxRetries) {
          await new Promise((r) => setTimeout(r, delay));
          return this.fetchWithRetry(url, attempt + 1);
        }
        return null;
      }
      if (!response.ok || response.status === 429) return null;

      const raw = (await response.json()) as OpenSkyResponse;
      return raw;
    } catch {
      return null;
    }
  }

  async getStatesByBounds(bounds: { minLat: number; maxLat: number; minLon: number; maxLon: number }): Promise<OpenSkyStateVector[]> {
    const cacheKey = this.formatCoordinates(bounds);
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.fetchedAt < 60_000) {
      return this.mapStates(cached.data);
    }

    this.lastRequestAt = 0;
    const url = `${this.baseUrl}/states/all?lamin=${bounds.minLat}&lomin=${bounds.minLon}&lamax=${bounds.maxLat}&lomax=${bounds.maxLon}`;
    const data = await this.fetchWithRetry(url);
    if (!data || !data.states) return [];

    this.cache.set(cacheKey, { data, fetchedAt: Date.now() });
    return this.mapStates(data);
  }

  private mapStates(data: OpenSkyResponse): OpenSkyStateVector[] {
    if (!data.states) return [];
    return data.states.map((s) => ({
      icao24: takeString(s[0]) ?? "",
      callsign: takeString(s[1]),
      originCountry: takeString(s[2]),
      timePosition: takeNumber(s[3]),
      lastContact: takeNumber(s[4]),
      longitude: takeNumber(s[5]),
      latitude: takeNumber(s[6]),
      baroAltitude: takeNumber(s[7]),
      onGround: takeBoolean(s[8]),
      velocity: takeNumber(s[9]),
      trueTrack: takeNumber(s[10]),
      verticalRate: takeNumber(s[11]),
      geoAltitude: takeNumber(s[13]),
      squawk: takeString(s[14]),
    }));
  }

  async getAircraftByCallsign(callsign: string, bounds?: { minLat: number; maxLat: number; minLon: number; maxLon: number }): Promise<OpenSkySearchResult | null> {
    const defaultBounds = { minLat: -90, maxLat: 90, minLon: -180, maxLon: 180 };
    const states = await this.getStatesByBounds(bounds ?? defaultBounds);
    const normalized = callsign.trim().toUpperCase();
    const matched = states.find((s) => s.callsign?.toUpperCase() === normalized) ?? states.find((s) => s.callsign?.toUpperCase().startsWith(normalized.slice(0, 6)));

    if (!matched) return null;

    const now = new Date().toISOString();
    const dataSourceInfo: DataSourceInfo = {
      source: this.sourceName,
      provider: "OpenSky Network",
      sourceUrl: "https://opensky-network.org/",
      license: "OpenSky ToS — anonymous, minimal. Requires attribution for frequent use.",
      attribution: "State vectors by The OpenSky Network (opensky-network.org).",
      commercialUse: false,
      sourceUpdatedAt: now,
      dataConfidence: "verified",
      cachedAt: now,
      retrievedAt: now,
    };

    return {
      icao24: matched.icao24,
      callsign: matched.callsign,
      latitude: matched.latitude,
      longitude: matched.longitude,
      baroAltitude: matched.baroAltitude,
      velocityKts: matched.velocity !== undefined ? Math.round(matched.velocity * 0.539957) : undefined,
      trueTrack: matched.trueTrack,
      verticalRateFpm: matched.verticalRate !== undefined ? Math.round(matched.verticalRate * 196.85) : undefined,
      onGround: matched.onGround,
      lastContactMs: matched.lastContact,
      dataSourceInfo,
    };
  }

  getHealthStatus() {
    return {
      provider: this.sourceName,
      available: true,
      lastRequestAt: this.lastRequestAt,
      caching: true,
      cacheEntries: this.cache.size,
      rateLimited: Date.now() - this.lastRequestAt < this.minRequestIntervalMs,
    };
  }
}

export const openskyProvider = new OpenSkyProvider();
