import { wikimediaMediaProvider } from "@/services/providers/wikimediaMediaProvider";
import type { MediaKind, MediaProvider, MediaSubject } from "@/services/providers/mediaProvider";
import type { MediaAsset } from "@/types/volantis";

interface ProviderHealth {
  name: string;
  available: boolean;
  consecutiveFailures: number;
  lastStatus?: number;
  lastErrorAt?: string;
  lastSuccessAt?: string;
  lastFailureReason?: string;
}

class MediaProviderChain {
  private providers: MediaProvider[] = [];
  private health = new Map<string, ProviderHealth>();

  register(provider: MediaProvider) {
    this.providers.push(provider);
    this.health.set(provider.name, {
      name: provider.name,
      available: true,
      consecutiveFailures: 0,
    });
    return this;
  }

  private markSuccess(name: string) {
    const h = this.health.get(name);
    if (h) {
      h.consecutiveFailures = 0;
      h.available = true;
      h.lastSuccessAt = new Date().toISOString();
      delete h.lastFailureReason;
      delete h.lastStatus;
    }
  }

  private markFailure(name: string, status?: number, reason?: string) {
    const h = this.health.get(name);
    if (h) {
      h.consecutiveFailures += 1;
      h.lastErrorAt = new Date().toISOString();
      h.lastStatus = status;
      h.lastFailureReason = reason;
      if (h.consecutiveFailures >= 3 || status === 429) {
        h.available = false;
      }
    }
  }

  async find(kind: MediaKind, subject: MediaSubject): Promise<{ asset: MediaAsset | null; provider: string; degraded: boolean }> {
    for (const provider of this.providers) {
      const health = this.health.get(provider.name);
      if (health && !health.available) {
        console.warn(`[mediaChain] provider ${provider.name} is degraded (${health.lastFailureReason}) — skipping`);
        continue;
      }

      let result;
      try {
        if (kind === "airport-photo") result = await provider.findAirportPhoto(subject);
        else if (kind === "airline-logo") result = await provider.findAirlineLogo(subject);
        else result = await provider.findAircraftPhoto(subject);
      } catch (error) {
        this.markFailure(provider.name, 0, error instanceof Error ? error.message : "unknown");
        continue;
      }

      if (result.asset) {
        this.markSuccess(provider.name);
        return { asset: result.asset, provider: provider.name, degraded: false };
      }
      if (result.providerError) {
        this.markFailure(provider.name, result.statusCode, `http-${result.statusCode}`);
      }
      // no asset found → legit "not found", not provider error
    }
    return { asset: null, provider: "none", degraded: Array.from(this.health.values()).some((h) => !h.available) };
  }

  getHealth() {
    return Array.from(this.health.values());
  }
}

export const mediaProviderChain = new MediaProviderChain().register(wikimediaMediaProvider);
