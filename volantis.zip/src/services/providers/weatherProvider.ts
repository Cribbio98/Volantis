import type { DataSourceInfo } from "@/types/volantis";

export interface WeatherCondition {
  temperatureC: number;
  windSpeedKts: number;
  windDirectionDeg: number;
  visibilityKm?: number;
  cloudCoverPct?: number;
  precipitationMm?: number;
  weatherCode?: string;
  weatherDescription?: string;
  humidityPct?: number;
  pressureHpa?: number;
  forecastNext6h?: Array<{
    time: string;
    temperatureC: number;
    windSpeedKts: number;
    precipitationProbPct: number;
    weatherCode?: string;
  }>;
  dataSourceInfo: DataSourceInfo;
}

export interface WeatherProvider {
  readonly sourceName: string;
  getCurrentWeather(latitude: number, longitude: number): Promise<WeatherCondition | null>;
  getAirportWeather(iata: string): Promise<WeatherCondition | null>;
}

export class OpenMeteoWeatherProvider implements WeatherProvider {
  readonly sourceName = "open-meteo";
  private readonly baseUrl = "https://api.open-meteo.com/v1/forecast";
  private cache = new Map<string, { data: WeatherCondition; cachedAt: number }>();

  private async fetchWeather(latitude: number, longitude: number): Promise<WeatherCondition | null> {
    const cacheKey = `${latitude.toFixed(4)},${longitude.toFixed(4)}`;
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < 5 * 60_000) {
      return cached.data;
    }

    try {
      const url = new URL(this.baseUrl);
      url.searchParams.set("latitude", String(latitude));
      url.searchParams.set("longitude", String(longitude));
      url.searchParams.set("current", "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m");
      url.searchParams.set("hourly", "temperature_2m,precipitation_probability,weather_code,wind_speed_10m");
      url.searchParams.set("forecast_days", "1");
      url.searchParams.set("timezone", "UTC");

      const response = await fetch(url.toString(), { cache: "no-store" });
      if (!response.ok) return null;

      const raw = (await response.json()) as {
        current?: { temperature_2m?: number; relative_humidity_2m?: number; precipitation?: number; weather_code?: number; cloud_cover?: number; pressure_msl?: number; wind_speed_10m?: number; wind_direction_10m?: number };
        hourly?: { time?: string[]; temperature_2m?: number[]; precipitation_probability?: number[]; weather_code?: number[]; wind_speed_10m?: number[] };
      };

      if (!raw.current) return null;

      const now = new Date().toISOString();
      const dataSourceInfo: DataSourceInfo = {
        source: this.sourceName,
        provider: "Open-Meteo",
        sourceUrl: "https://open-meteo.com/",
        license: "CC-BY-4.0",
        attribution: "Weather data by Open-Meteo.com (CC-BY-4.0)",
        commercialUse: true,
        sourceUpdatedAt: now,
        dataConfidence: "verified",
        cachedAt: now,
        retrievedAt: now,
      };

      const rawCode = raw.current.weather_code ?? 0;
      const forecastNext6h = raw.hourly?.time?.slice(0, 6).map((time, i) => ({
        time,
        temperatureC: raw.hourly?.temperature_2m?.[i] ?? 0,
        windSpeedKts: Math.round((raw.hourly?.wind_speed_10m?.[i] ?? 0) * 0.539957),
        precipitationProbPct: raw.hourly?.precipitation_probability?.[i] ?? 0,
        weatherCode: String(raw.hourly?.weather_code?.[i] ?? rawCode),
      }));

      const condition: WeatherCondition = {
        temperatureC: raw.current.temperature_2m ?? 0,
        windSpeedKts: Math.round((raw.current.wind_speed_10m ?? 0) * 0.539957),
        windDirectionDeg: raw.current.wind_direction_10m ?? 0,
        cloudCoverPct: raw.current.cloud_cover,
        precipitationMm: raw.current.precipitation,
        humidityPct: raw.current.relative_humidity_2m,
        pressureHpa: raw.current.pressure_msl,
        weatherCode: String(rawCode),
        weatherDescription: this.weatherCodeToDescription(rawCode),
        forecastNext6h,
        dataSourceInfo,
      };

      this.cache.set(cacheKey, { data: condition, cachedAt: Date.now() });
      return condition;
    } catch {
      return null;
    }
  }

  private weatherCodeToDescription(code: number): string {
    const map: Record<number, string> = {
      0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog", 48: "Depositing rime fog",
      51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle", 61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
      71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow", 80: "Slight showers", 81: "Moderate showers", 82: "Violent showers",
      95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Severe thunderstorm with hail",
    };
    return map[code] ?? "Unknown";
  }

  async getCurrentWeather(latitude: number, longitude: number) {
    return this.fetchWeather(latitude, longitude);
  }

  async getAirportWeather(_iata: string) {
    return null;
  }
}

export const weatherProvider: WeatherProvider = new OpenMeteoWeatherProvider();
