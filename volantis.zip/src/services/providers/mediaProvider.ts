import type { MediaAsset } from "@/types/volantis";

export type MediaKind = "airport-photo" | "airline-logo" | "aircraft-photo";

export interface MediaSubject {
  /** IATA/ICAO code for airline/airport lookups */
  code: string;
  name: string;
  /** extra hints that improve query relevance */
  city?: string;
  country?: string;
  aliases?: string[];
}

export interface MediaProviderResult {
  asset: MediaAsset | null;
  /** true when the provider could not be reached (rate-limit/network), distinct from "no asset exists" */
  providerError?: boolean;
  statusCode?: number;
}

export interface MediaProvider {
  readonly name: string;
  findAirportPhoto(subject: MediaSubject): Promise<MediaProviderResult>;
  findAirlineLogo(subject: MediaSubject): Promise<MediaProviderResult>;
  findAircraftPhoto(subject: MediaSubject): Promise<MediaProviderResult>;
}

/**
 * Validates that a Wikimedia result plausibly belongs to the requested entity.
 * Rejects city photos, generic aircraft, unrelated content.
 */
export function resultMatchesSubject(title: string, subject: MediaSubject, kind: MediaKind): boolean {
  const t = title.toLowerCase().replace(/^file:/, "");
  const name = subject.name.toLowerCase();
  const code = subject.code.toLowerCase();
  const aliasHits = (subject.aliases ?? []).some((a) => a && t.includes(a.toLowerCase()));

  const explicitNameHit = t.includes(name) || t.includes(code) || aliasHits;
  if (!explicitNameHit) return false;

  const badTokens = ["map", "diagram", "route map", "chart", "table", "logo of a", "cockpit", "plan", "scheme", "emblem of a city", "flag of"];
  if (badTokens.some((b) => t.includes(b))) return false;

  if (kind === "airport-photo") {
    const airportTokens = ["airport", "terminal", "aerodrome", "runway", "aeroporto", "flughafen", "aéroport", "international"];
    const hasAirport = airportTokens.some((tok) => t.includes(tok));
    const notAirport = ["museum", "park", "stadium", "hotel", "castle", "cathedral"].some((tok) => t.includes(tok));
    if (notAirport) return false;
    return hasAirport || explicitNameHit;
  }

  if (kind === "airline-logo") {
    const logoTokens = ["logo", "svg", "brand", "emblem", "mark"];
    return logoTokens.some((tok) => t.includes(tok)) || explicitNameHit;
  }

  if (kind === "aircraft-photo") {
    const aircraftTokens = ["aircraft", "airplane", "jet", "airbus", "boeing", "landing", "takeoff", "taxiway", "liner", "plane"];
    return aircraftTokens.some((tok) => t.includes(tok)) || explicitNameHit;
  }

  return true;
}

export function normalizeLicense(raw: string | undefined): { normalized: string; commercialOk: boolean } {
  const val = (raw ?? "Unknown").trim();
  const upper = val.toUpperCase().replace(/[^A-Z0-9. /-]/g, "");
  const freeTokens = ["PUBLIC DOMAIN", "PUBLICDOMAIN", "PD", "CC0", "CC BY", "CC-BY", "CC BY-SA", "CC-BY-SA", "GFDL", "ODBL"];
  const commercialOk = freeTokens.some((tok) => upper.includes(tok));
  return { normalized: val, commercialOk };
}
