import { buildRouteSegments, resolveAircraftPosition } from "@/lib/geo";
import type { Coordinate, Flight } from "@/types/volantis";

export type FlightRouteTelemetry = {
  aircraft: ReturnType<typeof resolveAircraftPosition>;
  fullRoute: Coordinate[];
  completedRoute: Coordinate[];
  remainingRoute: Coordinate[];
  origin: Coordinate;
  destination: Coordinate;
};

export function getFlightRouteTelemetry(flight: Flight): FlightRouteTelemetry {
  const segments = buildRouteSegments(flight);
  return {
    aircraft: segments.resolution,
    fullRoute: segments.full,
    completedRoute: segments.completed,
    remainingRoute: segments.remaining,
    origin: flight.origin,
    destination: flight.destination,
  };
}

export function coordinatesToLngLat(coordinates: Coordinate[]) {
  return coordinates.map((coordinate) => [coordinate.longitude, coordinate.latitude] as [number, number]);
}

export function getAircraftTelemetrySnapshot(flight: Flight) {
  const aircraft = resolveAircraftPosition(flight);
  return {
    source: aircraft.source,
    label: aircraft.label,
    latitude: aircraft.position.latitude,
    longitude: aircraft.position.longitude,
    progressPercent: aircraft.progressPercent,
    remainingDistanceKm: aircraft.remainingDistanceKm,
    altitudeFt: flight.telemetry?.altitudeFt,
    groundSpeedKt: flight.telemetry?.groundSpeedKt,
    headingDeg: aircraft.headingDeg,
    eta: aircraft.eta,
    reportedAt: flight.telemetry?.reportedAt ?? flight.lastUpdatedUtc,
    freshnessSeconds: flight.telemetry?.freshnessSeconds,
    isAuthoritativeLive: aircraft.isAuthoritativeLive,
  };
}
