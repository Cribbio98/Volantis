import { createDemoFlights } from "@/data/demoFlights";
import { resolveAircraftPosition } from "@/lib/geo";
import { getCachedFlights, saveFlightsToCache } from "@/services/repositories/flightCacheRepository";
import { repositoryProvider } from "@/services/repositoryProvider";
import type { DataSourceState, Flight, FlightDashboard } from "@/types/volantis";

function scoreFlight(flight: Flight) {
  const statusScore: Record<string, number> = {
    EnRoute: 0,
    Boarding: 1,
    GateClosed: 2,
    CheckIn: 3,
    Delayed: 4,
    Expected: 5,
    Departed: 6,
    Approaching: 7,
    Arrived: 90,
    Canceled: 100,
    Diverted: 80,
    Unknown: 50,
    CanceledUncertain: 95,
  };
  return [statusScore[flight.status] ?? 50, new Date(flight.scheduledDeparture).getTime()] as const;
}

export function orderFlights(flights: Flight[]) {
  return [...flights].sort((a, b) => {
    const [aScore, aTime] = scoreFlight(a);
    const [bScore, bTime] = scoreFlight(b);
    if (aScore !== bScore) return aScore - bScore;
    return aTime - bTime;
  });
}

function refreshMetrics(flight: Flight): Flight {
  const resolution = resolveAircraftPosition(flight);
  return {
    ...flight,
    dataSource: resolution.source === "LIVE_DATA" ? "LIVE_DATA" : flight.dataSource,
    progressPercent: resolution.progressPercent,
    remainingDistanceKm: resolution.remainingDistanceKm,
    eta: resolution.eta,
  };
}

function dashboardFromFlights(flights: Flight[], dataSource: DataSourceState, offline: boolean): FlightDashboard {
  const ordered = orderFlights(flights.map(refreshMetrics));
  const fallback = createDemoFlights()[0];
  return {
    nextFlight: ordered[0] ?? fallback,
    flights: ordered.length > 0 ? ordered : [fallback],
    dataSource,
    offline,
    updatedAt: new Date().toISOString(),
  };
}

export async function getFlightDashboard(): Promise<FlightDashboard> {
  const primaryRepository = repositoryProvider.flightRepository();

  try {
    const flights = await primaryRepository.getDashboardFlights();
    if (flights.length > 0) {
      await saveFlightsToCache(flights);
      const source = flights.some((flight) => flight.dataSource === "LIVE_DATA")
        ? "LIVE_DATA"
        : flights[0]?.dataSource ?? "ESTIMATED_POSITION";
      return dashboardFromFlights(flights, source, false);
    }
  } catch (error) {
    console.warn("Primary flight repository unavailable", error);
  }

  const cached = await getCachedFlights();
  if (cached.length > 0) {
    return dashboardFromFlights(cached, "OFFLINE_CACHED", true);
  }

  const fallbackFlights = await repositoryProvider.fallbackFlightRepository().getDashboardFlights();
  return dashboardFromFlights(fallbackFlights, "DEMO_DATA", false);
}

export async function getFlightByNumber(flightNumber: string, dateLocal?: string): Promise<Flight | null> {
  const primaryRepository = repositoryProvider.flightRepository();

  try {
    const flight = await primaryRepository.getFlightByNumber(flightNumber, dateLocal);
    if (flight) {
      await saveFlightsToCache([flight]);
      return refreshMetrics(flight);
    }
  } catch (error) {
    console.warn("Primary flight lookup unavailable", error);
  }

  const normalized = flightNumber.replace(/\s+/g, "").toUpperCase();
  const cached = await getCachedFlights();
  const cachedFlight = cached.find((flight) => flight.flightNumber.replace(/\s+/g, "").toUpperCase() === normalized);
  if (cachedFlight) {
    return refreshMetrics(cachedFlight);
  }

  const fallback = await repositoryProvider.fallbackFlightRepository().getFlightByNumber(flightNumber, dateLocal);
  return fallback ? refreshMetrics(fallback) : null;
}
