import { findAirport as findFallbackAirport } from "@/data/airports";
import { getAirportFromDb } from "@/services/dataProviders/ourAirportsProvider";
import { resolveAirportPhoto } from "@/services/repositories/mediaCacheRepository";
import type { MediaAsset } from "@/types/volantis";

/**
 * Airport photo retrieval is database-cache-first with negative caching and TTL
 * revalidation. Wikimedia is queried only once per airport per TTL window via the
 * provider chain, never on every render.
 */
export async function getAirportPhoto(airportIata: string): Promise<MediaAsset | null> {
  const dbAirport = await getAirportFromDb(airportIata);
  const airport = dbAirport ?? findFallbackAirport(airportIata);
  if (!airport) return null;
  return resolveAirportPhoto(airport.iata, airport.name, {
    city: airport.city,
    country: airport.countryIso,
    icao: airport.icao,
  });
}
