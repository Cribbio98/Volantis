import type { Aircraft3DAsset, RenderedAircraft, AirlineLivery, Aircraft } from "@/types/volantis";

const assetRegistry: Aircraft3DAsset[] = [
  { icaoType: "A320", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet. Using CSS silhouette as fallback. Contribute a CC0/CC-BY model to replace this." },
  { icaoType: "A321", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "A330", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "A350", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "A380", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "B737", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "B744", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "B777", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "B787", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "E190", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "E195", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
  { icaoType: "AT72", assetUrl: "", format: "glb", license: "pending", isApproximate: true, sourceName: "none", attribution: "No free GLB asset found yet." },
];

const byIcao = new Map(assetRegistry.map((a) => [a.icaoType.toUpperCase(), a]));

const fallbackAsset: Aircraft3DAsset = {
  icaoType: "UNKNOWN",
  assetUrl: "",
  format: "glb",
  license: "pending",
  isApproximate: true,
  sourceName: "none",
  attribution: "Fallback. No 3D model registered for this aircraft type. Using CSS silhouette.",
};

export interface AircraftAssetRepository {
  findByIcaoType(icaoType: string): Aircraft3DAsset;
  registerAsset(asset: Aircraft3DAsset): void;
  getAllRegistered(): Aircraft3DAsset[];
}

class DefaultAircraftAssetRepository implements AircraftAssetRepository {
  findByIcaoType(icaoType: string) {
    const normalized = icaoType.replace(/[^A-Z0-9]/gi, "").toUpperCase();
    return byIcao.get(normalized) ?? byIcao.get(normalized.slice(0, 3)) ?? fallbackAsset;
  }
  registerAsset(asset: Aircraft3DAsset) {
    byIcao.set(asset.icaoType.toUpperCase(), asset);
  }
  getAllRegistered() {
    return Array.from(byIcao.values());
  }
}

export const aircraftAssetRepository: AircraftAssetRepository = new DefaultAircraftAssetRepository();

const liveryCache = new Map<string, AirlineLivery>();

export interface LiveryRepository {
  getLivery(airlineIata: string): AirlineLivery | undefined;
  setLivery(airlineIata: string, livery: AirlineLivery): void;
  renderAircraft(aircraft: Aircraft, airlineIata: string): RenderedAircraft;
}

class DefaultLiveryRepository implements LiveryRepository {
  getLivery(airlineIata: string) {
    return liveryCache.get(airlineIata.toUpperCase());
  }
  setLivery(airlineIata: string, livery: AirlineLivery) {
    liveryCache.set(airlineIata.toUpperCase(), livery);
  }
  renderAircraft(aircraft: Aircraft, airlineIata: string): RenderedAircraft {
    const icaoType = aircraft.icaoType ?? "";
    const asset = aircraftAssetRepository.findByIcaoType(icaoType);
    const livery = this.getLivery(airlineIata);

    const effectiveLiveryNote = livery?.isOfficial
      ? "Airline-specific livery applied from verified source."
      : livery
        ? "Livery data is approximate/inferred and not from an official source. Correct geometry takes priority over livery accuracy."
        : "No airline-specific livery data available. Using default aircraft geometry. Correct geometry always takes priority over livery.";

    return { aircraft: asset, livery: livery ?? undefined, effectiveLiveryNote };
  }
}

export const liveryRepository: LiveryRepository = new DefaultLiveryRepository();
