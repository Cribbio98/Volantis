import { airlineRegistry, findAirline as findAirlineFallback, resolveAirline as resolveAirlineFallback } from "@/data/airlines";
import { getAirlineFromDb, searchAirlinesFromDb } from "@/services/dataProviders/openFlightsProvider";
import type { Airline } from "@/types/volantis";

export interface AirlineRepository {
  findByIata(iata: string): Promise<Airline | null>;
  findByIcao(icao: string): Promise<Airline | null>;
  search(query: { iata?: string; icao?: string; name?: string; country?: string }, limit?: number): Promise<Airline[]>;
  resolve(input: { name?: string | null; iata?: string | null; icao?: string | null }): Promise<Airline>;
  getAll(): Airline[];
}

class FallbackAirlineRepository implements AirlineRepository {
  async findByIata(iata: string) {
    return findAirlineFallback(iata) ?? null;
  }
  async findByIcao(icao: string) {
    return findAirlineFallback(icao) ?? null;
  }
  async search(query: { iata?: string; icao?: string; name?: string; country?: string }, _limit?: number) {
    if (query.iata) {
      const airline = findAirlineFallback(query.iata);
      return airline ? [airline] : [];
    }
    return [];
  }
  async resolve(input: { name?: string | null; iata?: string | null; icao?: string | null }) {
    return resolveAirlineFallback(input);
  }
  getAll() {
    return airlineRegistry;
  }
}

class DbAirlineRepository implements AirlineRepository {
  async findByIata(iata: string) {
    const dbAirline = await getAirlineFromDb(iata);
    if (dbAirline) return dbAirline;
    return findAirlineFallback(iata) ?? null;
  }
  async findByIcao(icao: string) {
    const results = await searchAirlinesFromDb({ icao }, 1);
    if (results.length > 0) return results[0];
    return findAirlineFallback(icao) ?? null;
  }
  async search(query: { iata?: string; icao?: string; name?: string; country?: string }, limit?: number) {
    const dbResults = await searchAirlinesFromDb(query, limit);
    if (dbResults.length > 0) return dbResults;
    if (query.iata) {
      const fallback = findAirlineFallback(query.iata);
      return fallback ? [fallback] : [];
    }
    return [];
  }
  async resolve(input: { name?: string | null; iata?: string | null; icao?: string | null }) {
    if (input.iata) {
      const dbAirline = await getAirlineFromDb(input.iata);
      if (dbAirline) return dbAirline;
    }
    return resolveAirlineFallback(input);
  }
  getAll() {
    return airlineRegistry;
  }
}

let _repository: AirlineRepository | null = null;

export function getAirlineRepository(): AirlineRepository {
  if (_repository) return _repository;
  const useDb = process.env.VOLANTIS_USE_DB_AIRLINES !== "false";
  _repository = useDb ? new DbAirlineRepository() : new FallbackAirlineRepository();
  return _repository;
}

export function setAirlineRepository(repository: AirlineRepository) {
  _repository = repository;
}
