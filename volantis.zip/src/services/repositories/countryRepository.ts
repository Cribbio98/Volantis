import { findCountry, getAllCountries, getCountryByAlpha2, getCountryByAlpha3, getFlagSvgUrl } from "@/services/dataProviders/countryProvider";
import type { Country } from "@/types/volantis";

export interface CountryRepository {
  findByAlpha2(code: string): Country | undefined;
  findByAlpha3(code: string): Country | undefined;
  find(input?: string): Country | undefined;
  getAll(): Country[];
  flagSvgUrl(isoAlpha2: string): string;
}

class DefaultCountryRepository implements CountryRepository {
  findByAlpha2(code: string) {
    return getCountryByAlpha2(code);
  }
  findByAlpha3(code: string) {
    return getCountryByAlpha3(code);
  }
  find(input?: string) {
    return findCountry(input);
  }
  getAll() {
    return getAllCountries();
  }
  flagSvgUrl(isoAlpha2: string) {
    return getFlagSvgUrl(isoAlpha2);
  }
}

export const countryRepository: CountryRepository = new DefaultCountryRepository();
