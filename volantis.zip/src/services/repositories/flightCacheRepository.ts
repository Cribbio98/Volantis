import { db } from "@/db";
import { sql } from "drizzle-orm";
import type { Flight } from "@/types/volantis";

async function ensureCacheTable() {
  await db.execute(sql`
    create table if not exists volantis_flight_cache (
      flight_number text primary key,
      payload jsonb not null,
      source text not null,
      updated_at timestamptz not null default now()
    )
  `);
}

export async function saveFlightsToCache(flights: Flight[]) {
  if (flights.length === 0) return;

  try {
    await ensureCacheTable();
    for (const flight of flights) {
      await db.execute(sql`
        insert into volantis_flight_cache (flight_number, payload, source, updated_at)
        values (${flight.flightNumber}, ${JSON.stringify(flight)}::jsonb, ${flight.dataSource}, now())
        on conflict (flight_number)
        do update set payload = excluded.payload, source = excluded.source, updated_at = now()
      `);
    }
  } catch (error) {
    console.warn("Volantis cache write skipped", error);
  }
}

export async function getCachedFlights(limit = 12): Promise<Flight[]> {
  try {
    await ensureCacheTable();
    const result = await db.execute(sql`
      select payload
      from volantis_flight_cache
      order by updated_at desc
      limit ${limit}
    `);

    return result.rows
      .map((row) => row.payload as Flight | undefined)
      .filter((flight): flight is Flight => Boolean(flight))
      .map((flight) => ({
        ...flight,
        dataSource: "OFFLINE_CACHED" as const,
        telemetry: flight.telemetry ? { ...flight.telemetry, source: "OFFLINE_CACHED" as const } : undefined,
      }));
  } catch (error) {
    console.warn("Volantis cache read skipped", error);
    return [];
  }
}
