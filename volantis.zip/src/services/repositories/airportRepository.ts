import { findAirport as findAirportFallback, airportRegistry } from "@/data/airports";
import { getAirportFromDb, searchAirportsFromDb } from "@/services/dataProviders/ourAirportsProvider";
import type { Airport } from "@/types/volantis";

export interface AirportRepository {
  findByIata(iata: string): Promise<Airport | null>;
  findByIcao(icao: string): Promise<Airport | null>;
  search(query: { iata?: string; icao?: string; name?: string; city?: string; country?: string }, limit?: number): Promise<Airport[]>;
  getAll(): Airport[];
}

class FallbackAirportRepository implements AirportRepository {
  async findByIata(iata: string) {
    return findAirportFallback(iata) ?? null;
  }
  async findByIcao(_icao: string) {
    return null;
  }
  async search(query: { iata?: string; icao?: string; name?: string; city?: string; country?: string }, _limit?: number) {
    if (query.iata) {
      const airport = findAirportFallback(query.iata);
      return airport ? [airport] : [];
    }
    return [];
  }
  getAll() {
    return airportRegistry;
  }
}

class DbAirportRepository implements AirportRepository {
  async findByIata(iata: string) {
    const dbAirport = await getAirportFromDb(iata);
    if (dbAirport) return dbAirport;
    return findAirportFallback(iata) ?? null;
  }
  async findByIcao(icao: string) {
    const results = await searchAirportsFromDb({ icao }, 1);
    if (results.length > 0) return results[0];
    return null;
  }
  async search(query: { iata?: string; icao?: string; name?: string; city?: string; country?: string }, limit?: number) {
    const dbResults = await searchAirportsFromDb(query, limit);
    if (dbResults.length > 0) return dbResults;
    if (query.iata) {
      const fallback = findAirportFallback(query.iata);
      return fallback ? [fallback] : [];
    }
    return [];
  }
  getAll() {
    return airportRegistry;
  }
}

let _repository: AirportRepository | null = null;

export function getAirportRepository(): AirportRepository {
  if (_repository) return _repository;
  const useDb = process.env.VOLANTIS_USE_DB_AIRPORTS !== "false";
  _repository = useDb ? new DbAirportRepository() : new FallbackAirportRepository();
  return _repository;
}

export function setAirportRepository(repository: AirportRepository) {
  _repository = repository;
}
