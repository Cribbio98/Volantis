import type { Flight } from "@/types/volantis";

export type FlightSearchOptions = {
  flightNumber?: string;
  dateLocal?: string;
};

export interface FlightRepository {
  readonly sourceName: string;
  getDashboardFlights(): Promise<Flight[]>;
  getFlightByNumber(flightNumber: string, dateLocal?: string): Promise<Flight | null>;
}
