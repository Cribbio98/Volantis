import { createDemoFlights } from "@/data/demoFlights";
import type { FlightRepository } from "@/services/repositories/flightRepository";

function normalizeFlightNumber(value: string) {
  return value.replace(/\s+/g, "").toUpperCase();
}

export class MockFlightRepository implements FlightRepository {
  readonly sourceName = "mock";

  async getDashboardFlights() {
    return createDemoFlights();
  }

  async getFlightByNumber(flightNumber: string) {
    const normalized = normalizeFlightNumber(flightNumber);
    return createDemoFlights().find((flight) => normalizeFlightNumber(flight.flightNumber) === normalized) ?? null;
  }
}
