import { db } from "@/db";
import { sql } from "drizzle-orm";
import { mediaProviderChain } from "@/services/providers/mediaProviderChain";
import type { MediaSubject } from "@/services/providers/mediaProvider";
import type { MediaAsset } from "@/types/volantis";

export type MediaSubjectType = "airport-photo" | "airline-logo" | "aircraft-photo";

const POSITIVE_CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const NEGATIVE_CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

let tableEnsured = false;

async function ensureMediaTable() {
  if (tableEnsured) return;
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS volantis_media_assets (
      id SERIAL PRIMARY KEY,
      media_type VARCHAR(32) NOT NULL,
      subject_code VARCHAR(64) NOT NULL,
      subject_name VARCHAR(180),
      url TEXT,
      thumbnail_url TEXT,
      source_page_url TEXT,
      author TEXT,
      license VARCHAR(96),
      attribution TEXT,
      commercial_use BOOLEAN DEFAULT FALSE,
      found BOOLEAN DEFAULT FALSE,
      provider VARCHAR(48),
      retrieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(media_type, subject_code)
    )
  `);
  await db.execute(sql`ALTER TABLE volantis_media_assets ADD COLUMN IF NOT EXISTS provider VARCHAR(48)`).catch(() => {});
  tableEnsured = true;
}

interface CachedRow {
  url: string | null;
  thumbnail_url: string | null;
  source_page_url: string | null;
  author: string | null;
  license: string | null;
  attribution: string | null;
  commercial_use: boolean | null;
  found: boolean;
  provider: string | null;
  retrieved_at: Date;
}

async function readCache(mediaType: MediaSubjectType, subjectCode: string): Promise<{ asset: MediaAsset | null; fresh: boolean } | null> {
  try {
    await ensureMediaTable();
    const result = await db.execute(sql`
      SELECT url, thumbnail_url, source_page_url, author, license, attribution, commercial_use, found, provider, retrieved_at
      FROM volantis_media_assets
      WHERE media_type = ${mediaType} AND subject_code = ${subjectCode.toUpperCase()}
      LIMIT 1
    `);
    if (result.rows.length === 0) return null;

    const row = result.rows[0] as unknown as CachedRow;
    const age = Date.now() - new Date(row.retrieved_at).getTime();
    const ttl = row.found ? POSITIVE_CACHE_TTL_MS : NEGATIVE_CACHE_TTL_MS;
    const fresh = age < ttl;

    if (row.found && row.url) {
      return {
        fresh,
        asset: {
          url: row.url,
          thumbnailUrl: row.thumbnail_url ?? undefined,
          sourcePageUrl: row.source_page_url ?? undefined,
          author: row.author ?? undefined,
          license: row.license ?? "Unknown",
          attribution: row.attribution ?? undefined,
          commercialUse: row.commercial_use === true,
          retrievedAt: new Date(row.retrieved_at).toISOString(),
        },
      };
    }
    return { fresh, asset: null };
  } catch {
    return null;
  }
}

async function writeCache(mediaType: MediaSubjectType, subjectCode: string, subjectName: string, provider: string, asset: MediaAsset | null) {
  try {
    await ensureMediaTable();
    await db.execute(sql`
      INSERT INTO volantis_media_assets (media_type, subject_code, subject_name, url, thumbnail_url, source_page_url, author, license, attribution, commercial_use, found, provider, retrieved_at)
      VALUES (${mediaType}, ${subjectCode.toUpperCase()}, ${subjectName}, ${asset?.url ?? null}, ${asset?.thumbnailUrl ?? null}, ${asset?.sourcePageUrl ?? null}, ${asset?.author ?? null}, ${asset?.license ?? null}, ${asset?.attribution ?? null}, ${asset?.commercialUse ?? false}, ${asset !== null}, ${provider}, NOW())
      ON CONFLICT (media_type, subject_code) DO UPDATE SET
        subject_name = EXCLUDED.subject_name,
        url = EXCLUDED.url,
        thumbnail_url = EXCLUDED.thumbnail_url,
        source_page_url = EXCLUDED.source_page_url,
        author = EXCLUDED.author,
        license = EXCLUDED.license,
        attribution = EXCLUDED.attribution,
        commercial_use = EXCLUDED.commercial_use,
        found = EXCLUDED.found,
        provider = EXCLUDED.provider,
        retrieved_at = NOW()
    `);
  } catch (error) {
    console.warn("Volantis media cache write skipped", error);
  }
}

async function resolve(kind: MediaSubjectType, subject: MediaSubject, opts?: { forceRefresh?: boolean }): Promise<MediaAsset | null> {
  if (!opts?.forceRefresh) {
    const cached = await readCache(kind, subject.code);
    if (cached?.fresh) return cached.asset;
  }

  // Keep a reference to a stale cached asset as a fallback if the live call fails.
  const fallback = (await readCache(kind, subject.code))?.asset ?? null;

  try {
    const { asset, provider } = await mediaProviderChain.find(kind, subject);
    await writeCache(kind, subject.code, subject.name, provider, asset);
    return asset;
  } catch {
    // Cache provider errors too, so we don't hammer a failing provider.
    if (fallback) return fallback;
    return null;
  }
}

export async function resolveAirportPhoto(iata: string, airportName: string, extras?: { city?: string; country?: string; icao?: string; forceRefresh?: boolean }): Promise<MediaAsset | null> {
  return resolve("airport-photo", {
    code: iata,
    name: airportName,
    city: extras?.city,
    country: extras?.country,
    aliases: extras?.icao ? [extras.icao] : undefined,
  }, { forceRefresh: extras?.forceRefresh });
}

export async function resolveAirlineLogo(iata: string, airlineName: string, extras?: { icao?: string; forceRefresh?: boolean }): Promise<MediaAsset | null> {
  return resolve("airline-logo", {
    code: iata,
    name: airlineName,
    aliases: extras?.icao ? [extras.icao] : undefined,
  }, { forceRefresh: extras?.forceRefresh });
}

export async function invalidateCache(kind: MediaSubjectType, code: string) {
  try {
    await ensureMediaTable();
    await db.execute(sql`DELETE FROM volantis_media_assets WHERE media_type = ${kind} AND subject_code = ${code.toUpperCase()}`);
  } catch {}
}

export async function resolveAircraftPhoto(manufacturer: string, model: string): Promise<MediaAsset | null> {
  const code = `${manufacturer}-${model}`.replace(/[^A-Z0-9-]/gi, "-").toUpperCase().slice(0, 60);
  return resolve("aircraft-photo", { code, name: model });
}

export async function getMediaStats() {
  try {
    await ensureMediaTable();
    const result = await db.execute(sql`
      SELECT media_type, provider, COUNT(*) FILTER (WHERE found) AS found, COUNT(*) AS total
      FROM volantis_media_assets
      GROUP BY media_type, provider
    `);
    return result.rows as unknown as Array<{ media_type: string; provider: string; found: number; total: number }>;
  } catch {
    return [];
  }
}

export async function getCachedAsset(kind: MediaSubjectType, code: string): Promise<MediaAsset | null> {
  const row = await readCache(kind, code);
  return row?.asset ?? null;
}
