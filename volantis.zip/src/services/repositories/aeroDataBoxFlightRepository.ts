import { aircraftFamilyFromType, findAircraftSpecs } from "@/data/aircraft";
import { resolveAirline } from "@/data/airlines";
import { resolveAirport } from "@/data/airports";
import { getOptionalEnv } from "@/lib/env";
import { bearingDegrees, calculateRouteProgress, calculateTemporalProgress, haversineDistanceKm } from "@/lib/geo";
import type { FlightRepository } from "@/services/repositories/flightRepository";
import type { Aircraft, DataSourceState, Flight, FlightStatus, FlightTelemetry, FlightTimelineEvent } from "@/types/volantis";

type ClientConfig = {
  baseUrl: string;
  headers: Record<string, string>;
  configured: boolean;
};

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return typeof value === "object" && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : undefined;
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function stringAt(record: Record<string, unknown> | undefined, key: string) {
  const value = record?.[key];
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : undefined;
}

function numberAt(record: Record<string, unknown> | undefined, key: string) {
  const value = record?.[key];
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function recordAt(record: Record<string, unknown> | undefined, key: string) {
  return asRecord(record?.[key]);
}

function normalizeStatus(value?: string): FlightStatus {
  const known: FlightStatus[] = [
    "Unknown",
    "Expected",
    "EnRoute",
    "CheckIn",
    "Boarding",
    "GateClosed",
    "Departed",
    "Delayed",
    "Approaching",
    "Arrived",
    "Canceled",
    "Diverted",
    "CanceledUncertain",
  ];
  return known.find((status) => status.toLowerCase() === value?.toLowerCase()) ?? "Unknown";
}

function getIsoTime(movement: Record<string, unknown> | undefined, key: string) {
  const time = recordAt(movement, key);
  const value = stringAt(time, "utc") ?? stringAt(time, "local");
  return value ? new Date(value).toISOString() : undefined;
}

function firstIsoTime(movement: Record<string, unknown> | undefined, keys: string[]) {
  for (const key of keys) {
    const value = getIsoTime(movement, key);
    if (value) return value;
  }
  return undefined;
}

function distanceFeet(distance: Record<string, unknown> | undefined) {
  const feet = numberAt(distance, "ft") ?? numberAt(distance, "feet");
  if (typeof feet === "number") return feet;
  const meters = numberAt(distance, "m") ?? numberAt(distance, "meter") ?? numberAt(distance, "meters");
  return typeof meters === "number" ? meters * 3.28084 : undefined;
}

function speedKnots(speed: Record<string, unknown> | undefined) {
  return numberAt(speed, "kt") ?? numberAt(speed, "knots") ?? numberAt(speed, "kts");
}

function trackDegrees(track: Record<string, unknown> | undefined) {
  return numberAt(track, "deg") ?? numberAt(track, "degrees");
}

function movementAirport(movement: Record<string, unknown> | undefined) {
  const airport = recordAt(movement, "airport");
  const location = recordAt(airport, "location");
  return resolveAirport({
    iata: stringAt(airport, "iata"),
    icao: stringAt(airport, "icao"),
    name: stringAt(airport, "name") ?? stringAt(airport, "shortName"),
    city: stringAt(airport, "municipalityName"),
    country: stringAt(airport, "countryCode"),
    latitude: numberAt(location, "lat"),
    longitude: numberAt(location, "lon"),
    timezone: stringAt(airport, "timeZone"),
  });
}

function aircraftFrom(raw: Record<string, unknown> | undefined): Aircraft {
  const model =
    stringAt(raw, "model") ??
    stringAt(raw, "typeName") ??
    stringAt(raw, "icaoCode") ??
    stringAt(raw, "icaoType") ??
    stringAt(raw, "type") ??
    "Unknown aircraft";
  const image = recordAt(raw, "image");
  const specs = findAircraftSpecs(model);

  return {
    type: model,
    family: aircraftFamilyFromType(model),
    manufacturer: specs?.manufacturer ?? stringAt(raw, "manufacturer") ?? "Unknown",
    registration: stringAt(raw, "reg") ?? stringAt(raw, "registration") ?? stringAt(raw, "tailNumber"),
    icaoType: stringAt(raw, "icaoCode") ?? stringAt(raw, "icaoType"),
    imageUrl: stringAt(image, "url"),
    imageAttribution: stringAt(image, "author") ?? stringAt(image, "attribution"),
    specs,
  };
}

function telemetryFrom(location: Record<string, unknown> | undefined): FlightTelemetry | undefined {
  const latitude = numberAt(location, "lat");
  const longitude = numberAt(location, "lon");

  if (typeof latitude !== "number" || typeof longitude !== "number") {
    return undefined;
  }

  const reportedAt = stringAt(location, "reportedAtUtc") ?? stringAt(location, "updatedUtc") ?? new Date().toISOString();
  const reportedAtMs = new Date(reportedAt).getTime();
  const freshnessSeconds = Number.isFinite(reportedAtMs) ? Math.max(0, Math.round((Date.now() - reportedAtMs) / 1000)) : undefined;

  return {
    // Exact values supplied by AeroDataBox location are preserved here. Downstream map
    // rendering treats these coordinates as authoritative when source is LIVE_DATA.
    latitude,
    longitude,
    altitudeFt: distanceFeet(recordAt(location, "altitude")) ?? distanceFeet(recordAt(location, "pressureAltitude")),
    groundSpeedKt: speedKnots(recordAt(location, "groundSpeed")),
    headingDeg: trackDegrees(recordAt(location, "trueTrack")) ?? numberAt(location, "track") ?? numberAt(location, "heading"),
    reportedAt: new Date(reportedAt).toISOString(),
    freshnessSeconds,
    source: "LIVE_DATA",
  };
}

function buildTimeline(status: FlightStatus, departure: string, arrival: string): FlightTimelineEvent[] {
  const departMs = new Date(departure).getTime();
  const eventAt = (minutes: number) => new Date(departMs + minutes * 60_000).toISOString();
  const airborne = ["EnRoute", "Departed", "Approaching", "Arrived"].includes(status);
  return [
    { label: "Scheduled", at: departure, state: "complete", detail: "Schedule from provider" },
    { label: "Check-in", at: eventAt(-180), state: status === "CheckIn" ? "active" : airborne ? "complete" : "upcoming" },
    { label: "Boarding", at: eventAt(-45), state: status === "Boarding" ? "active" : airborne ? "complete" : "upcoming" },
    { label: "Gate", at: eventAt(-20), state: status === "GateClosed" ? "active" : airborne ? "complete" : "upcoming" },
    { label: "Takeoff", at: departure, state: airborne ? "complete" : "upcoming" },
    { label: "Cruise", at: eventAt(55), state: status === "EnRoute" ? "active" : status === "Arrived" ? "complete" : "upcoming" },
    { label: "Arrival", at: arrival, state: status === "Arrived" ? "complete" : "upcoming" },
  ];
}

function mapAeroDataBoxFlight(rawValue: unknown, fallbackNumber?: string): Flight | null {
  const raw = asRecord(rawValue);
  if (!raw) return null;

  const departure = recordAt(raw, "departure");
  const arrival = recordAt(raw, "arrival");
  const origin = movementAirport(departure);
  const destination = movementAirport(arrival);
  const airlineRaw = recordAt(raw, "airline");
  const airline = resolveAirline({
    name: stringAt(airlineRaw, "name"),
    iata: stringAt(airlineRaw, "iata"),
    icao: stringAt(airlineRaw, "icao"),
  });
  const aircraft = aircraftFrom(recordAt(raw, "aircraft"));
  const telemetry = telemetryFrom(recordAt(raw, "location"));
  const scheduledDeparture = firstIsoTime(departure, ["scheduledTime", "predictedTime", "revisedTime", "actualTime"]);
  const scheduledArrival = firstIsoTime(arrival, ["scheduledTime", "predictedTime", "revisedTime", "actualTime"]);

  if (!scheduledDeparture || !scheduledArrival) {
    return null;
  }

  const estimatedDeparture = firstIsoTime(departure, ["revisedTime", "predictedTime"]);
  const estimatedArrival = firstIsoTime(arrival, ["revisedTime", "predictedTime"]);
  const actualDeparture = firstIsoTime(departure, ["actualTime", "runwayTime"]);
  const actualArrival = firstIsoTime(arrival, ["actualTime", "runwayTime"]);
  const status = normalizeStatus(stringAt(raw, "status"));
  const distanceRaw = recordAt(raw, "greatCircleDistance");
  const distanceKm = numberAt(distanceRaw, "km") ?? numberAt(distanceRaw, "kilometer") ?? numberAt(distanceRaw, "kilometers") ?? haversineDistanceKm(origin, destination);
  const durationMinutes = Math.max(
    1,
    Math.round((new Date(scheduledArrival).getTime() - new Date(scheduledDeparture).getTime()) / 60_000),
  );
  const progress = telemetry
    ? calculateRouteProgress(origin, destination, telemetry)
    : calculateTemporalProgress(actualDeparture ?? estimatedDeparture ?? scheduledDeparture, estimatedArrival ?? actualArrival ?? scheduledArrival);
  const heading = telemetry?.headingDeg ?? bearingDegrees(origin, destination);
  const source: DataSourceState = telemetry ? "LIVE_DATA" : "ESTIMATED_POSITION";
  const flightNumber = stringAt(raw, "number") ?? fallbackNumber ?? `${airline.iata}----`;

  return {
    id: `${flightNumber.replace(/\s+/g, "")}-${scheduledDeparture}`,
    airline,
    flightNumber,
    callSign: stringAt(raw, "callSign"),
    status,
    origin,
    destination,
    scheduledDeparture,
    scheduledArrival,
    estimatedDeparture,
    estimatedArrival,
    actualDeparture,
    actualArrival,
    terminal: stringAt(departure, "terminal"),
    gate: stringAt(departure, "gate"),
    arrivalTerminal: stringAt(arrival, "terminal"),
    arrivalGate: stringAt(arrival, "gate"),
    boarding: {
      startsAt: stringAt(departure, "boardingTime") ?? undefined,
      notes: stringAt(departure, "checkInDesk") ? `Check-in ${stringAt(departure, "checkInDesk")}` : undefined,
    },
    aircraft,
    telemetry: telemetry ? { ...telemetry, headingDeg: telemetry.headingDeg ?? heading } : undefined,
    lastUpdatedUtc: stringAt(raw, "lastUpdatedUtc") ?? new Date().toISOString(),
    dataSource: source,
    distanceKm,
    durationMinutes,
    progressPercent: Math.round(progress * 100),
    remainingDistanceKm: Math.max(0, distanceKm * (1 - progress)),
    eta: estimatedArrival ?? scheduledArrival,
    timeline: buildTimeline(status, actualDeparture ?? estimatedDeparture ?? scheduledDeparture, estimatedArrival ?? actualArrival ?? scheduledArrival),
  };
}

export function createAeroDataBoxClientConfig(): ClientConfig {
  const explicitBase = getOptionalEnv("AERODATABOX_API_BASE_URL");
  const rapidKey = getOptionalEnv("AERODATABOX_RAPIDAPI_KEY") ?? getOptionalEnv("RAPIDAPI_KEY");
  const apiMarketKey = getOptionalEnv("AERODATABOX_API_KEY") ?? getOptionalEnv("API_MARKET_KEY");
  const useRapid = Boolean(explicitBase?.includes("rapidapi") || (rapidKey && !apiMarketKey));
  const key = useRapid ? rapidKey ?? apiMarketKey : apiMarketKey ?? rapidKey;
  const baseUrl = explicitBase ?? (useRapid ? "https://aerodatabox.p.rapidapi.com" : "https://prod.api.market/api/v1/aedbx/aerodatabox");

  if (!key) {
    return { baseUrl, headers: {}, configured: false };
  }

  const headers: Record<string, string> = useRapid
    ? {
        "X-RapidAPI-Key": key,
        "X-RapidAPI-Host": getOptionalEnv("AERODATABOX_RAPIDAPI_HOST") ?? "aerodatabox.p.rapidapi.com",
        Accept: "application/json",
      }
    : {
        "x-api-market-key": key,
        Accept: "application/json",
      };

  return { baseUrl, headers, configured: true };
}

export class AeroDataBoxFlightRepository implements FlightRepository {
  readonly sourceName = "aerodatabox";
  private readonly config = createAeroDataBoxClientConfig();

  get configured() {
    return this.config.configured;
  }

  async getDashboardFlights() {
    const configuredFlights =
      getOptionalEnv("VOLANTIS_TRACK_FLIGHTS")
        ?.split(",")
        .map((flight) => flight.trim())
        .filter(Boolean) ?? [];
    const singleFlight = getOptionalEnv("VOLANTIS_TRACK_FLIGHT_NUMBER");
    const flightNumbers = configuredFlights.length > 0 ? configuredFlights : singleFlight ? [singleFlight] : [];

    if (!this.configured || flightNumbers.length === 0) {
      return [];
    }

    const settled = await Promise.allSettled(flightNumbers.map((flightNumber) => this.getFlightByNumber(flightNumber)));
    return settled.flatMap((result) => (result.status === "fulfilled" && result.value ? [result.value] : []));
  }

  async getFlightByNumber(flightNumber: string, dateLocal?: string) {
    if (!this.configured) {
      return null;
    }

    const encoded = encodeURIComponent(flightNumber.replace(/\s+/g, ""));
    const path = dateLocal
      ? `/flights/number/${encoded}/${encodeURIComponent(dateLocal)}?withLocation=true&withAircraftImage=true`
      : `/flights/number/${encoded}?withLocation=true&withAircraftImage=true`;
    const payload = await this.fetchJson(path);
    const flights = asArray(payload).map((item) => mapAeroDataBoxFlight(item, flightNumber)).filter((flight): flight is Flight => Boolean(flight));

    return flights[0] ?? null;
  }

  private async fetchJson(path: string) {
    const url = `${this.config.baseUrl.replace(/\/$/, "")}${path}`;
    const response = await fetch(url, {
      method: "GET",
      headers: this.config.headers,
      cache: "no-store",
    });

    if (response.status === 204) {
      return [];
    }

    if (!response.ok) {
      const body = await response.text().catch(() => "");
      throw new Error(`AeroDataBox request failed: ${response.status} ${body.slice(0, 160)}`);
    }

    return response.json() as Promise<unknown>;
  }
}
