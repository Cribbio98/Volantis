export function hasGooglePlacesCredentials() {
  return Boolean(process.env.GOOGLE_MAPS_API_KEY || process.env.GOOGLE_PLACES_API_KEY);
}

export function buildGoogleMapsUrl(latitude: number, longitude: number, label?: string) {
  const query = encodeURIComponent(label ? `${label} ${latitude},${longitude}` : `${latitude},${longitude}`);
  return `https://www.google.com/maps/search/?api=1&query=${query}`;
}

export function getOptionalPlacesCategories() {
  return ["Restaurants", "Hotels", "Attractions", "Transit", "Car rentals"];
}
