import { db } from "@/db";
import { sql } from "drizzle-orm";
import { parseCsvToObjects } from "@/lib/csvParser";
import type { Airport, DataSourceInfo, Runway } from "@/types/volantis";

const OURAIRPORTS_AIRPORTS_URL = "https://davidmegginson.github.io/ourairports-data/airports.csv";
const OURAIRPORTS_RUNWAYS_URL = "https://davidmegginson.github.io/ourairports-data/runways.csv";
const LICENSE = "CC0-1.0";
const SOURCE = "ourairports";

function safeFloat(value?: string) {
  const result = Number(value);
  return Number.isFinite(result) ? result : undefined;
}

function safeInt(value?: string) {
  const result = parseInt(value ?? "", 10);
  return Number.isFinite(result) ? result : undefined;
}

function airportTypeFrom(rawType?: string): Airport["type"] {
  if (!rawType) return "unknown";
  if (rawType.includes("large")) return "large_airport";
  if (rawType.includes("medium")) return "medium_airport";
  if (rawType.includes("small")) return "small_airport";
  if (rawType.includes("seaplane")) return "seaplane_base";
  if (rawType.includes("heliport")) return "heliport";
  if (rawType.includes("closed")) return "closed";
  return "unknown";
}

function airportFromCsv(record: Record<string, string>): Airport | null {
  const iata = record.iata_code?.trim();
  const icao = record.ident?.trim();
  const name = record.name?.trim();
  const latitude = safeFloat(record.latitude_deg);
  const longitude = safeFloat(record.longitude_deg);

  if (!iata || iata.length !== 3 || !icao || !name || typeof latitude !== "number" || typeof longitude !== "number") {
    return null;
  }

  const now = new Date().toISOString();
  const dataSourceInfo: DataSourceInfo = {
    source: SOURCE,
    provider: "OurAirports",
    sourceUrl: OURAIRPORTS_AIRPORTS_URL,
    license: LICENSE,
    attribution: "Data from OurAirports. CC0-1.0 Public Domain.",
    commercialUse: true,
    sourceUpdatedAt: now,
    dataConfidence: "likely",
    cachedAt: now,
    retrievedAt: now,
  };

  return {
    iata: iata.toUpperCase(),
    icao: icao.toUpperCase(),
    name,
    city: record.municipality?.trim() ?? "",
    municipality: record.municipality?.trim(),
    country: record.iso_country?.trim() ?? "",
    countryIso: record.iso_country?.trim().toUpperCase(),
    latitude,
    longitude,
    elevationFt: safeInt(record.elevation_ft),
    timezone: undefined,
    type: airportTypeFrom(record.type),
    scheduledService: record.scheduled_service === "1",
    homeLink: record.home_link?.trim() || undefined,
    wikipediaLink: record.wikipedia_link?.trim() || undefined,
    dataSourceInfo,
  };
}

function runwaysFromCsv(record: Record<string, string>): Runway[] {
  const runways: Runway[] = [];
  const leIdent = record.le_ident?.trim();
  const heIdent = record.he_ident?.trim();

  if (leIdent) {
    runways.push({
      name: leIdent,
      lengthFt: safeInt(record.length_ft),
      lengthMeters: typeof safeInt(record.length_ft) === "number" ? Math.round(safeInt(record.length_ft)! * 0.3048) : undefined,
      surface: record.surface?.trim() || undefined,
      headingDeg: safeFloat(record.le_heading_degT),
      lighted: record.lighted === "1",
      closed: record.closed === "1",
    });
  }

  if (heIdent && heIdent !== leIdent) {
    runways.push({
      name: heIdent,
      lengthFt: safeInt(record.length_ft),
      lengthMeters: typeof safeInt(record.length_ft) === "number" ? Math.round(safeInt(record.length_ft)! * 0.3048) : undefined,
      surface: record.surface?.trim() || undefined,
      headingDeg: safeFloat(record.he_heading_degT),
      lighted: record.lighted === "1",
      closed: record.closed === "1",
    });
  }

  return runways;
}

export async function seedAirportsFromOurAirports() {
  console.log("Volantis: Fetching OurAirports airport data...");
  const airportsResponse = await fetch(OURAIRPORTS_AIRPORTS_URL, { cache: "no-store" });
  if (!airportsResponse.ok) throw new Error(`OurAirports airports CSV fetch failed: ${airportsResponse.status}`);
  const airportsCsv = await airportsResponse.text();

  console.log("Volantis: Parsing airports CSV...");
  const airportRecords = parseCsvToObjects(airportsCsv);
  const airports = airportRecords.map(airportFromCsv).filter((a): a is Airport => a !== null);
  console.log(`Volantis: Parsed ${airports.length} airports with IATA codes.`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS volantis_airport_data (
    iata VARCHAR(3) PRIMARY KEY,
    icao VARCHAR(4) NOT NULL,
    name VARCHAR(180) NOT NULL,
    city VARCHAR(120) NOT NULL DEFAULT '',
    municipality VARCHAR(120),
    country VARCHAR(96) NOT NULL DEFAULT '',
    country_iso VARCHAR(2),
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    elevation_ft INTEGER,
    timezone VARCHAR(80),
    airport_type VARCHAR(24),
    scheduled_service BOOLEAN DEFAULT FALSE,
    home_link TEXT,
    wikipedia_link TEXT,
    data_source_info JSONB,
    runways JSONB,
    runway_count INTEGER DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);

  let inserted = 0;
  const batchSize = 200;

  for (let batchStart = 0; batchStart < airports.length; batchStart += batchSize) {
    const batch = airports.slice(batchStart, batchStart + batchSize);
    const values = batch
      .map(
        (a) =>
          `(${sql.raw(`'${a.iata}'`)},${sql.raw(`'${a.icao}'`)},${sql.raw(`'${a.name.replace(/'/g, "''")}'`)},${sql.raw(`'${(a.city || "").replace(/'/g, "''")}'`)},${a.municipality ? sql.raw(`'${a.municipality.replace(/'/g, "''")}'`) : "NULL"},${sql.raw(`'${(a.country || "").replace(/'/g, "''")}'`)},${a.countryIso ? sql.raw(`'${a.countryIso}'`) : "NULL"},${a.latitude},${a.longitude},${a.elevationFt ?? "NULL"},${a.timezone ? sql.raw(`'${a.timezone}'`) : "NULL"},${a.type ? sql.raw(`'${a.type}'`) : "NULL"},${a.scheduledService ? "TRUE" : "FALSE"},${a.homeLink ? sql.raw(`'${a.homeLink}'`) : "NULL"},${a.wikipediaLink ? sql.raw(`'${a.wikipediaLink}'`) : "NULL"},${sql.raw(`'${JSON.stringify(a.dataSourceInfo)}'`)}::jsonb,'[]'::jsonb,0,NOW())`,
      )
      .join(",");

    await db.execute(sql`
      INSERT INTO volantis_airport_data (iata,icao,name,city,municipality,country,country_iso,latitude,longitude,elevation_ft,timezone,airport_type,scheduled_service,home_link,wikipedia_link,data_source_info,runways,runway_count,updated_at)
      VALUES ${sql.raw(values)}
      ON CONFLICT (iata) DO UPDATE SET
        icao=EXCLUDED.icao, name=EXCLUDED.name, city=EXCLUDED.city, municipality=EXCLUDED.municipality,
        country=EXCLUDED.country, country_iso=EXCLUDED.country_iso, latitude=EXCLUDED.latitude, longitude=EXCLUDED.longitude,
        elevation_ft=EXCLUDED.elevation_ft, timezone=EXCLUDED.timezone, airport_type=EXCLUDED.airport_type,
        scheduled_service=EXCLUDED.scheduled_service, home_link=EXCLUDED.home_link, wikipedia_link=EXCLUDED.wikipedia_link,
        data_source_info=EXCLUDED.data_source_info, updated_at=NOW()
    `);
    inserted += batch.length;
  }

  console.log("Volantis: Fetching OurAirports runway data...");
  let runwayCount = 0;
  try {
    const runwaysResponse = await fetch(OURAIRPORTS_RUNWAYS_URL, { cache: "no-store" });
    if (runwaysResponse.ok) {
      const runwaysCsv = await runwaysResponse.text();
      const runwayRecords = parseCsvToObjects(runwaysCsv);
      const runwaysByAirport = new Map<string, Runway[]>();

      for (const record of runwayRecords) {
        const airportIdent = record.airport_ident?.trim().toUpperCase();
        if (!airportIdent) continue;
        const runways = runwaysFromCsv(record);
        const existing = runwaysByAirport.get(airportIdent) ?? [];
        runwaysByAirport.set(airportIdent, [...existing, ...runways]);
      }

      for (const [icao, runways] of runwaysByAirport) {
        if (runways.length === 0) continue;
        await db.execute(sql`
          UPDATE volantis_airport_data
          SET runways = ${JSON.stringify(runways)}::jsonb, runway_count = ${runways.length}
          WHERE icao = ${icao}
        `);
        runwayCount++;
      }
    }
  } catch (error) {
    console.warn("Volantis: Runway data seeding skipped", error);
  }

  return { airportCount: inserted, runwayAssignments: runwayCount, source: SOURCE, license: LICENSE };
}

export async function getAirportFromDb(iata: string): Promise<Airport | null> {
  try {
    const result = await db.execute(sql`
      SELECT iata,icao,name,city,municipality,country,country_iso,latitude,longitude,elevation_ft,timezone,airport_type,scheduled_service,home_link,wikipedia_link,data_source_info,runways,runway_count
      FROM volantis_airport_data
      WHERE iata = ${iata.toUpperCase()}
      LIMIT 1
    `);

    if (result.rows.length === 0) return null;
    const row = result.rows[0] as Record<string, unknown>;
    return dbRowToAirport(row);
  } catch {
    return null;
  }
}

export async function searchAirportsFromDb(query: { iata?: string; icao?: string; name?: string; city?: string; country?: string }, limit = 24): Promise<Airport[]> {
  try {
    const conditions: string[] = [];
    const q = query;
    if (q.iata) conditions.push(`iata = '${q.iata.toUpperCase().replace(/'/g, "''")}'`);
    if (q.icao) conditions.push(`icao = '${q.icao.toUpperCase().replace(/'/g, "''")}'`);
    if (q.name) conditions.push(`name ILIKE '%${q.name.replace(/'/g, "''")}%'`);
    if (q.city) conditions.push(`city ILIKE '%${q.city.replace(/'/g, "''")}%'`);
    if (q.country) conditions.push(`(country ILIKE '%${q.country.replace(/'/g, "''")}%' OR country_iso ILIKE '%${q.country.toUpperCase().replace(/'/g, "''")}%')`);

    if (conditions.length === 0) return [];
    const where = conditions.join(" AND ");

    const result = await db.execute(sql`
      SELECT iata,icao,name,city,municipality,country,country_iso,latitude,longitude,elevation_ft,timezone,airport_type,scheduled_service,home_link,wikipedia_link,data_source_info,runways,runway_count
      FROM volantis_airport_data
      WHERE ${sql.raw(where)}
      ORDER BY
        CASE airport_type WHEN 'large_airport' THEN 0 WHEN 'medium_airport' THEN 1 WHEN 'small_airport' THEN 2 ELSE 3 END,
        name
      LIMIT ${limit}
    `);

    return result.rows.map((row) => dbRowToAirport(row as Record<string, unknown>)).filter((a): a is Airport => a !== null);
  } catch {
    return [];
  }
}

function dbRowToAirport(row: Record<string, unknown>): Airport | null {
  const iata = typeof row.iata === "string" ? row.iata : null;
  const icao = typeof row.icao === "string" ? row.icao : null;
  const name = typeof row.name === "string" ? row.name : null;
  const latitude = typeof row.latitude === "number" ? row.latitude : Number(row.latitude);
  const longitude = typeof row.longitude === "number" ? row.longitude : Number(row.longitude);

  if (!iata || !icao || !name || !Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;

  return {
    iata,
    icao,
    name,
    city: typeof row.city === "string" ? row.city : "",
    municipality: typeof row.municipality === "string" ? row.municipality : undefined,
    country: typeof row.country === "string" ? row.country : "",
    countryIso: typeof row.country_iso === "string" ? row.country_iso : undefined,
    latitude,
    longitude,
    elevationFt: typeof row.elevation_ft === "number" ? row.elevation_ft : undefined,
    timezone: typeof row.timezone === "string" ? row.timezone : undefined,
    type: typeof row.airport_type === "string" ? (row.airport_type as Airport["type"]) : undefined,
    scheduledService: row.scheduled_service === true || row.scheduled_service === "t",
    homeLink: typeof row.home_link === "string" ? row.home_link : undefined,
    wikipediaLink: typeof row.wikipedia_link === "string" ? row.wikipedia_link : undefined,
    runways: Array.isArray(row.runways) ? (row.runways as Runway[]) : undefined,
    runwayCount: typeof row.runway_count === "number" ? row.runway_count : undefined,
    dataSourceInfo: typeof row.data_source_info === "object" && row.data_source_info !== null ? (row.data_source_info as DataSourceInfo) : undefined,
  };
}
