import { globalCountries } from "@/data/countriesComplete";
import type { Country } from "@/types/volantis";

const countries = globalCountries;

const countryByAlpha2 = new Map(countries.map((c) => [c.isoAlpha2, c]));
const countryByAlpha3 = new Map(countries.map((c) => [c.isoAlpha3, c]));
const countryByName = new Map(countries.map((c) => [c.name.toLowerCase(), c]));

export function getCountryByAlpha2(code: string) {
  return countryByAlpha2.get(code.toUpperCase());
}

export function getCountryByAlpha3(code: string) {
  return countryByAlpha3.get(code.toUpperCase());
}

export function findCountry(input?: string) {
  if (!input) return undefined;
  const trimmed = input.trim();
  return (
    countryByAlpha2.get(trimmed.toUpperCase()) ??
    countryByAlpha3.get(trimmed.toUpperCase()) ??
    countryByName.get(trimmed.toLowerCase())
  );
}

export function getAllCountries() {
  return countries;
}

export function getFlagSvgUrl(isoAlpha2: string) {
  return `https://flagcdn.com/w80/${isoAlpha2.toLowerCase()}.svg`;
}

export function getCountryCount() {
  return countries.length;
}

export function getAllContinents() {
  return Array.from(new Set(countries.map((c) => c.continent)));
}
