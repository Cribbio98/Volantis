import { db } from "@/db";
import { sql } from "drizzle-orm";
import { parseCsvToObjects } from "@/lib/csvParser";
import type { Airline, DataSourceInfo } from "@/types/volantis";

const OPENFLIGHTS_URL = "https://raw.githubusercontent.com/jpatokal/openflights/master/data/airlines.dat";
const LICENSE = "ODbL-1.0";
const SOURCE = "openflights";

function safeString(value?: string) {
  const trimmed = value?.trim();
  return trimmed && trimmed !== "\\N" && trimmed.length > 0 ? trimmed : undefined;
}

function airlineFromCsvRow(record: Record<string, string>): Airline | null {
  const name = safeString(record["1"]) ?? safeString(record.name);
  const iata = safeString(record["3"]) ?? safeString(record.iata);
  const icao = safeString(record["4"]) ?? safeString(record.icao);
  const active = (record["7"] ?? record.active) === "Y";

  if (!name) return null;

  const now = new Date().toISOString();
  const dataSourceInfo: DataSourceInfo = {
    source: SOURCE,
    provider: "OpenFlights",
    sourceUrl: OPENFLIGHTS_URL,
    license: LICENSE,
    attribution: "Data from OpenFlights (ODbL-1.0). Attribution required for derivative databases.",
    commercialUse: true,
    sourceUpdatedAt: now,
    dataConfidence: "likely",
    cachedAt: now,
    retrievedAt: now,
  };

  const callsign = safeString(record["5"]) ?? safeString(record.callsign);
  const country = safeString(record["6"]) ?? safeString(record.country);

  return {
    name,
    iata: iata?.toUpperCase() ?? "",
    icao: icao?.toUpperCase() ?? "",
    callsign,
    logo: {
      kind: iata ? "brand-safe-mark" : "text-lockup",
      label: iata ?? name.slice(0, 2).toUpperCase(),
      licensingNote: "Brand-safe in-app mark derived from OpenFlights IATA code. Replace with an official licensed logo when available.",
    },
    brandColors: {
      primary: "#FACC15",
      secondary: "#0F172A",
      accent: "#FFFFFF",
    },
    alliance: "Independent" as const,
    country: country ?? "",
    countryIso: undefined,
    active,
    type: "unknown",
    dataSourceInfo,
  };
}

export async function seedAirlinesFromOpenFlights() {
  console.log("Volantis: Fetching OpenFlights airline data...");
  const response = await fetch(OPENFLIGHTS_URL, { cache: "no-store" });
  if (!response.ok) throw new Error(`OpenFlights airline data fetch failed: ${response.status}`);

  const text = await response.text();
  const lines = text.split(/\r?\n/).filter((line) => line.trim().length > 0);

  const headers = ["id", "name", "alias", "iata", "icao", "callsign", "country", "active"];
  const records = lines.map((line) => {
    const values = line.split(",").map((v) => v.replace(/^"|"$/g, "").trim());
    const record: Record<string, string> = {};
    values.forEach((value, index) => {
      record[String(index)] = value;
      if (headers[index]) record[headers[index]] = value;
    });
    return record;
  });

  const airlines = records.map(airlineFromCsvRow).filter((a): a is Airline => a !== null && (a.iata.length > 0 || a.icao.length > 0));
  console.log(`Volantis: Parsed ${airlines.length} airlines.`);

  await db.execute(sql`CREATE TABLE IF NOT EXISTS volantis_airline_data (
    iata VARCHAR(3) PRIMARY KEY,
    icao VARCHAR(4),
    name VARCHAR(160) NOT NULL,
    callsign VARCHAR(64),
    country VARCHAR(96),
    country_iso VARCHAR(2),
    alliance VARCHAR(40) DEFAULT 'Independent',
    active BOOLEAN DEFAULT TRUE,
    airline_type VARCHAR(24) DEFAULT 'unknown',
    logo_url TEXT,
    logo_license TEXT,
    brand_colors JSONB,
    website TEXT,
    wikipedia_link TEXT,
    data_source_info JSONB,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);

  let inserted = 0;
  const batchSize = 200;

  for (let batchStart = 0; batchStart < airlines.length; batchStart += batchSize) {
    const batch = airlines.slice(batchStart, batchStart + batchSize).filter((a) => a.iata.length > 0);
    if (batch.length === 0) continue;

    const values = batch
      .map(
        (a) =>
          `(${sql.raw(`'${a.iata}'`)},${a.icao ? sql.raw(`'${a.icao}'`) : "NULL"},${sql.raw(`'${a.name.replace(/'/g, "''")}'`)},${a.callsign ? sql.raw(`'${a.callsign.replace(/'/g, "''")}'`) : "NULL"},${a.country ? sql.raw(`'${a.country.replace(/'/g, "''")}'`) : "NULL"},${a.countryIso ? sql.raw(`'${a.countryIso}'`) : "NULL"},${sql.raw(`'${a.alliance}'`)},${a.active ? "TRUE" : "FALSE"},${sql.raw(`'${a.type ?? "unknown"}'`)},NULL,NULL,${sql.raw(`'${JSON.stringify(a.brandColors)}'`)}::jsonb,NULL,NULL,${sql.raw(`'${JSON.stringify(a.dataSourceInfo)}'`)}::jsonb,NOW())`,
      )
      .join(",");

    await db.execute(sql`
      INSERT INTO volantis_airline_data (iata,icao,name,callsign,country,country_iso,alliance,active,airline_type,logo_url,logo_license,brand_colors,website,wikipedia_link,data_source_info,updated_at)
      VALUES ${sql.raw(values)}
      ON CONFLICT (iata) DO UPDATE SET
        icao=COALESCE(EXCLUDED.icao, volantis_airline_data.icao),
        name=EXCLUDED.name, callsign=COALESCE(EXCLUDED.callsign, volantis_airline_data.callsign),
        country=COALESCE(EXCLUDED.country, volantis_airline_data.country),
        active=EXCLUDED.active, data_source_info=EXCLUDED.data_source_info, updated_at=NOW()
    `);
    inserted += batch.length;
  }

  return { airlineCount: inserted, source: SOURCE, license: LICENSE };
}

export async function getAirlineFromDb(iata: string): Promise<Airline | null> {
  try {
    const result = await db.execute(sql`
      SELECT iata,icao,name,callsign,country,country_iso,alliance,active,airline_type,brand_colors,data_source_info
      FROM volantis_airline_data
      WHERE iata = ${iata.toUpperCase()}
      LIMIT 1
    `);
    if (result.rows.length === 0) return null;
    return dbRowToAirline(result.rows[0] as Record<string, unknown>);
  } catch {
    return null;
  }
}

export async function searchAirlinesFromDb(query: { iata?: string; icao?: string; name?: string; country?: string }, limit = 24): Promise<Airline[]> {
  try {
    const conditions: string[] = [];
    if (query.iata) conditions.push(`iata = '${query.iata.toUpperCase().replace(/'/g, "''")}'`);
    if (query.icao) conditions.push(`icao = '${query.icao.toUpperCase().replace(/'/g, "''")}'`);
    if (query.name) conditions.push(`name ILIKE '%${query.name.replace(/'/g, "''")}%'`);
    if (query.country) conditions.push(`country ILIKE '%${query.country.replace(/'/g, "''")}%'`);
    if (conditions.length === 0) return [];

    const result = await db.execute(sql`
      SELECT iata,icao,name,callsign,country,country_iso,alliance,active,airline_type,brand_colors,data_source_info
      FROM volantis_airline_data
      WHERE ${sql.raw(conditions.join(" AND "))}
      ORDER BY name
      LIMIT ${limit}
    `);

    return result.rows.map((row) => dbRowToAirline(row as Record<string, unknown>)).filter((a): a is Airline => a !== null);
  } catch {
    return [];
  }
}

function dbRowToAirline(row: Record<string, unknown>): Airline | null {
  const name = typeof row.name === "string" ? row.name : null;
  const iata = typeof row.iata === "string" ? row.iata : "";
  const icao = typeof row.icao === "string" ? row.icao : "";
  if (!name) return null;

  return {
    name,
    iata,
    icao,
    callsign: typeof row.callsign === "string" ? row.callsign : undefined,
    logo: {
      kind: "brand-safe-mark",
      label: iata || name.slice(0, 2).toUpperCase(),
      licensingNote: "Brand-safe mark from OpenFlights data. Replace with licensed logo when available.",
    },
    brandColors: typeof row.brand_colors === "object" && row.brand_colors !== null
      ? (row.brand_colors as Airline["brandColors"])
      : { primary: "#FACC15", secondary: "#0F172A", accent: "#FFFFFF" },
    alliance: (typeof row.alliance === "string" ? row.alliance : "Independent") as Airline["alliance"],
    country: typeof row.country === "string" ? row.country : "",
    countryIso: typeof row.country_iso === "string" ? row.country_iso : undefined,
    active: row.active === true || row.active === "t",
    type: (typeof row.airline_type === "string" ? row.airline_type : "unknown") as Airline["type"],
    dataSourceInfo: typeof row.data_source_info === "object" && row.data_source_info !== null ? (row.data_source_info as DataSourceInfo) : undefined,
  };
}
