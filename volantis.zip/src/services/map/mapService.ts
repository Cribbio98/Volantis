export type MapCameraMode = "GLOBAL" | "ROUTE" | "FOLLOW";

export type SatelliteImageryProvider = {
  id: string;
  name: string;
  tiles: string[];
  attribution: string;
  tileSize: number;
};

export type TerrainProvider = {
  id: string;
  name: string;
  tiles: string[];
  attribution: string;
  tileSize: number;
  encoding: "terrarium" | "mapbox";
};

export function getSatelliteImageryProvider(): SatelliteImageryProvider {
  return {
    id: "esri-world-imagery",
    name: "Esri World Imagery",
    tiles: [
      process.env.NEXT_PUBLIC_SATELLITE_TILE_URL ??
        "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    ],
    attribution:
      "Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community. Configure NEXT_PUBLIC_SATELLITE_TILE_URL to use another licensed imagery provider.",
    tileSize: 256,
  };
}

export function getTerrainProvider(): TerrainProvider {
  return {
    id: "aws-terrain-terrarium",
    name: "AWS Terrain Tiles",
    tiles: [
      process.env.NEXT_PUBLIC_TERRAIN_TILE_URL ??
        "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png",
    ],
    attribution: "Terrain tiles by Mapzen / AWS Open Data.",
    tileSize: 256,
    encoding: "terrarium",
  };
}

export function createVolantisMapStyle(): Record<string, unknown> {
  const satellite = getSatelliteImageryProvider();
  const terrain = getTerrainProvider();

  return {
    version: 8,
    name: "Volantis Satellite Globe",
    sources: {
      [satellite.id]: {
        type: "raster",
        tiles: satellite.tiles,
        tileSize: satellite.tileSize,
        attribution: satellite.attribution,
      },
      [terrain.id]: {
        type: "raster-dem",
        tiles: terrain.tiles,
        tileSize: terrain.tileSize,
        encoding: terrain.encoding,
        attribution: terrain.attribution,
      },
    },
    layers: [
      {
        id: "satellite-base",
        type: "raster",
        source: satellite.id,
        paint: {
          "raster-saturation": -0.08,
          "raster-contrast": 0.08,
          "raster-brightness-min": 0.02,
          "raster-brightness-max": 0.92,
        },
      },
    ],
    terrain: {
      source: terrain.id,
      exaggeration: 1.18,
    },
  };
}

export function cameraModeLabel(mode: MapCameraMode) {
  const labels: Record<MapCameraMode, string> = {
    GLOBAL: "Global",
    ROUTE: "Route",
    FOLLOW: "Follow",
  };
  return labels[mode];
}
