import { createDemoPassport, createDemoTrips } from "@/data/passport";

export function getTrips() {
  return createDemoTrips();
}

export function getTravelPassport() {
  return createDemoPassport();
}
