import { airportRegistry, findAirport } from "@/data/airports";
import { airlineRegistry, findAirline } from "@/data/airlines";
import { detailedAircraftSpecs, aircraftFamilyFromType } from "@/data/aircraft";
import { countryRepository } from "@/services/repositories/countryRepository";

export interface SearchResult {
  category: "airport" | "airline" | "aircraft" | "country";
  label: string;
  sublabel: string;
  href: string;
  emoji?: string;
}

export function searchAviation(query: string): SearchResult[] {
  const normalized = query.trim().toLowerCase();
  if (normalized.length < 1) return [];

  const results: SearchResult[] = [];

  for (const airport of airportRegistry) {
    if (
      airport.iata.toLowerCase() === normalized ||
      airport.icao.toLowerCase() === normalized ||
      airport.name.toLowerCase().includes(normalized) ||
      airport.city.toLowerCase().includes(normalized)
    ) {
      const country = airport.countryIso ? countryRepository.findByAlpha2(airport.countryIso) : undefined;
      results.push({
        category: "airport",
        label: `${airport.iata} — ${airport.name}`,
        sublabel: `${airport.city}, ${airport.country} ${country ? country.flagEmoji : ""}`,
        href: `/airports/${airport.iata}`,
        emoji: "✈",
      });
    }
  }

  for (const airline of airlineRegistry) {
    if (
      airline.iata.toLowerCase() === normalized ||
      airline.icao.toLowerCase() === normalized ||
      airline.name.toLowerCase().includes(normalized)
    ) {
      const country = airline.countryIso ? countryRepository.findByAlpha2(airline.countryIso) : undefined;
      results.push({
        category: "airline",
        label: airline.name,
        sublabel: `${airline.iata} · ${airline.icao} · ${airline.alliance} ${country ? country.flagEmoji : ""}`,
        href: `/airlines/${airline.iata}`,
        emoji: "🏢",
      });
    }
  }

  for (const aircraft of detailedAircraftSpecs) {
    if (
      aircraft.model.toLowerCase().includes(normalized) ||
      aircraft.icaoCode.toLowerCase() === normalized ||
      aircraft.family.toLowerCase().includes(normalized)
    ) {
      results.push({
        category: "aircraft",
        label: aircraft.model,
        sublabel: `${aircraft.manufacturer} · ${aircraft.typicalSeats} seats · ${aircraft.icaoCode}`,
        href: `/aircraft/${encodeURIComponent(aircraft.model)}`,
        emoji: "🛩",
      });
    }
  }

  for (const country of countryRepository.getAll()) {
    if (
      country.name.toLowerCase().includes(normalized) ||
      country.isoAlpha2.toLowerCase() === normalized ||
      country.isoAlpha3.toLowerCase() === normalized
    ) {
      results.push({
        category: "country",
        label: `${country.flagEmoji} ${country.name}`,
        sublabel: `${country.isoAlpha2} · ${country.continent} · ${country.capital ?? ""}`,
        href: `/passport`,
        emoji: country.flagEmoji,
      });
    }
  }

  return results.slice(0, 30);
}
