import type { AircraftPositionResolution, Coordinate, DataSourceState, Flight } from "@/types/volantis";

const EARTH_RADIUS_KM = 6371.0088;

function toRadians(degrees: number) {
  return (degrees * Math.PI) / 180;
}

function toDegrees(radians: number) {
  return (radians * 180) / Math.PI;
}

export function clamp(value: number, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value));
}

export function haversineDistanceKm(a: Coordinate, b: Coordinate) {
  const lat1 = toRadians(a.latitude);
  const lat2 = toRadians(b.latitude);
  const deltaLat = toRadians(b.latitude - a.latitude);
  const deltaLon = toRadians(b.longitude - a.longitude);

  const h =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);

  return 2 * EARTH_RADIUS_KM * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function bearingDegrees(from: Coordinate, to: Coordinate) {
  const lat1 = toRadians(from.latitude);
  const lat2 = toRadians(to.latitude);
  const deltaLon = toRadians(to.longitude - from.longitude);
  const y = Math.sin(deltaLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLon);
  return (toDegrees(Math.atan2(y, x)) + 360) % 360;
}

export function greatCircleInterpolate(from: Coordinate, to: Coordinate, fraction: number): Coordinate {
  const f = clamp(fraction);
  const lat1 = toRadians(from.latitude);
  const lon1 = toRadians(from.longitude);
  const lat2 = toRadians(to.latitude);
  const lon2 = toRadians(to.longitude);

  const angularDistance = haversineDistanceKm(from, to) / EARTH_RADIUS_KM;
  if (angularDistance === 0) {
    return from;
  }

  const sinDistance = Math.sin(angularDistance);
  const a = Math.sin((1 - f) * angularDistance) / sinDistance;
  const b = Math.sin(f * angularDistance) / sinDistance;

  const x = a * Math.cos(lat1) * Math.cos(lon1) + b * Math.cos(lat2) * Math.cos(lon2);
  const y = a * Math.cos(lat1) * Math.sin(lon1) + b * Math.cos(lat2) * Math.sin(lon2);
  const z = a * Math.sin(lat1) + b * Math.sin(lat2);

  const lat = Math.atan2(z, Math.sqrt(x * x + y * y));
  const lon = Math.atan2(y, x);

  return {
    latitude: toDegrees(lat),
    longitude: toDegrees(lon),
  };
}

export function greatCirclePath(from: Coordinate, to: Coordinate, steps = 72): Coordinate[] {
  return Array.from({ length: steps + 1 }, (_, index) => greatCircleInterpolate(from, to, index / steps));
}

export function calculateTemporalProgress(departureIso: string, arrivalIso: string, now = new Date()) {
  const depart = new Date(departureIso).getTime();
  const arrive = new Date(arrivalIso).getTime();
  const current = now.getTime();

  if (!Number.isFinite(depart) || !Number.isFinite(arrive) || arrive <= depart) {
    return 0;
  }

  return clamp((current - depart) / (arrive - depart));
}

export function calculateRouteProgress(origin: Coordinate, destination: Coordinate, position: Coordinate) {
  const total = haversineDistanceKm(origin, destination);
  if (total === 0) {
    return 0;
  }

  const travelled = haversineDistanceKm(origin, position);
  return clamp(travelled / total);
}

export function estimatePositionBySchedule(flight: Flight, now = new Date()): Coordinate {
  const departure = flight.actualDeparture ?? flight.estimatedDeparture ?? flight.scheduledDeparture;
  const arrival = flight.estimatedArrival ?? flight.actualArrival ?? flight.scheduledArrival;
  const progress = calculateTemporalProgress(departure, arrival, now);
  return greatCircleInterpolate(flight.origin, flight.destination, progress);
}

function dataSourceLabel(source: DataSourceState): AircraftPositionResolution["label"] {
  switch (source) {
    case "LIVE_DATA":
      return "LIVE DATA";
    case "ESTIMATED_POSITION":
      return "ESTIMATED POSITION";
    case "OFFLINE_CACHED":
      return "OFFLINE / CACHED";
    case "DEMO_DATA":
    default:
      return "DEMO DATA";
  }
}

export function resolveAircraftPosition(flight: Flight, now = new Date()): AircraftPositionResolution {
  const hasRealTelemetry =
    flight.telemetry?.source === "LIVE_DATA" &&
    Number.isFinite(flight.telemetry.latitude) &&
    Number.isFinite(flight.telemetry.longitude);

  // Critical Volantis rule: when AeroDataBox supplies live coordinates, those exact
  // coordinates are the authoritative aircraft position. We never replace them with
  // schedule-derived interpolation.
  const position = hasRealTelemetry ? flight.telemetry! : estimatePositionBySchedule(flight, now);
  const source = hasRealTelemetry ? "LIVE_DATA" : flight.dataSource === "OFFLINE_CACHED" ? "OFFLINE_CACHED" : flight.dataSource === "DEMO_DATA" ? "DEMO_DATA" : "ESTIMATED_POSITION";
  const progress = hasRealTelemetry
    ? calculateRouteProgress(flight.origin, flight.destination, position)
    : calculateTemporalProgress(flight.actualDeparture ?? flight.estimatedDeparture ?? flight.scheduledDeparture, flight.estimatedArrival ?? flight.actualArrival ?? flight.scheduledArrival, now);
  const distanceKm = flight.distanceKm || haversineDistanceKm(flight.origin, flight.destination);
  const remainingDistanceKm = Math.max(0, distanceKm * (1 - progress));
  const headingDeg = flight.telemetry?.headingDeg ?? bearingDegrees(position, flight.destination);

  const lastPositionUpdate = hasRealTelemetry ? flight.telemetry!.reportedAt : undefined;

  const positionExplanation = hasRealTelemetry
    ? "AeroDataBox live latitude/longitude are used directly as the aircraft marker position. This is authoritative real-time positioning."
    : flight.dataSource === "DEMO_DATA"
      ? "No live position is available. This is demo/mock data for demonstration only, clearly labeled as such."
      : flight.dataSource === "OFFLINE_CACHED"
        ? "No live position is available. Previously cached data is being used. The timestamp shows when the position was last updated."
        : "No live position is available from AeroDataBox. The aircraft position is estimated from departure/arrival times and the great-circle route. This is clearly labeled as ESTIMATED POSITION, never as live data.";

  return {
    position,
    source,
    label: dataSourceLabel(source),
    isAuthoritativeLive: hasRealTelemetry,
    progressPercent: Math.round(progress * 100),
    remainingDistanceKm,
    headingDeg,
    eta: flight.eta ?? flight.estimatedArrival ?? flight.scheduledArrival,
    lastPositionUpdate,
    positionExplanation,
  };
}

export function buildRouteSegments(flight: Flight, now = new Date()) {
  const resolution = resolveAircraftPosition(flight, now);
  const completed = greatCirclePath(flight.origin, resolution.position, 44);
  const remaining = greatCirclePath(resolution.position, flight.destination, 64);
  const full = flight.routeCoordinates && flight.routeCoordinates.length > 1 ? flight.routeCoordinates : greatCirclePath(flight.origin, flight.destination, 96);

  return {
    resolution,
    completed,
    remaining,
    full,
  };
}

export function midpoint(points: Coordinate[]): Coordinate {
  if (points.length === 0) {
    return { latitude: 0, longitude: 0 };
  }

  const sum = points.reduce(
    (acc, point) => ({ latitude: acc.latitude + point.latitude, longitude: acc.longitude + point.longitude }),
    { latitude: 0, longitude: 0 },
  );

  return {
    latitude: sum.latitude / points.length,
    longitude: sum.longitude / points.length,
  };
}
