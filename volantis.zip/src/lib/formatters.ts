import type { DataSourceState, FlightStatus } from "@/types/volantis";

const timeFormatter = new Intl.DateTimeFormat("en", {
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

const dateFormatter = new Intl.DateTimeFormat("en", {
  month: "short",
  day: "numeric",
});

export function formatTime(iso?: string) {
  if (!iso) {
    return "—";
  }
  return timeFormatter.format(new Date(iso));
}

export function formatDate(iso?: string) {
  if (!iso) {
    return "—";
  }
  return dateFormatter.format(new Date(iso));
}

export function formatDateTime(iso?: string) {
  if (!iso) {
    return "—";
  }
  return `${formatDate(iso)} · ${formatTime(iso)}`;
}

export function formatDuration(minutes: number) {
  const rounded = Math.max(0, Math.round(minutes));
  const hours = Math.floor(rounded / 60);
  const mins = rounded % 60;
  if (hours === 0) {
    return `${mins}m`;
  }
  return `${hours}h ${mins.toString().padStart(2, "0")}m`;
}

export function formatDistance(km: number) {
  return `${Math.round(km).toLocaleString("en")} km`;
}

export function formatAltitude(feet?: number) {
  if (typeof feet !== "number") {
    return "—";
  }
  return `${Math.round(feet).toLocaleString("en")} ft`;
}

export function formatSpeed(knots?: number) {
  if (typeof knots !== "number") {
    return "—";
  }
  return `${Math.round(knots)} kt`;
}

export function formatHeading(degrees?: number) {
  if (typeof degrees !== "number") {
    return "—";
  }
  return `${Math.round(degrees)}°`;
}

export function countdownTo(iso: string, now = new Date()) {
  const deltaMs = new Date(iso).getTime() - now.getTime();
  const absMinutes = Math.abs(Math.round(deltaMs / 60000));
  const hours = Math.floor(absMinutes / 60);
  const minutes = absMinutes % 60;
  const value = hours > 0 ? `${hours}h ${minutes.toString().padStart(2, "0")}m` : `${minutes}m`;

  if (deltaMs > 0) {
    return `T-${value}`;
  }

  return `T+${value}`;
}

export function statusLabel(status: FlightStatus) {
  const labels: Record<FlightStatus, string> = {
    Unknown: "Unknown",
    Expected: "Expected",
    EnRoute: "En route",
    CheckIn: "Check-in",
    Boarding: "Boarding",
    GateClosed: "Gate closed",
    Departed: "Departed",
    Delayed: "Delayed",
    Approaching: "Approaching",
    Arrived: "Arrived",
    Canceled: "Canceled",
    Diverted: "Diverted",
    CanceledUncertain: "Uncertain",
  };
  return labels[status];
}

export function sourceLabel(source: DataSourceState) {
  const labels: Record<DataSourceState, string> = {
    LIVE_DATA: "LIVE DATA",
    ESTIMATED_POSITION: "ESTIMATED POSITION",
    DEMO_DATA: "DEMO DATA",
    OFFLINE_CACHED: "OFFLINE / CACHED",
  };
  return labels[source];
}

export function sourceTone(source: DataSourceState) {
  const tones: Record<DataSourceState, string> = {
    LIVE_DATA: "border-emerald-300/50 bg-emerald-300/15 text-emerald-100",
    ESTIMATED_POSITION: "border-sky-300/40 bg-sky-300/10 text-sky-100",
    DEMO_DATA: "border-yellow-300/40 bg-yellow-300/10 text-yellow-100",
    OFFLINE_CACHED: "border-orange-300/40 bg-orange-300/10 text-orange-100",
  };
  return tones[source];
}
