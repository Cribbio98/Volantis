export function parseCsvLine(line: string): string[] {
  const fields: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (inQuotes) {
      if (char === '"') {
        if (line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
    } else if (char === '"') {
      inQuotes = true;
    } else if (char === ",") {
      fields.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  fields.push(current);
  return fields;
}

export function parseCsvToObjects(csvText: string): Record<string, string>[] {
  const lines = csvText.split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]).map((header) => header.replace(/^"|"$/g, "").trim());
  const objects: Record<string, string>[] = [];

  for (let index = 1; index < lines.length; index++) {
    const values = parseCsvLine(lines[index]);
    const record: Record<string, string> = {};
    for (let column = 0; column < headers.length; column++) {
      record[headers[column]] = (values[column] ?? "").replace(/^"|"$/g, "").trim();
    }
    objects.push(record);
  }

  return objects;
}

export function parseCsvStreaming(csvText: string, onHeader: (headers: string[]) => void, onRow: (row: Record<string, string>) => void) {
  const lines = csvText.split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length < 2) return;

  const headers = parseCsvLine(lines[0]).map((header) => header.replace(/^"|"$/g, "").trim());
  onHeader(headers);

  for (let index = 1; index < lines.length; index++) {
    const values = parseCsvLine(lines[index]);
    const record: Record<string, string> = {};
    for (let column = 0; column < headers.length; column++) {
      record[headers[column]] = (values[column] ?? "").replace(/^"|"$/g, "").trim();
    }
    onRow(record);
  }
}
