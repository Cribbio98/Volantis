import { boolean, date, index, integer, jsonb, numeric, pgEnum, pgTable, text, timestamp, uuid, varchar } from "drizzle-orm/pg-core";

export const dataSourceStateEnum = pgEnum("volantis_data_source_state", [
  "LIVE_DATA",
  "ESTIMATED_POSITION",
  "DEMO_DATA",
  "OFFLINE_CACHED",
]);

export const flightStatusEnum = pgEnum("volantis_flight_status", [
  "Unknown",
  "Expected",
  "EnRoute",
  "CheckIn",
  "Boarding",
  "GateClosed",
  "Departed",
  "Delayed",
  "Approaching",
  "Arrived",
  "Canceled",
  "Diverted",
  "CanceledUncertain",
]);

export const airlines = pgTable(
  "volantis_airlines",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    iata: varchar("iata", { length: 3 }).notNull().unique(),
    icao: varchar("icao", { length: 4 }).notNull().unique(),
    logo: jsonb("logo"),
    brandColors: jsonb("brand_colors"),
    alliance: varchar("alliance", { length: 40 }),
    country: varchar("country", { length: 96 }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    airlineIataIdx: index("volantis_airlines_iata_idx").on(table.iata),
    airlineIcaoIdx: index("volantis_airlines_icao_idx").on(table.icao),
  }),
);

export const airports = pgTable(
  "volantis_airports",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    iata: varchar("iata", { length: 3 }).notNull().unique(),
    icao: varchar("icao", { length: 4 }).notNull().unique(),
    name: varchar("name", { length: 180 }).notNull(),
    city: varchar("city", { length: 120 }).notNull(),
    country: varchar("country", { length: 96 }).notNull(),
    latitude: numeric("latitude", { precision: 9, scale: 6 }).notNull(),
    longitude: numeric("longitude", { precision: 9, scale: 6 }).notNull(),
    timezone: varchar("timezone", { length: 80 }),
    terminals: jsonb("terminals"),
    runways: jsonb("runways"),
    airlines: jsonb("airlines"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    airportIataIdx: index("volantis_airports_iata_idx").on(table.iata),
    airportIcaoIdx: index("volantis_airports_icao_idx").on(table.icao),
  }),
);

export const flights = pgTable(
  "volantis_flights",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    flightNumber: varchar("flight_number", { length: 16 }).notNull(),
    airlineIata: varchar("airline_iata", { length: 3 }),
    airlineIcao: varchar("airline_icao", { length: 4 }),
    originIata: varchar("origin_iata", { length: 3 }).notNull(),
    destinationIata: varchar("destination_iata", { length: 3 }).notNull(),
    status: flightStatusEnum("status").default("Unknown").notNull(),
    scheduledDeparture: timestamp("scheduled_departure", { withTimezone: true }).notNull(),
    scheduledArrival: timestamp("scheduled_arrival", { withTimezone: true }).notNull(),
    estimatedDeparture: timestamp("estimated_departure", { withTimezone: true }),
    estimatedArrival: timestamp("estimated_arrival", { withTimezone: true }),
    actualDeparture: timestamp("actual_departure", { withTimezone: true }),
    actualArrival: timestamp("actual_arrival", { withTimezone: true }),
    terminal: varchar("terminal", { length: 32 }),
    gate: varchar("gate", { length: 32 }),
    aircraftType: varchar("aircraft_type", { length: 96 }),
    aircraftRegistration: varchar("aircraft_registration", { length: 16 }),
    distanceKm: numeric("distance_km", { precision: 10, scale: 2 }),
    durationMinutes: integer("duration_minutes"),
    dataSource: dataSourceStateEnum("data_source").default("DEMO_DATA").notNull(),
    rawPayload: jsonb("raw_payload"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    flightNumberIdx: index("volantis_flights_number_idx").on(table.flightNumber),
    flightRouteIdx: index("volantis_flights_route_idx").on(table.originIata, table.destinationIata),
  }),
);

export const flightTelemetrySamples = pgTable(
  "volantis_flight_telemetry_samples",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    flightNumber: varchar("flight_number", { length: 16 }).notNull(),
    latitude: numeric("latitude", { precision: 9, scale: 6 }).notNull(),
    longitude: numeric("longitude", { precision: 9, scale: 6 }).notNull(),
    altitudeFt: integer("altitude_ft"),
    groundSpeedKt: integer("ground_speed_kt"),
    headingDeg: integer("heading_deg"),
    source: dataSourceStateEnum("source").notNull(),
    reportedAt: timestamp("reported_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    telemetryFlightIdx: index("volantis_telemetry_flight_idx").on(table.flightNumber, table.reportedAt),
  }),
);

export const flightCache = pgTable("volantis_flight_cache", {
  flightNumber: text("flight_number").primaryKey(),
  payload: jsonb("payload").notNull(),
  source: text("source").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const trips = pgTable("volantis_trips", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  originIata: varchar("origin_iata", { length: 3 }).notNull(),
  destinationIata: varchar("destination_iata", { length: 3 }).notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  destinationImage: text("destination_image"),
  totalDistanceKm: numeric("total_distance_km", { precision: 10, scale: 2 }),
  totalDurationMinutes: integer("total_duration_minutes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const tripFlights = pgTable(
  "volantis_trip_flights",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tripId: uuid("trip_id").notNull(),
    flightNumber: varchar("flight_number", { length: 16 }).notNull(),
    sequence: integer("sequence").notNull(),
    connectionRisk: varchar("connection_risk", { length: 32 }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    tripFlightsTripIdx: index("volantis_trip_flights_trip_idx").on(table.tripId),
  }),
);

export const personalFlightLogbook = pgTable(
  "volantis_personal_flight_logbook",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    flightNumber: varchar("flight_number", { length: 16 }).notNull(),
    airlineIata: varchar("airline_iata", { length: 3 }),
    aircraftType: varchar("aircraft_type", { length: 96 }),
    aircraftRegistration: varchar("aircraft_registration", { length: 16 }),
    originIata: varchar("origin_iata", { length: 3 }).notNull(),
    destinationIata: varchar("destination_iata", { length: 3 }).notNull(),
    departureDate: date("departure_date").notNull(),
    distanceKm: numeric("distance_km", { precision: 10, scale: 2 }),
    durationMinutes: integer("duration_minutes"),
    seat: varchar("seat", { length: 8 }),
    cabin: varchar("cabin", { length: 32 }),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    logbookRegistrationIdx: index("volantis_logbook_registration_idx").on(table.aircraftRegistration),
    logbookRouteIdx: index("volantis_logbook_route_idx").on(table.originIata, table.destinationIata),
  }),
);

export const airportVisits = pgTable(
  "volantis_airport_visits",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    airportIata: varchar("airport_iata", { length: 3 }).notNull(),
    country: varchar("country", { length: 96 }).notNull(),
    firstVisitedAt: date("first_visited_at"),
    lastVisitedAt: date("last_visited_at"),
    visitCount: integer("visit_count").default(1).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    airportVisitIdx: index("volantis_airport_visits_airport_idx").on(table.airportIata),
  }),
);

export const routeHistory = pgTable(
  "volantis_route_history",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    originIata: varchar("origin_iata", { length: 3 }).notNull(),
    destinationIata: varchar("destination_iata", { length: 3 }).notNull(),
    flightCount: integer("flight_count").default(1).notNull(),
    totalDistanceKm: numeric("total_distance_km", { precision: 12, scale: 2 }),
    lastFlownAt: date("last_flown_at"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    routeHistoryRouteIdx: index("volantis_route_history_route_idx").on(table.originIata, table.destinationIata),
  }),
);

export const passportStamps = pgTable("volantis_passport_stamps", {
  id: uuid("id").defaultRandom().primaryKey(),
  country: varchar("country", { length: 96 }).notNull(),
  airportIata: varchar("airport_iata", { length: 3 }).notNull(),
  stampedAt: date("stamped_at").notNull(),
  visualVariant: varchar("visual_variant", { length: 32 }).default("classic").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const smartTravelAlerts = pgTable(
  "volantis_smart_travel_alerts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    flightNumber: varchar("flight_number", { length: 16 }).notNull(),
    type: varchar("type", { length: 48 }).notNull(),
    title: varchar("title", { length: 160 }).notNull(),
    body: text("body"),
    severity: varchar("severity", { length: 24 }).default("info").notNull(),
    acknowledged: boolean("acknowledged").default(false).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    smartAlertsFlightIdx: index("volantis_alerts_flight_idx").on(table.flightNumber),
  }),
);
