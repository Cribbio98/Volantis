import Link from "next/link";
import { findAircraftSpecs, aircraftFamilyFromType, detailedAircraftSpecs, aircraftFleetDirectory } from "@/data/aircraft";
import { getLogbook } from "@/services/logbookService";
import { resolveAircraftPhoto } from "@/services/repositories/mediaCacheRepository";
import { formatDistance, formatDuration } from "@/lib/formatters";
import type { DetailedAircraftSpecs } from "@/data/aircraft";

export const dynamic = "force-dynamic";

export default async function AircraftDetailPage({ params }: { params: Promise<{ type: string }> }) {
  const { type } = await params;
  const decoded = decodeURIComponent(type);
  const specs = findAircraftSpecs(decoded);
  const family = aircraftFamilyFromType(decoded);
  const detailed = detailedAircraftSpecs.find((d) => d.model === decoded || d.icaoCode === decoded.toUpperCase() || d.family === family);
  const logbook = getLogbook();
  const aircraftFlights = logbook.filter((e) => e.aircraftType === decoded || e.aircraftType.includes(family.replace("Airbus ", "A").replace("Boeing ", "")));
  const aircraftDistance = aircraftFlights.reduce((sum, e) => sum + e.distanceKm, 0);
  const aircraftTime = aircraftFlights.reduce((sum, e) => sum + e.durationMinutes, 0);
  const airlinesFlown = Array.from(new Set(aircraftFlights.map((e) => e.airlineName)));
  const routesFlown = aircraftFlights.map((e) => `${e.originIata} → ${e.destinationIata}`);
  const familyMembers = aircraftFleetDirectory.filter((s) => s.manufacturer === specs.manufacturer);

  let photo = null;
  try {
    photo = await resolveAircraftPhoto(specs.manufacturer, specs.model);
  } catch {
    photo = null;
  }

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">
          ← Command center
        </Link>

        <section className="overflow-hidden rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.06)_38%,rgba(255,255,255,0.035))] backdrop-blur-xl">
          {photo?.url ? (
            <div className="relative h-44 sm:h-56">
              <img src={photo.thumbnailUrl ?? photo.url} alt={specs.model} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#02040a] via-[#02040a]/30 to-transparent" />
              {photo.sourcePageUrl ? (
                <a href={photo.sourcePageUrl} target="_blank" rel="noreferrer" className="absolute bottom-3 right-3 rounded-full bg-black/50 px-2.5 py-1 text-[0.6rem] text-white/60 backdrop-blur hover:text-[#FACC15]">
                  Photo: {photo.attribution || "Wikimedia Commons"} · {photo.license}
                </a>
              ) : null}
            </div>
          ) : null}
          <div className="p-6">
            <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Aircraft intelligence</p>
            <h1 className="mt-2 text-4xl font-black tracking-[-0.07em] text-white">{specs.model}</h1>
            <p className="mt-2 text-lg text-white/58">{specs.manufacturer} · {family}</p>
            {detailed ? (
              <p className="text-sm text-white/45">ICAO {detailed.icaoCode} · IATA {detailed.iataCode} · First flight {detailed.firstFlightYear}</p>
            ) : null}
            {!photo ? (
              <p className="mt-3 text-xs italic text-white/35">Real photograph data unavailable — no generated image is substituted</p>
            ) : null}
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Cruise speed</p>
            <p className="mt-2 text-2xl font-black text-[#FACC15]">{specs.typicalCruiseKt} kt</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Range</p>
            <p className="mt-2 text-2xl font-black text-white">{formatDistance(specs.rangeKm)}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Ceiling</p>
            <p className="mt-2 text-2xl font-black text-white">{specs.ceilingFt.toLocaleString("en")} ft</p>
          </div>
        </section>

        {detailed ? (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <h2 className="text-lg font-bold text-white">Dimensions</h2>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Length</p>
                <p className="mt-1 font-semibold text-white">{detailed.lengthM.toFixed(1)} m</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Wingspan</p>
                <p className="mt-1 font-semibold text-white">{detailed.wingspanM.toFixed(1)} m</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Height</p>
                <p className="mt-1 font-semibold text-white">{detailed.heightM.toFixed(1)} m</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Max speed</p>
                <p className="mt-1 font-semibold text-white">{detailed.maxSpeedKt} kt</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Engines</p>
                <p className="mt-1 font-semibold text-white">{detailed.engineCount} × {detailed.engineType}</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Seats</p>
                <p className="mt-1 font-semibold text-white">{detailed.typicalSeats}</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">First flight</p>
                <p className="mt-1 font-semibold text-white">{detailed.firstFlightYear}</p>
              </div>
              <div className="rounded-2xl bg-black/25 p-3">
                <p className="text-xs text-white/40">Engine type</p>
                <p className="mt-1 font-semibold text-white">{detailed.engines}</p>
              </div>
            </div>
          </section>
        ) : (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <h2 className="text-lg font-bold text-white">Specifications</h2>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-black/25 p-3"><p className="text-xs text-white/40">Seats</p><p className="mt-1 font-semibold text-white">{specs.typicalSeats}</p></div>
              <div className="rounded-2xl bg-black/25 p-3"><p className="text-xs text-white/40">Engines</p><p className="mt-1 font-semibold text-white">{specs.engines}</p></div>
            </div>
          </section>
        )}

        {aircraftFlights.length > 0 ? (
          <section className="rounded-[2rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.15),rgba(255,255,255,0.055)_38%)] p-5 backdrop-blur-xl">
            <h2 className="text-lg font-bold text-white">Your flights on this aircraft</h2>
            <div className="mt-4 grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-black/25 p-3"><p className="text-xs text-white/40">Flights</p><p className="mt-1 text-2xl font-black text-[#FACC15]">{aircraftFlights.length}</p></div>
              <div className="rounded-2xl bg-black/25 p-3"><p className="text-xs text-white/40">Distance</p><p className="mt-1 text-2xl font-black text-white">{formatDistance(aircraftDistance)}</p></div>
              <div className="rounded-2xl bg-black/25 p-3"><p className="text-xs text-white/40">Time</p><p className="mt-1 text-2xl font-black text-white">{formatDuration(aircraftTime)}</p></div>
            </div>
            {airlinesFlown.length > 0 ? (
              <div className="mt-4">
                <p className="text-xs text-white/40">Airlines flown</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {airlinesFlown.map((name) => <span key={name} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-white/70">{name}</span>)}
                </div>
              </div>
            ) : null}
            {routesFlown.length > 0 ? (
              <div className="mt-4">
                <p className="text-xs text-white/40">Routes</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {routesFlown.map((route, i) => <span key={`${route}-${i}`} className="rounded-full border border-[#FACC15]/20 bg-[#FACC15]/10 px-3 py-1 text-xs font-semibold text-[#FACC15]">{route}</span>)}
                </div>
              </div>
            ) : null}
          </section>
        ) : null}

        {familyMembers.length > 1 ? (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <h2 className="text-lg font-bold text-white">Family variants</h2>
            <div className="mt-4 space-y-2">
              {familyMembers.map((member) => (
                <Link key={member.model} href={`/aircraft/${encodeURIComponent(member.model)}`} className="block rounded-2xl bg-black/25 p-3 text-sm font-semibold text-white/70 transition hover:text-[#FACC15]">
                  {member.model} · {member.typicalSeats} seats · {formatDistance(member.rangeKm)} range
                </Link>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}
