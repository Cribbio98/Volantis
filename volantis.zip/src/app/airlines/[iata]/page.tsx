import Link from "next/link";
import { airlineRegistry, findAirline } from "@/data/airlines";
import { AirlineLogo } from "@/components/volantis/AirlineLogo";
import { formatDistance, formatDuration } from "@/lib/formatters";
import { getLogbook } from "@/services/logbookService";
import { countryRepository } from "@/services/repositories/countryRepository";
import { resolveAirlineLogo } from "@/services/repositories/mediaCacheRepository";

export const dynamic = "force-dynamic";

export default async function AirlineDetailPage({ params }: { params: Promise<{ iata: string }> }) {
  const { iata } = await params;
  const airline = findAirline(iata) ?? airlineRegistry[0];
  const country = airline.countryIso ? countryRepository.findByAlpha2(airline.countryIso) : undefined;
  const logbook = getLogbook();
  const airlineFlights = logbook.filter((e) => e.airlineIata === airline.iata);
  const airlineDistance = airlineFlights.reduce((sum, e) => sum + e.distanceKm, 0);
  const airlineTime = airlineFlights.reduce((sum, e) => sum + e.durationMinutes, 0);
  const aircraftTypes = Array.from(new Set(airlineFlights.map((e) => e.aircraftType)));
  const destinations = Array.from(new Set(airlineFlights.flatMap((e) => [e.destinationIata, e.originIata])));

  let logoAsset = null;
  try {
    logoAsset = await resolveAirlineLogo(airline.iata, airline.name);
  } catch {
    logoAsset = null;
  }

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">← Command center</Link>

        <section className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.06)_38%,rgba(255,255,255,0.035))] p-6 backdrop-blur-xl">
          <div className="flex items-start gap-5">
            {logoAsset?.url ? (
              <div className="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl border border-white/10 bg-white/95 p-2 shadow-[0_18px_40px_rgba(0,0,0,0.35)]">
                <img src={logoAsset.thumbnailUrl ?? logoAsset.url} alt={`${airline.name} logo`} className="max-h-full max-w-full object-contain" />
              </div>
            ) : (
              <AirlineLogo airline={airline} size="lg" />
            )}
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Airline intelligence</p>
              <h1 className="mt-2 text-4xl font-black tracking-[-0.07em] text-white">{airline.name}</h1>
              <p className="text-lg text-white/58">{airline.iata} / {airline.icao} {airline.callsign ? `· ${airline.callsign}` : ""}</p>
              <p className="mt-1 text-sm text-white/45">{airline.country} {country ? `${country.flagEmoji}` : ""} · {airline.alliance}</p>
            </div>
          </div>
          {logoAsset ? (
            <div className="mt-4 rounded-2xl border border-sky-300/20 bg-sky-300/5 p-2.5 text-[0.65rem] text-sky-100/80">
              Real logo: {logoAsset.sourcePageUrl ? <a href={logoAsset.sourcePageUrl} target="_blank" rel="noreferrer" className="underline hover:text-[#FACC15]">Wikimedia Commons</a> : "Wikimedia Commons"} · Artist: {logoAsset.author ?? "Unknown"} · License: {logoAsset.license} · Commercial use {logoAsset.commercialUse ? "✓ verified" : "unverified"}
            </div>
          ) : (
            <div className="mt-4 rounded-2xl border border-white/10 bg-black/20 p-2.5 text-[0.65rem] text-white/40">
              No legally verified logo asset available. Neutral fallback shown — no imitated logo is generated.
            </div>
          )}
        </section>

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Alliance</p>
            <p className="mt-2 text-xl font-black text-[#FACC15]">{airline.alliance}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Country</p>
            <p className="mt-2 text-xl font-black text-white">{country ? `${country.flagEmoji} ` : ""}{airline.country}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Status</p>
            <p className="mt-2 text-xl font-black text-white">{airline.active !== false ? "Active" : "Inactive"}</p>
          </div>
        </div>

        <section className="rounded-[2rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.15),rgba(255,255,255,0.055)_38%)] p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Your flights</h2>
            <span className="rounded-full border border-yellow-300/30 bg-yellow-300/10 px-2.5 py-1 text-[0.6rem] font-bold uppercase tracking-[0.14em] text-yellow-100">Demo logbook</span>
          </div>
          {airlineFlights.length > 0 ? (
            <div className="mt-4 grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-[#FACC15]">{airlineFlights.length}</p><p className="text-xs text-white/40">Flights</p></div>
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-white">{formatDistance(airlineDistance)}</p><p className="text-xs text-white/40">Distance</p></div>
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-white">{formatDuration(airlineTime)}</p><p className="text-xs text-white/40">Time</p></div>
            </div>
          ) : (
            <p className="mt-4 text-sm italic text-white/30">No flights with this airline in your demo logbook</p>
          )}
        </section>

        {aircraftTypes.length > 0 ? (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">Fleet flown</h2>
              <span className="text-[0.6rem] uppercase tracking-[0.14em] text-white/35">Demo logbook</span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {aircraftTypes.map((type) => (
                <Link key={type} href={`/aircraft/${encodeURIComponent(type)}`} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/70 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">{type}</Link>
              ))}
            </div>
          </section>
        ) : null}

        {destinations.length > 0 ? (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">Destinations</h2>
              <span className="text-[0.6rem] uppercase tracking-[0.14em] text-white/35">Demo logbook</span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {destinations.map((dest) => (
                <Link key={dest} href={`/airports/${dest}`} className="rounded-full border border-[#FACC15]/20 bg-[#FACC15]/10 px-3 py-1.5 text-xs font-semibold text-[#FACC15]">{dest}</Link>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}
