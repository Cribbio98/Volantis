import Link from "next/link";
import { searchAviation } from "@/services/searchService";

export const dynamic = "force-dynamic";

const categoryLabels: Record<string, string> = {
  airport: "Airports",
  airline: "Airlines",
  aircraft: "Aircraft",
  country: "Countries",
};

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const query = q ?? "";
  const results = query.length > 0 ? searchAviation(query) : [];
  const grouped = new Map<string, typeof results>();
  for (const r of results) {
    const existing = grouped.get(r.category) ?? [];
    existing.push(r);
    grouped.set(r.category, existing);
  }

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">← Command center</Link>

        <section className="rounded-[2.25rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Aviation search</p>
          <h1 className="mt-2 text-3xl font-black tracking-[-0.07em] text-white">Search everything</h1>
          <form className="mt-4 flex gap-3">
            <input name="q" defaultValue={query} placeholder="Search airports, airlines, aircraft, countries..." className="flex-1 rounded-2xl border border-white/15 bg-black/35 px-5 py-3.5 text-white placeholder-white/30 outline-none transition focus:border-[#FACC15]/50" autoFocus />
            <button type="submit" className="rounded-2xl bg-[#FACC15] px-6 py-3.5 text-sm font-black uppercase tracking-[0.14em] text-black">Search</button>
          </form>
        </section>

        {query.length > 0 && results.length === 0 ? (
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-8 text-center backdrop-blur-xl">
            <p className="text-lg text-white/50">No results for &ldquo;{query}&rdquo;</p>
          </div>
        ) : null}

        {Array.from(grouped.entries()).map(([category, items]) => (
          <section key={category} className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <h2 className="text-lg font-bold text-white">{categoryLabels[category] ?? category}</h2>
            <div className="mt-4 space-y-2">
              {items.map((item, index) => (
                <Link key={`${category}-${index}`} href={item.href} className="flex items-center gap-3 rounded-2xl bg-black/25 p-3 transition hover:bg-white/[0.08]">
                  <span className="text-lg">{item.emoji}</span>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-white">{item.label}</p>
                    <p className="text-xs text-white/45">{item.sublabel}</p>
                  </div>
                  <span className="text-white/25">→</span>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
