import Link from "next/link";
import { formatDistance, formatDuration } from "@/lib/formatters";
import { getLogbook, getLogbookStatistics } from "@/services/logbookService";

export const dynamic = "force-dynamic";

export default async function LogbookPage() {
  const entries = getLogbook();
  const stats = getLogbookStatistics();

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">← Command center</Link>

        <section className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.2),rgba(255,255,255,0.075)_36%)] p-6 backdrop-blur-xl">
          <p className="text-xs font-black uppercase tracking-[0.24em] text-[#FACC15]">Flight logbook</p>
          <h1 className="mt-2 text-5xl font-black tracking-[-0.08em] text-white">Aviation logbook</h1>
          <div className="mt-5 grid grid-cols-3 gap-3">
            <div className="rounded-3xl bg-black/25 p-4 text-center"><p className="text-3xl font-black text-[#FACC15]">{stats.totalFlights}</p><p className="text-xs text-white/40">Flights</p></div>
            <div className="rounded-3xl bg-black/25 p-4 text-center"><p className="text-2xl font-black text-white">{formatDistance(stats.totalDistanceKm)}</p><p className="text-xs text-white/40">Distance</p></div>
            <div className="rounded-3xl bg-black/25 p-4 text-center"><p className="text-2xl font-black text-white">{formatDuration(stats.totalFlightTimeMinutes)}</p><p className="text-xs text-white/40">Time</p></div>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Statistics</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Most flown airline</p><p className="mt-1 text-lg font-black text-[#FACC15]">{stats.mostFlownAirline.name}</p><p className="text-xs text-white/45">{stats.mostFlownAirline.count} flights</p></div>
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Most visited airport</p><p className="mt-1 text-lg font-black text-[#FACC15]">{stats.mostVisitedAirport.iata} — {stats.mostVisitedAirport.city}</p><p className="text-xs text-white/45">{stats.mostVisitedAirport.count} visits</p></div>
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Most flown aircraft</p><p className="mt-1 text-lg font-black text-[#FACC15]">{stats.mostFlownAircraft.type}</p><p className="text-xs text-white/45">{stats.mostFlownAircraft.count} flights</p></div>
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Most frequent route</p><p className="mt-1 text-lg font-black text-[#FACC15]">{stats.mostFrequentRoute.origin} → {stats.mostFrequentRoute.destination}</p><p className="text-xs text-white/45">{stats.mostFrequentRoute.count} flights</p></div>
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Longest flight</p><p className="mt-1 font-semibold text-white">{stats.longestFlight.flightNumber} · {stats.longestFlight.originIata} → {stats.longestFlight.destinationIata}</p><p className="text-xs text-white/45">{formatDistance(stats.longestFlight.distanceKm)} · {formatDuration(stats.longestFlight.durationMinutes)}</p></div>
            <div className="rounded-2xl bg-black/25 p-4"><p className="text-xs text-white/40">Shortest flight</p><p className="mt-1 font-semibold text-white">{stats.shortestFlight.flightNumber} · {stats.shortestFlight.originIata} → {stats.shortestFlight.destinationIata}</p><p className="text-xs text-white/45">{formatDistance(stats.shortestFlight.distanceKm)} · {formatDuration(stats.shortestFlight.durationMinutes)}</p></div>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">All flights</h2>
          <div className="mt-4 space-y-2">
            {entries.map((entry) => (
              <div key={entry.id} className="grid grid-cols-[1fr_auto] gap-3 rounded-2xl bg-black/25 p-3">
                <div className="min-w-0">
                  <p className="font-semibold text-white">{entry.flightNumber} · {entry.airlineName}</p>
                  <p className="text-xs text-white/45">{entry.originIata} → {entry.destinationIata} · {entry.departureDate} · {entry.aircraftType}</p>
                </div>
                <div className="text-right text-xs text-white/50">
                  <p>{formatDistance(entry.distanceKm)}</p>
                  <p>{formatDuration(entry.durationMinutes)}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
