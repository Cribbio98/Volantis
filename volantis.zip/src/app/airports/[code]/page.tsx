import Link from "next/link";
import { getAirportIntelligence } from "@/services/airportService";
import { weatherProvider } from "@/services/providers/weatherProvider";
import { getAirportPhoto } from "@/services/repositories/airportMediaRepository";
import { AirportMap } from "@/components/volantis/AirportMap";

export const dynamic = "force-dynamic";

function DataField({ label, value, mono = false }: { label: string; value: string | number | null | undefined; mono?: boolean }) {
  return (
    <div className="rounded-2xl bg-black/25 p-4">
      <p className="text-xs text-white/40">{label}</p>
      {value !== null && value !== undefined && value !== "" ? (
        <p className={`mt-1 font-semibold text-white ${mono ? "font-mono" : ""}`}>{value}</p>
      ) : (
        <p className="mt-1 text-sm italic text-white/30">Data unavailable</p>
      )}
    </div>
  );
}

export default async function AirportPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const { airport, country, flagSvgUrl, operational, googleMapsUrl } = await getAirportIntelligence(decodeURIComponent(code));
  let photo = null;
  try {
    photo = await getAirportPhoto(airport.iata);
  } catch {
    photo = null;
  }
  let weather = null;
  try {
    weather = await weatherProvider.getCurrentWeather(airport.latitude, airport.longitude);
  } catch {
    weather = null;
  }

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-24 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">
          ← Command center
        </Link>

        <section className="overflow-hidden rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.06)_38%,rgba(255,255,255,0.035))] backdrop-blur-xl">
          {photo?.url ? (
            <div className="relative h-48 sm:h-64">
              <img src={photo.thumbnailUrl ?? photo.url} alt={airport.name} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#02040a] via-[#02040a]/40 to-transparent" />
              {photo.sourcePageUrl ? (
                <a href={photo.sourcePageUrl} target="_blank" rel="noreferrer" className="absolute bottom-3 right-3 rounded-full bg-black/50 px-2.5 py-1 text-[0.6rem] text-white/60 backdrop-blur hover:text-[#FACC15]">
                  Photo: {photo.attribution || "Wikimedia Commons"} · {photo.license}
                </a>
              ) : null}
            </div>
          ) : null}
          <div className="p-6">
            <p className="text-xs font-black uppercase tracking-[0.24em] text-[#FACC15]">Airport intelligence</p>
            <div className="mt-4 flex flex-wrap items-end justify-between gap-5">
              <div>
                <h1 className="text-6xl font-black tracking-[-0.08em] text-white">{airport.iata}</h1>
                <p className="mt-2 text-xl font-semibold text-white">{airport.name}</p>
                <p className="text-white/50">
                  {airport.city || "City data unavailable"}, {airport.country || "Country data unavailable"} · {airport.icao} {country ? `${country.flagEmoji}` : ""}
                </p>
                <p className="mt-1 text-sm text-white/40">
                  {airport.elevationFt ? `Elevation ${airport.elevationFt} ft` : "Elevation data unavailable"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {flagSvgUrl ? <img src={flagSvgUrl} alt={`${airport.country} flag`} className="h-10 w-auto self-center rounded" /> : null}
                <a href={googleMapsUrl} target="_blank" rel="noreferrer" className="rounded-full bg-[#FACC15] px-5 py-3 text-xs font-black uppercase tracking-[0.16em] text-black">
                  Google Maps
                </a>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {airport.dataSourceInfo ? (
                <span className="rounded-full border border-emerald-300/20 bg-emerald-300/5 px-3 py-1.5 text-[0.65rem] text-emerald-100/80">
                  Data: {airport.dataSourceInfo.provider} · {airport.dataSourceInfo.license}
                </span>
              ) : null}
              {photo ? (
                <span className="rounded-full border border-sky-300/20 bg-sky-300/5 px-3 py-1.5 text-[0.65rem] text-sky-100/80">
                  Photo: Wikimedia Commons · {photo.license} · Commercial {photo.commercialUse ? "✓" : "unverified"}
                </span>
              ) : null}
            </div>
          </div>
        </section>

        <AirportMap airport={airport} />

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Overview</h2>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <DataField label="ICAO code" value={airport.icao} mono />
            <DataField label="Local time zone" value={airport.timezone} />
            <DataField label="Airport type" value={airport.type ? airport.type.replace(/_/g, " ") : null} />
            <DataField label="Scheduled service" value={operational.scheduledService === null ? null : operational.scheduledService ? "Yes" : "No"} />
            <DataField label="Terminals" value={operational.terminalInfo} />
            <DataField label="Runways" value={operational.availableRunways} />
          </div>
          <p className="mt-4 text-xs text-white/35">{operational.feedNote}</p>
        </section>

        {weather ? (
          <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <div className="flex items-start justify-between">
              <h2 className="text-lg font-bold text-white">Current weather</h2>
              <span className="rounded-full bg-black/30 px-2 py-1 text-[0.6rem] uppercase tracking-[0.14em] text-white/40">{weather.dataSourceInfo.provider} · {weather.dataSourceInfo.license}</span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-white">{weather.temperatureC.toFixed(1)}°C</p><p className="text-xs text-white/40">Temperature</p></div>
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-white">{weather.windSpeedKts} kt</p><p className="text-xs text-white/40">Wind {weather.windDirectionDeg}°</p></div>
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-2xl font-black text-white">{weather.cloudCoverPct ?? "—"}%</p><p className="text-xs text-white/40">Cloud cover</p></div>
              <div className="rounded-2xl bg-black/25 p-3 text-center"><p className="text-lg font-black text-white">{weather.weatherDescription ?? "—"}</p><p className="text-xs text-white/40">Conditions</p></div>
            </div>
          </section>
        ) : null}

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Runways ({airport.runways?.length ?? 0})</h2>
          {airport.runways && airport.runways.length > 0 ? (
            <div className="mt-4 space-y-2">
              {airport.runways.map((runway) => (
                <div key={runway.name} className="rounded-2xl bg-black/25 p-3 text-sm">
                  <span className="font-semibold text-white">{runway.name}</span>
                  <span className="ml-2 text-white/45">
                    {runway.lengthMeters ? `${runway.lengthMeters.toLocaleString("en")} m` : runway.lengthFt ? `${runway.lengthFt.toLocaleString("en")} ft` : "Length data unavailable"} · {runway.surface ?? "Surface data unavailable"} · {runway.headingDeg !== undefined ? `${runway.headingDeg.toFixed(0)}°` : "Heading unknown"}{runway.closed ? " · CLOSED" : ""}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm italic text-white/30">Runway data unavailable</p>
          )}
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Departures &amp; arrivals</h2>
          <p className="mt-3 rounded-2xl bg-black/25 p-4 text-sm text-white/45">
            Real-time departure and arrival boards are available once the AeroDataBox FIDS provider is activated. Currently in DEMO mode — no fabricated schedules are shown.
          </p>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Links</h2>
          <div className="mt-4 space-y-2">
            {airport.homeLink ? <a href={airport.homeLink} target="_blank" rel="noreferrer" className="block rounded-2xl bg-black/25 p-3 text-sm text-[#FACC15] hover:underline">{airport.homeLink}</a> : null}
            {airport.wikipediaLink ? <a href={airport.wikipediaLink} target="_blank" rel="noreferrer" className="block rounded-2xl bg-black/25 p-3 text-sm text-[#FACC15] hover:underline">Wikipedia</a> : null}
            {!airport.homeLink && !airport.wikipediaLink ? <p className="text-sm italic text-white/30">External links data unavailable</p> : null}
          </div>
        </section>
      </div>
    </main>
  );
}
