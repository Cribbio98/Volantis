import Link from "next/link";
import { notFound } from "next/navigation";
import { AircraftViewer } from "@/components/volantis/AircraftViewer";
import { AirlineLogo } from "@/components/volantis/AirlineLogo";
import { AirportIntelligenceCard } from "@/components/volantis/AirportIntelligenceCard";
import { DataSourceBadge } from "@/components/volantis/DataSourceBadge";
import { FlightTimeline } from "@/components/volantis/FlightTimeline";
import { LiveFlightExperience } from "@/components/volantis/LiveFlightExperience";
import { RouteStrip } from "@/components/volantis/RouteStrip";
import { formatAltitude, formatDateTime, formatDistance, formatDuration, formatHeading, formatSpeed, statusLabel } from "@/lib/formatters";
import { getFlightByNumber } from "@/services/flightService";
import { getAircraftTelemetrySnapshot } from "@/services/flightTelemetryService";

export const dynamic = "force-dynamic";

export default async function FlightDetailPage({ params }: { params: Promise<{ flightNumber: string }> }) {
  const { flightNumber } = await params;
  const flight = await getFlightByNumber(decodeURIComponent(flightNumber));

  if (!flight) {
    notFound();
  }

  const telemetry = getAircraftTelemetrySnapshot(flight);

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-6xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">
          ← Command center
        </Link>

        <section className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.06)_38%,rgba(255,255,255,0.035))] p-5 backdrop-blur-xl sm:p-7">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div className="flex min-w-0 items-center gap-4">
              <AirlineLogo airline={flight.airline} size="lg" />
              <div className="min-w-0">
                <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Flight detail</p>
                <h1 className="mt-1 truncate text-4xl font-black tracking-[-0.07em] text-white sm:text-6xl">{flight.flightNumber}</h1>
                <p className="text-sm text-white/58">{flight.airline.name} · {flight.aircraft.type}</p>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <DataSourceBadge source={flight.dataSource} />
              <span className="rounded-full border border-white/10 bg-black/25 px-3 py-1.5 text-xs font-black uppercase tracking-[0.16em] text-white/60">
                {statusLabel(flight.status)}
              </span>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-[1fr_auto_1fr] items-end gap-4">
            <div>
              <p className="text-5xl font-black tracking-[-0.08em] text-white">{flight.origin.iata}</p>
              <p className="text-sm text-white/50">{flight.origin.city} · {flight.origin.name}</p>
            </div>
            <div className="pb-4 text-center text-xs uppercase tracking-[0.18em] text-white/45">{formatDuration(flight.durationMinutes)}</div>
            <div className="text-right">
              <p className="text-5xl font-black tracking-[-0.08em] text-white">{flight.destination.iata}</p>
              <p className="text-sm text-white/50">{flight.destination.city} · {flight.destination.name}</p>
            </div>
          </div>

          <RouteStrip flight={flight} emphasis />
        </section>

        <LiveFlightExperience initialFlight={flight} />

        <section className="grid gap-4 md:grid-cols-4">
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Departure</p>
            <p className="mt-2 text-lg font-black text-white">{formatDateTime(flight.estimatedDeparture ?? flight.scheduledDeparture)}</p>
            <p className="mt-1 text-sm text-white/50">Terminal {flight.terminal ?? "—"} · Gate {flight.gate ?? "—"}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Arrival</p>
            <p className="mt-2 text-lg font-black text-white">{formatDateTime(flight.estimatedArrival ?? flight.scheduledArrival)}</p>
            <p className="mt-1 text-sm text-white/50">Terminal {flight.arrivalTerminal ?? "—"} · Gate {flight.arrivalGate ?? "—"}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Live position</p>
            <p className="mt-2 font-mono text-sm font-black text-white">{telemetry.latitude.toFixed(4)}, {telemetry.longitude.toFixed(4)}</p>
            <p className="mt-1 text-sm text-white/50">{telemetry.label}</p>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-xs text-white/40">Telemetry</p>
            <p className="mt-2 text-sm font-black text-white">{formatAltitude(telemetry.altitudeFt)} · {formatSpeed(telemetry.groundSpeedKt)}</p>
            <p className="mt-1 text-sm text-white/50">HDG {formatHeading(telemetry.headingDeg)} · {formatDistance(telemetry.remainingDistanceKm)} left</p>
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1fr_0.9fr]">
          <AircraftViewer flight={flight} />
          <FlightTimeline flight={flight} />
        </div>

        <div className="grid gap-5 lg:grid-cols-2">
          <AirportIntelligenceCard code={flight.origin.iata} title="Departure airport" />
          <AirportIntelligenceCard code={flight.destination.iata} title="Arrival airport" />
        </div>
      </div>
    </main>
  );
}
