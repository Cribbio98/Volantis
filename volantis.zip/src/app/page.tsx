import { AirportIntelligenceCard } from "@/components/volantis/AirportIntelligenceCard";
import { AppHeader } from "@/components/volantis/AppHeader";
import { BottomNav } from "@/components/volantis/BottomNav";
import { DirectoriesPanel } from "@/components/volantis/DirectoriesPanel";
import { FlightCard } from "@/components/volantis/FlightCard";
import { NextFlightHero } from "@/components/volantis/NextFlightHero";
import { TravelPassportPanel } from "@/components/volantis/TravelPassportPanel";
import { TripPanel } from "@/components/volantis/TripPanel";
import { formatDateTime } from "@/lib/formatters";
import { getFlightDashboard } from "@/services/flightService";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const dashboard = await getFlightDashboard();
  const { nextFlight, flights } = dashboard;

  return (
    <main className="min-h-screen px-4 pb-32 text-white sm:px-6">
      <AppHeader source={dashboard.dataSource} offline={dashboard.offline} />

      <div className="mx-auto max-w-6xl space-y-6 pt-5">
        <section className="flex items-center justify-between gap-4 rounded-[2rem] border border-white/10 bg-white/[0.045] p-4 backdrop-blur-xl">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Android-first preview</p>
            <h2 className="mt-1 text-2xl font-black tracking-[-0.06em] text-white">Premium flight tracking, not simulated certainty.</h2>
          </div>
          <div className="hidden rounded-2xl bg-black/30 p-3 text-right text-xs text-white/45 sm:block">
            <p>Updated</p>
            <p className="font-semibold text-white/70">{formatDateTime(dashboard.updatedAt)}</p>
          </div>
        </section>

        <NextFlightHero flight={nextFlight} />

        <section id="flights" className="space-y-4">
          <div className="flex items-end justify-between gap-4 px-1">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">Flight cards</p>
              <h2 className="text-2xl font-black tracking-[-0.06em] text-white">Upcoming and active flights</h2>
            </div>
            <span className="rounded-full border border-white/10 px-3 py-1.5 text-xs font-bold text-white/45">{flights.length} tracked</span>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            {flights.map((flight) => (
              <FlightCard key={flight.id} flight={flight} />
            ))}
          </div>
        </section>

        <section id="airports" className="grid gap-5 lg:grid-cols-2">
          <AirportIntelligenceCard code={nextFlight.origin.iata} title="Departure intelligence" />
          <AirportIntelligenceCard code={nextFlight.destination.iata} title="Arrival intelligence" />
        </section>

        <section id="passport" className="grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
          <TravelPassportPanel />
          <TripPanel />
        </section>

        <section id="directory">
          <DirectoriesPanel flights={flights} />
        </section>
      </div>

      <BottomNav />
    </main>
  );
}
