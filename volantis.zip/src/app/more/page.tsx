import Link from "next/link";
import { detailedAircraftSpecs } from "@/data/aircraft";
import { airlineRegistry } from "@/data/airlines";
import { airportRegistry } from "@/data/airports";

export default async function MorePage() {
  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">← Command center</Link>

        <section className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.18),rgba(255,255,255,0.06)_38%,rgba(255,255,255,0.035))] p-6 backdrop-blur-xl">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-[#FACC15]">More</p>
          <h1 className="mt-2 text-4xl font-black tracking-[-0.07em] text-white">Volantis</h1>
          <p className="text-sm text-white/50">Aviation intelligence at your fingertips.</p>
        </section>

        <section className="grid gap-3 sm:grid-cols-2">
          <Link href="/passport" className="group rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl transition hover:border-[#FACC15]/45">
            <p className="text-2xl">🛂</p>
            <h2 className="mt-2 text-lg font-bold text-white group-hover:text-[#FACC15]">Passport</h2>
            <p className="text-sm text-white/45">Countries, airports, stamps</p>
          </Link>
          <Link href="/logbook" className="group rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl transition hover:border-[#FACC15]/45">
            <p className="text-2xl">📋</p>
            <h2 className="mt-2 text-lg font-bold text-white group-hover:text-[#FACC15]">Logbook</h2>
            <p className="text-sm text-white/45">Flight history and statistics</p>
          </Link>
          <Link href="/search" className="group rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl transition hover:border-[#FACC15]/45">
            <p className="text-2xl">🔍</p>
            <h2 className="mt-2 text-lg font-bold text-white group-hover:text-[#FACC15]">Search</h2>
            <p className="text-sm text-white/45">Find airports, airlines, aircraft</p>
          </Link>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
            <p className="text-2xl">⚙️</p>
            <h2 className="mt-2 text-lg font-bold text-white/50">Settings</h2>
            <p className="text-sm text-white/30">Coming soon</p>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Airlines</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {airlineRegistry.map((airline) => (
              <Link key={airline.iata} href={`/airlines/${airline.iata}`} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/70 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">{airline.iata} {airline.name}</Link>
            ))}
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Aircraft</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {detailedAircraftSpecs.map((aircraft) => (
              <Link key={aircraft.icaoCode} href={`/aircraft/${encodeURIComponent(aircraft.model)}`} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/70 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">{aircraft.icaoCode} {aircraft.model}</Link>
            ))}
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Airports</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {airportRegistry.map((airport) => (
              <Link key={airport.iata} href={`/airports/${airport.iata}`} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/70 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">{airport.iata} {airport.city}</Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
