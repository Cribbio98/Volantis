import Link from "next/link";
import { formatDistance, formatDuration } from "@/lib/formatters";
import { getLogbookStatistics } from "@/services/logbookService";
import { countryRepository } from "@/services/repositories/countryRepository";

export const dynamic = "force-dynamic";

export default async function PassportPage() {
  const stats = getLogbookStatistics();
  const allCountries = countryRepository.getAll();
  const visitedCountryNames = new Set(stats.countriesVisited.map((c) => c.name));
  const worldCoveragePercent = ((visitedCountryNames.size / allCountries.length) * 100).toFixed(1);

  return (
    <main className="min-h-screen bg-[#02040a] px-4 pb-28 pt-6 text-white sm:px-6">
      <div className="mx-auto max-w-4xl space-y-5">
        <Link href="/" className="inline-flex rounded-full border border-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-white/60 transition hover:border-[#FACC15]/40 hover:text-[#FACC15]">
          ← Command center
        </Link>

        <section className="rounded-[2.25rem] border border-[#FACC15]/20 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.22),rgba(255,255,255,0.075)_36%,rgba(255,255,255,0.04))] p-6 backdrop-blur-xl">
          <p className="text-xs font-black uppercase tracking-[0.24em] text-[#FACC15]">Travel passport</p>
          <h1 className="mt-2 text-5xl font-black tracking-[-0.08em] text-white">Aviation passport</h1>
          <p className="mt-3 text-lg text-white/50">Your personal flight history, countries explored, and aviation milestones.</p>
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-3xl bg-black/25 p-4 text-center">
              <p className="text-3xl font-black text-[#FACC15]">{stats.totalFlights}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-white/40">Flights</p>
            </div>
            <div className="rounded-3xl bg-black/25 p-4 text-center">
              <p className="text-2xl font-black text-white">{formatDistance(stats.totalDistanceKm)}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-white/40">Distance</p>
            </div>
            <div className="rounded-3xl bg-black/25 p-4 text-center">
              <p className="text-2xl font-black text-white">{formatDuration(stats.totalFlightTimeMinutes)}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-white/40">Time aloft</p>
            </div>
            <div className="rounded-3xl bg-black/25 p-4 text-center">
              <p className="text-3xl font-black text-white">{visitedCountryNames.size}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-white/40">Countries</p>
            </div>
          </div>
          <div className="mt-5 rounded-3xl border border-[#FACC15]/30 bg-[#FACC15]/10 p-4 text-center">
            <p className="text-sm font-bold text-[#FACC15]">{visitedCountryNames.size} countries · {worldCoveragePercent}% of the world</p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-black/30">
              <div className="h-full rounded-full bg-[#FACC15] shadow-[0_0_18px_rgba(250,204,21,0.5)]" style={{ width: `${Math.min(100, parseFloat(worldCoveragePercent))}%` }} />
            </div>
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Countries visited</h2>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {stats.countriesVisited.map((c) => {
              const country = countryRepository.getAll().find((cr) => cr.name === c.name);
              return (
                <div key={c.name} className="rounded-2xl bg-black/25 p-4">
                  <p className="text-lg font-black text-white">{country ? country.flagEmoji : "🌍"} {c.name}</p>
                  <p className="mt-1 text-sm text-white/45">{c.count} flight{c.count !== 1 ? "s" : ""}</p>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Airport stamps</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {stats.airportsVisited.map((a) => (
              <Link key={a.iata} href={`/airports/${a.iata}`} className="min-w-28 rounded-2xl border border-white/10 bg-black/25 p-3 text-center transition hover:border-[#FACC15]/30">
                <p className="text-xl font-black text-[#FACC15]">{a.iata}</p>
                <p className="mt-1 text-xs text-white/45">{a.city} · {a.count}×</p>
              </Link>
            ))}
          </div>
        </section>

        <section className="rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl">
          <h2 className="text-lg font-bold text-white">Airlines flown</h2>
          <div className="mt-4 space-y-2">
            {stats.airlinesFlown.map((a) => (
              <Link key={a.iata} href={`/airlines/${a.iata}`} className="flex items-center justify-between rounded-2xl bg-black/25 p-3 transition hover:bg-white/[0.08]">
                <div><p className="font-semibold text-white">{a.name}</p><p className="text-xs text-white/45">{a.iata} · {a.count} flights</p></div>
                <p className="text-sm font-semibold text-white/70">{formatDistance(a.distanceKm)}</p>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
