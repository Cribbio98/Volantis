import { getFlightByNumber, getFlightDashboard } from "@/services/flightService";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const flightNumber = searchParams.get("flightNumber");
  const dateLocal = searchParams.get("dateLocal") ?? undefined;

  if (flightNumber) {
    const flight = await getFlightByNumber(flightNumber, dateLocal);
    if (!flight) {
      return Response.json({ ok: false, error: "Flight not found" }, { status: 404 });
    }

    return Response.json(
      {
        ok: true,
        flight,
        updatedAt: new Date().toISOString(),
      },
      {
        headers: {
          "Cache-Control": "no-store, max-age=0",
        },
      },
    );
  }

  const dashboard = await getFlightDashboard();
  return Response.json(
    {
      ok: true,
      dashboard,
    },
    {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    },
  );
}
