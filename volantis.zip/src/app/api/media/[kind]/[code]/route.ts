import { findAirport } from "@/data/airports";
import { findAirline } from "@/data/airlines";
import { getAirportFromDb } from "@/services/dataProviders/ourAirportsProvider";
import { getAirlineFromDb } from "@/services/dataProviders/openFlightsProvider";
import { mediaProviderChain } from "@/services/providers/mediaProviderChain";
import type { MediaSubject } from "@/services/providers/mediaProvider";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ kind: string; code: string }> }) {
  const { kind, code } = await context.params;
  const normalizedCode = code.toUpperCase();

  if (kind === "airport-photo") {
    const dbAirport = await getAirportFromDb(normalizedCode);
    const airport = dbAirport ?? findAirport(normalizedCode);
    if (!airport) return Response.json({ ok: false, error: "Airport not found" }, { status: 404 });
    const subject: MediaSubject = { code: airport.iata, name: airport.name, city: airport.city, country: airport.countryIso, aliases: [airport.icao] };
    const { asset, provider, degraded } = await mediaProviderChain.find("airport-photo", subject);
    return Response.json({
      ok: true,
      asset,
      provider,
      degraded,
      cached: false,
      validationRun: true,
      note: asset?.commercialUse
        ? "License verified as compatible with commercial use."
        : asset
          ? "Found an image but its license does not clearly permit commercial use, so it is flagged as non-commercial."
          : degraded
            ? "No verified asset; external provider currently rate-limited/unavailable (HTTP 429/5xx). Negative-cached to avoid repeated calls."
            : "No legally verified asset found after entity validation.",
      health: mediaProviderChain.getHealth(),
    });
  }

  if (kind === "airline-logo") {
    const curated = findAirline(normalizedCode);
    let subject: MediaSubject | null = null;

    if (curated) {
      subject = { code: curated.iata, name: curated.name, aliases: [curated.icao] };
    } else {
      const dbAirline = await getAirlineFromDb(normalizedCode);
      if (!dbAirline) return Response.json({ ok: false, error: "Airline not found" }, { status: 404 });
      subject = { code: dbAirline.iata, name: dbAirline.name, aliases: [dbAirline.icao] };
    }

    const { asset, provider, degraded } = await mediaProviderChain.find("airline-logo", subject);
    return Response.json({
      ok: true,
      asset,
      provider,
      degraded,
      validationRun: true,
      note: asset?.commercialUse
        ? "License verified as compatible with commercial use."
        : asset
          ? "Logo found but license unverified — not used as production logo."
          : degraded
            ? "Provider currently rate-limited; neutral fallback retained."
            : "No verified logo asset found after entity validation.",
      health: mediaProviderChain.getHealth(),
    });
  }

  return Response.json({ ok: false, error: "Unknown media kind" }, { status: 400 });
}
