import { getCachedAsset } from "@/services/repositories/mediaCacheRepository";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const kind = searchParams.get("kind");
  const code = searchParams.get("code")?.toUpperCase();

  if (!kind || !code) {
    return Response.json({ ok: false, error: "kind and code required" }, { status: 400 });
  }

  const mediaType = kind === "airline-logo" ? "airline-logo" : kind === "airport-photo" ? "airport-photo" : kind === "aircraft-photo" ? "aircraft-photo" : null;
  if (!mediaType) return Response.json({ ok: false, error: "invalid kind" }, { status: 400 });

  const asset = await getCachedAsset(mediaType as "airport-photo" | "airline-logo" | "aircraft-photo", code);
  return Response.json({
    ok: true,
    found: Boolean(asset),
    asset,
    commercialUse: asset?.commercialUse ?? false,
    license: asset?.license,
  }, {
    headers: { "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400" },
  });
}
