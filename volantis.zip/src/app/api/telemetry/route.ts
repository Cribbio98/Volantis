import { getFlightByNumber } from "@/services/flightService";
import { getAircraftTelemetrySnapshot, getFlightRouteTelemetry } from "@/services/flightTelemetryService";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const flightNumber = searchParams.get("flightNumber");

  if (!flightNumber) {
    return Response.json({ ok: false, error: "flightNumber is required" }, { status: 400 });
  }

  const flight = await getFlightByNumber(flightNumber, searchParams.get("dateLocal") ?? undefined);
  if (!flight) {
    return Response.json({ ok: false, error: "Flight not found" }, { status: 404 });
  }

  return Response.json(
    {
      ok: true,
      telemetry: getAircraftTelemetrySnapshot(flight),
      route: getFlightRouteTelemetry(flight),
      updatedAt: new Date().toISOString(),
    },
    {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    },
  );
}
