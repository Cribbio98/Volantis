import { getAirportRepository } from "@/services/repositories/airportRepository";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const iata = searchParams.get("iata") ?? undefined;
  const icao = searchParams.get("icao") ?? undefined;
  const name = searchParams.get("name") ?? undefined;
  const city = searchParams.get("city") ?? undefined;
  const country = searchParams.get("country") ?? undefined;
  const limit = parseInt(searchParams.get("limit") ?? "24", 10);

  if (!iata && !icao && !name && !city && !country) {
    return Response.json({ ok: false, error: "At least one search parameter is required (iata, icao, name, city, country)" }, { status: 400 });
  }

  const repository = getAirportRepository();
  const airports = await repository.search({ iata, icao, name, city, country }, limit);

  return Response.json({
    ok: true,
    count: airports.length,
    airports,
    dataSource: airports.length > 0 && airports[0].dataSourceInfo ? airports[0].dataSourceInfo.source : "fallback",
  });
}
