import { getAirportIntelligence } from "@/services/airportService";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ code: string }> }) {
  const { code } = await context.params;
  const intelligence = getAirportIntelligence(code);

  return Response.json(
    {
      ok: true,
      intelligence,
      googleMapsOptional: true,
    },
    {
      headers: {
        "Cache-Control": "public, max-age=300, stale-while-revalidate=3600",
      },
    },
  );
}
