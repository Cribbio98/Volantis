import { openskyProvider } from "@/services/providers/openskyProvider";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const callsign = searchParams.get("callsign");
  const minLat = parseFloat(searchParams.get("minLat") ?? "-90");
  const maxLat = parseFloat(searchParams.get("maxLat") ?? "90");
  const minLon = parseFloat(searchParams.get("minLon") ?? "-180");
  const maxLon = parseFloat(searchParams.get("maxLon") ?? "180");

  try {
    if (callsign) {
      const result = await openskyProvider.getAircraftByCallsign(callsign, { minLat, maxLat, minLon, maxLon });
      return Response.json({
        ok: true,
        result,
        source: openskyProvider.sourceName,
        health: openskyProvider.getHealthStatus(),
      });
    }

    const states = await openskyProvider.getStatesByBounds({ minLat, maxLat, minLon, maxLon });
    return Response.json({
      ok: true,
      count: states.length,
      states: states.slice(0, 100),
      source: openskyProvider.sourceName,
      health: openskyProvider.getHealthStatus(),
    });
  } catch (error) {
    return Response.json({ ok: false, error: error instanceof Error ? error.message : "OpenSky error" }, { status: 500 });
  }
}
