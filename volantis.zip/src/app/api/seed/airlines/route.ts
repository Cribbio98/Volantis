import { seedAirlinesFromOpenFlights } from "@/services/dataProviders/openFlightsProvider";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const result = await seedAirlinesFromOpenFlights();
    return Response.json({ ok: true, ...result, providerUrl: "https://github.com/jpatokal/openflights/tree/master/data", licenseVerification: "ODbL-1.0 (Open Database License). Attribution required. Share-alike for derived databases. Commercial use permitted. No API key. No credit card. No quota on raw GitHub data." });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
