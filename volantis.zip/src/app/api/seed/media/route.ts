import { airlineRegistry } from "@/data/airlines";
import { airportRegistry } from "@/data/airports";
import { getLogbook } from "@/services/logbookService";
import { getAirlineFromDb } from "@/services/dataProviders/openFlightsProvider";
import { mediaProviderChain } from "@/services/providers/mediaProviderChain";
import { getMediaStats, getCachedAsset, resolveAirportPhoto, resolveAirlineLogo } from "@/services/repositories/mediaCacheRepository";

export const dynamic = "force-dynamic";

const PRIORITY_AIRLINES = ["BA", "UA", "DL", "AF", "LH", "NH", "EK", "QR", "AA", "KL", "IB", "VS", "LX", "AZ", "TK", "SQ", "CX", "AC", "Q", "AZ"];
const PRIORITY_AIRPORTS = ["JFK", "LHR", "CDG", "FRA", "HND", "DXB", "SFO", "DOH", "FCO", "MAD", "AMS", "SIN", "ICN", "ORD", "LAX", "PEK", "YYZ", "ATL", "GRU", "JNB", "IST", "DEL", "BKK", "HKG", "MUC", "ZRH", "VIE", "CPH", "ARN", "HEL", "DUB", "LIS", "ATH", "PRG", "WAW"];

function assetSource(asset: { sourcePageUrl?: string; url?: string } | null) {
  return asset?.sourcePageUrl ?? asset?.url;
}

export async function POST(request: Request) {
  const url = new URL(request.url);
  const type = (url.searchParams.get("type") ?? "all").toLowerCase();
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "12", 10) || 12, 100);
  let processed = 0;
  let resolved = 0;
  const report: Array<Record<string, unknown>> = [];

  async function seedAirline(iata: string) {
    const curated = airlineRegistry.find((a) => a.iata === iata);
    const airline = curated ?? (await getAirlineFromDb(iata)) ?? undefined;
    if (!airline) return;
    processed++;
    const cached = await getCachedAsset("airline-logo", airline.iata);
    if (cached) {
      resolved++;
      report.push({ entity: airline.name, found: true, provider: "cache", license: cached.license, commercialUse: cached.commercialUse, sourceUrl: assetSource(cached) });
      return;
    }
    const result = await resolveAirlineLogo(airline.iata, airline.name, { icao: airline.icao, forceRefresh: true });
    if (result) {
      resolved++;
      report.push({ entity: airline.name, found: true, provider: "wikimedia-commons", license: result.license, commercialUse: result.commercialUse, sourceUrl: assetSource(result) });
    } else {
      report.push({ entity: airline.name, found: false, provider: "none" });
    }
    await new Promise((r) => setTimeout(r, 280));
  }

  async function seedAirport(iata: string) {
    const airport = airportRegistry.find((a) => a.iata === iata);
    if (!airport) return;
    processed++;
    const cached = await getCachedAsset("airport-photo", airport.iata);
    if (cached) {
      resolved++;
      report.push({ entity: airport.name, found: true, provider: "cache", license: cached.license, commercialUse: cached.commercialUse, sourceUrl: assetSource(cached) });
      return;
    }
    const result = await resolveAirportPhoto(airport.iata, airport.name, { city: airport.city, country: airport.countryIso, icao: airport.icao, forceRefresh: true });
    if (result) {
      resolved++;
      report.push({ entity: airport.name, found: true, provider: "wikimedia-commons", license: result.license, commercialUse: result.commercialUse, sourceUrl: assetSource(result) });
    } else {
      report.push({ entity: airport.name, found: false, provider: "none" });
    }
    await new Promise((r) => setTimeout(r, 300));
  }

  const airlineOrder = type === "airline" || type === "airlines" || type === "all"
    ? [...new Set([...AIRLINES_FROM_USER, ...PRIORITY_AIRLINES.map((a) => a.toUpperCase()), ...airlineRegistry.map((a) => a.iata)])]
    : [];

  // Additional globally recognized carriers seeded from OpenFlights when not in curated registry.
  const EXTRA_OPENFLIGHTS = ["AA", "KL", "IB", "VS", "LX", "AZ", "TK", "SQ", "CX", "AC"];
  const finalAirlineOrder = type === "airline" || type === "airlines" || type === "all"
    ? [...new Set([...airlineOrder, ...EXTRA_OPENFLIGHTS])]
    : [];

  const airportOrder = type === "airport" || type === "airports" || type === "all"
    ? [...new Set([...PRIORITY_AIRPORTS, ...airportRegistry.map((a) => a.iata)])]
    : [];

  const airlinesToSeed = type === "airline" || type === "airlines" || type === "all" ? finalAirlineOrder.slice(0, limit) : [];
  for (const iata of airlinesToSeed) await seedAirline(iata);
  for (const iata of airportOrder.slice(0, limit)) await seedAirport(iata);

  return Response.json({
    ok: true,
    type,
    limit,
    processed,
    resolved,
    report,
    health: mediaProviderChain.getHealth(),
    cacheStats: await getMediaStats(),
    policy: "Only assets whose individual license allows commercial use can be used as production logos/photographs. When absent, no fake/generated content is substituted.",
  });
}

const AIRLINES_FROM_USER = Array.from(new Set(getLogbook().map((e) => e.airlineIata)));
