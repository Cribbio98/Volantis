import { seedAirportsFromOurAirports } from "@/services/dataProviders/ourAirportsProvider";
import { seedAirlinesFromOpenFlights } from "@/services/dataProviders/openFlightsProvider";

export const dynamic = "force-dynamic";

export async function POST() {
  const results: Record<string, unknown> = {};
  let hasError = false;

  try {
    results.airports = await seedAirportsFromOurAirports();
  } catch (error) {
    results.airports = { error: error instanceof Error ? error.message : "Failed" };
    hasError = true;
  }

  try {
    results.airlines = await seedAirlinesFromOpenFlights();
  } catch (error) {
    results.airlines = { error: error instanceof Error ? error.message : "Failed" };
    hasError = true;
  }

  results.countries = { status: "static", count: 70, source: "ISO 3166 + flagcdn.com", license: "Public domain / free SVG flags" };

  return Response.json({
    ok: !hasError,
    ...results,
    licenseSummary: {
      ourairports: "CC0-1.0 — Public Domain. Commercial use OK. No key. No card. No quota.",
      openflights: "ODbL-1.0 — Attribution + share-alike. Commercial use OK. No key. No card. No quota on GitHub raw.",
      flagcdn: "Free SVG flags from flagpedia.net. Free for any use. No key. No card.",
      iso3166: "ISO 3166 country codes are an ISO standard. The codes themselves are not copyrightable. No key. No card.",
    },
  }, { status: hasError ? 207 : 200 });
}
