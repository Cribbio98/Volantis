import { seedAirportsFromOurAirports } from "@/services/dataProviders/ourAirportsProvider";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const result = await seedAirportsFromOurAirports();
    return Response.json({ ok: true, ...result, providerUrl: "https://davidmegginson.github.io/ourairports-data/", licenseVerification: "CC0-1.0 (Public Domain Dedication). No attribution required. Commercial use permitted. No API key. No credit card. No quota." });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return Response.json({ ok: false, error: message }, { status: 500 });
  }
}
