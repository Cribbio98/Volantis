import { findAirport } from "@/data/airports";
import { weatherProvider } from "@/services/providers/weatherProvider";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const lat = parseFloat(searchParams.get("lat") ?? "");
  const lon = parseFloat(searchParams.get("lon") ?? "");
  const iata = searchParams.get("iata");

  let weather = null;

  if (iata) {
    const airport = findAirport(iata);
    if (airport) {
      weather = await weatherProvider.getCurrentWeather(airport.latitude, airport.longitude);
    }
  } else if (Number.isFinite(lat) && Number.isFinite(lon)) {
    weather = await weatherProvider.getCurrentWeather(lat, lon);
  }

  if (!weather) {
    return Response.json({ ok: false, error: "Weather unavailable" }, { status: 404 });
  }

  return Response.json({
    ok: true,
    weather,
    provider: weatherProvider.sourceName,
    providerHealth: "operational",
  });
}
