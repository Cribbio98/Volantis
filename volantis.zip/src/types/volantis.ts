export type DataSourceState = "LIVE_DATA" | "ESTIMATED_POSITION" | "DEMO_DATA" | "OFFLINE_CACHED";

export type FlightStatus =
  | "Unknown"
  | "Expected"
  | "EnRoute"
  | "CheckIn"
  | "Boarding"
  | "GateClosed"
  | "Departed"
  | "Delayed"
  | "Approaching"
  | "Arrived"
  | "Canceled"
  | "Diverted"
  | "CanceledUncertain";

export type Alliance = "Star Alliance" | "SkyTeam" | "oneworld" | "Independent";

export type DataConfidence = "verified" | "likely" | "approximate" | "unknown";

export type DataSourceInfo = {
  source: string;
  provider: string;
  sourceUrl: string;
  license: string;
  attribution?: string;
  commercialUse: boolean;
  sourceUpdatedAt: string;
  dataConfidence: DataConfidence;
  cachedAt: string;
  retrievedAt?: string;
};

export type MediaAsset = {
  url: string;
  thumbnailUrl?: string;
  sourcePageUrl?: string;
  author?: string;
  license: string;
  licenseUrl?: string;
  attribution?: string;
  commercialUse: boolean;
  retrievedAt: string;
};

export type Coordinate = {
  latitude: number;
  longitude: number;
};

export type AirlineLogo = {
  kind: "brand-safe-mark" | "official-url" | "text-lockup";
  label: string;
  url?: string;
  attribution?: string;
  licensingNote?: string;
};

export type Airline = {
  name: string;
  iata: string;
  icao: string;
  callsign?: string;
  logo: AirlineLogo;
  brandColors: {
    primary: string;
    secondary?: string;
    accent?: string;
  };
  alliance: Alliance;
  country: string;
  countryIso?: string;
  website?: string;
  active?: boolean;
  type?: "scheduled" | "charter" | "cargo" | "private" | "unknown";
  dataSourceInfo?: DataSourceInfo;
};

export type Runway = {
  name: string;
  lengthMeters?: number;
  lengthFt?: number;
  surface?: string;
  headingDeg?: number;
  closed?: boolean;
  lighted?: boolean;
};

export type Airport = Coordinate & {
  iata: string;
  icao: string;
  name: string;
  city: string;
  municipality?: string;
  country: string;
  countryIso?: string;
  elevationFt?: number;
  timezone?: string;
  type?: "large_airport" | "medium_airport" | "small_airport" | "seaplane_base" | "heliport" | "closed" | "unknown";
  terminals?: string[];
  runways?: Runway[];
  runwayCount?: number;
  airlines?: string[];
  website?: string;
  wikipediaLink?: string;
  homeLink?: string;
  scheduledService?: boolean;
  dataSourceInfo?: DataSourceInfo;
};

export type Country = {
  name: string;
  isoAlpha2: string;
  isoAlpha3: string;
  numericCode: number;
  continent: string;
  capital?: string;
  currencyCode?: string;
  currencyName?: string;
  flagSvgUrl: string;
  flagEmoji: string;
};

export type AircraftFamily =
  | "Airbus A220"
  | "Airbus A320"
  | "Airbus A321"
  | "Airbus A330"
  | "Airbus A350"
  | "Airbus A380"
  | "Boeing 737"
  | "Boeing 747"
  | "Boeing 777"
  | "Boeing 787"
  | "Embraer E-Jets"
  | "ATR"
  | "Unknown";

export type Aircraft = {
  type: string;
  family: AircraftFamily;
  manufacturer: string;
  model?: string;
  registration?: string;
  icaoType?: string;
  iataType?: string;
  imageUrl?: string;
  imageAttribution?: string;
  specs?: AircraftSpecs;
  dataSourceInfo?: DataSourceInfo;
};

export type AircraftSpecs = {
  model: string;
  manufacturer: string;
  typicalCruiseKt: number;
  rangeKm: number;
  ceilingFt: number;
  typicalSeats: string;
  engines: string;
};

export type Aircraft3DAsset = {
  icaoType: string;
  assetUrl: string;
  format: "glb" | "gltf";
  license: string;
  licenseUrl?: string;
  attribution?: string;
  isApproximate: boolean;
  sourceName: string;
};

export type AirlineLivery = {
  airlineIata: string;
  tailColor?: string;
  fuselageColor?: string;
  cheatlineColor?: string;
  engineColor?: string;
  wordmark?: string;
  liveryAssetUrl?: string;
  liveryLicense?: string;
  isOfficial: boolean;
  dataSourceInfo?: DataSourceInfo;
};

export type RenderedAircraft = {
  aircraft: Aircraft3DAsset;
  livery?: AirlineLivery;
  effectiveLiveryNote: string;
};

export type FlightTelemetry = Coordinate & {
  altitudeFt?: number;
  groundSpeedKt?: number;
  headingDeg?: number;
  reportedAt: string;
  freshnessSeconds?: number;
  source: DataSourceState;
  dataSourceInfo?: DataSourceInfo;
};

export type BoardingInfo = {
  group?: string;
  startsAt?: string;
  closesAt?: string;
  notes?: string;
};

export type FlightTimelineEvent = {
  label: string;
  at?: string;
  state: "complete" | "active" | "upcoming";
  detail?: string;
};

export type PositionUpdate = Coordinate & {
  altitudeFt?: number;
  groundSpeedKt?: number;
  headingDeg?: number;
  timestampMs: number;
  source: DataSourceState;
};

export type Flight = {
  id: string;
  airline: Airline;
  flightNumber: string;
  callSign?: string;
  status: FlightStatus;
  origin: Airport;
  destination: Airport;
  scheduledDeparture: string;
  scheduledArrival: string;
  estimatedDeparture?: string;
  estimatedArrival?: string;
  actualDeparture?: string;
  actualArrival?: string;
  terminal?: string;
  gate?: string;
  arrivalTerminal?: string;
  arrivalGate?: string;
  boarding?: BoardingInfo;
  aircraft: Aircraft;
  telemetry?: FlightTelemetry;
  lastUpdatedUtc: string;
  dataSource: DataSourceState;
  distanceKm: number;
  durationMinutes: number;
  progressPercent: number;
  remainingDistanceKm: number;
  eta?: string;
  routeCoordinates?: Coordinate[];
  timeline: FlightTimelineEvent[];
  positionHistory?: PositionUpdate[];
};

export type FlightDashboard = {
  nextFlight: Flight;
  flights: Flight[];
  dataSource: DataSourceState;
  offline: boolean;
  updatedAt: string;
};

export type Trip = {
  id: string;
  name: string;
  origin: Airport;
  destination: Airport;
  startsAt: string;
  endsAt: string;
  flights: Flight[];
  destinationImage?: string;
  totalDistanceKm: number;
  totalDurationMinutes: number;
};

export type TravelPassport = {
  countriesVisited: string[];
  airportsVisited: Airport[];
  flightCount: number;
  totalDistanceKm: number;
  totalFlightTimeMinutes: number;
  routes: Array<{ origin: string; destination: string; count: number }>;
  stamps: Array<{ country: string; airport: string; date: string }>;
};

export type AircraftPositionResolution = {
  position: Coordinate;
  source: DataSourceState;
  label: "LIVE DATA" | "ESTIMATED POSITION" | "DEMO DATA" | "OFFLINE / CACHED";
  isAuthoritativeLive: boolean;
  progressPercent: number;
  remainingDistanceKm: number;
  headingDeg: number;
  eta?: string;
  lastPositionUpdate?: string;
  positionExplanation: string;
};
