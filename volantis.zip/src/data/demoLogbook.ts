import type { Flight } from "@/types/volantis";
import { createDemoFlights } from "@/data/demoFlights";

export interface LogbookEntry {
  id: string;
  flightNumber: string;
  airlineIata: string;
  airlineName: string;
  aircraftType: string;
  aircraftRegistration: string;
  originIata: string;
  originCity: string;
  destinationIata: string;
  destinationCity: string;
  departureDate: string;
  distanceKm: number;
  durationMinutes: number;
  seat?: string;
  cabin?: string;
}

export interface LogbookStatistics {
  totalFlights: number;
  totalDistanceKm: number;
  totalFlightTimeMinutes: number;
  airlinesFlown: Array<{ iata: string; name: string; count: number; distanceKm: number }>;
  aircraftFlown: Array<{ type: string; count: number; distanceKm: number }>;
  airportsVisited: Array<{ iata: string; city: string; count: number }>;
  countriesVisited: Array<{ name: string; count: number }>;
  routes: Array<{ origin: string; destination: string; count: number }>;
  mostFlownAirline: { iata: string; name: string; count: number };
  mostVisitedAirport: { iata: string; city: string; count: number };
  mostFlownAircraft: { type: string; count: number };
  longestFlight: LogbookEntry;
  shortestFlight: LogbookEntry;
  mostFrequentRoute: { origin: string; destination: string; count: number };
}

export function createDemoLogbook(): LogbookEntry[] {
  return [
    { id: "lb-1", flightNumber: "BA112", airlineIata: "BA", airlineName: "British Airways", aircraftType: "Boeing 777-300ER", aircraftRegistration: "G-STBF", originIata: "JFK", originCity: "New York", destinationIata: "LHR", destinationCity: "London", departureDate: "2025-11-14", distanceKm: 5539, durationMinutes: 425, seat: "14A", cabin: "Business" },
    { id: "lb-2", flightNumber: "BA117", airlineIata: "BA", airlineName: "British Airways", aircraftType: "Boeing 787-9 Dreamliner", aircraftRegistration: "G-ZBKF", originIata: "LHR", originCity: "London", destinationIata: "JFK", destinationCity: "New York", departureDate: "2025-09-22", distanceKm: 5539, durationMinutes: 480, seat: "22K", cabin: "Economy Plus" },
    { id: "lb-3", flightNumber: "UA875", airlineIata: "UA", airlineName: "United Airlines", aircraftType: "Boeing 787-9 Dreamliner", aircraftRegistration: "N24979", originIata: "SFO", originCity: "San Francisco", destinationIata: "HND", destinationCity: "Tokyo", departureDate: "2025-09-02", distanceKm: 8843, durationMinutes: 660, seat: "3A", cabin: "First" },
    { id: "lb-4", flightNumber: "NH876", airlineIata: "NH", airlineName: "All Nippon Airways", aircraftType: "Boeing 777-300ER", aircraftRegistration: "JA795A", originIata: "HND", originCity: "Tokyo", destinationIata: "SFO", destinationCity: "San Francisco", departureDate: "2025-09-09", distanceKm: 8843, durationMinutes: 570, cabin: "Business" },
    { id: "lb-5", flightNumber: "AF11", airlineIata: "AF", airlineName: "Air France", aircraftType: "Airbus A350-900", aircraftRegistration: "F-HTYH", originIata: "JFK", originCity: "New York", destinationIata: "CDG", destinationCity: "Paris", departureDate: "2025-06-20", distanceKm: 5837, durationMinutes: 435, seat: "8C", cabin: "Business" },
    { id: "lb-6", flightNumber: "AF12", airlineIata: "AF", airlineName: "Air France", aircraftType: "Airbus A320neo", aircraftRegistration: "F-HZNA", originIata: "CDG", originCity: "Paris", destinationIata: "FRA", destinationCity: "Frankfurt", departureDate: "2025-06-22", distanceKm: 450, durationMinutes: 80, seat: "18F", cabin: "Economy" },
    { id: "lb-7", flightNumber: "LH401", airlineIata: "LH", airlineName: "Lufthansa", aircraftType: "Airbus A340-600", aircraftRegistration: "D-AIHZ", originIata: "FRA", originCity: "Frankfurt", destinationIata: "JFK", destinationCity: "New York", departureDate: "2025-06-24", distanceKm: 6193, durationMinutes: 525, seat: "4A", cabin: "First" },
    { id: "lb-8", flightNumber: "EK201", airlineIata: "EK", airlineName: "Emirates", aircraftType: "Airbus A380-800", aircraftRegistration: "A6-EOA", originIata: "DXB", originCity: "Dubai", destinationIata: "LHR", destinationCity: "London", departureDate: "2024-12-18", distanceKm: 5498, durationMinutes: 420, seat: "12A", cabin: "Business" },
    { id: "lb-9", flightNumber: "QR1", airlineIata: "QR", airlineName: "Qatar Airways", aircraftType: "Airbus A350-1000", aircraftRegistration: "A7-ANB", originIata: "DOH", originCity: "Doha", destinationIata: "LHR", destinationCity: "London", departureDate: "2024-11-05", distanceKm: 5263, durationMinutes: 395, cabin: "Business" },
    { id: "lb-10", flightNumber: "BA178", airlineIata: "BA", airlineName: "British Airways", aircraftType: "Airbus A380-800", aircraftRegistration: "G-XLEK", originIata: "LHR", originCity: "London", destinationIata: "JFK", destinationCity: "New York", departureDate: "2024-10-12", distanceKm: 5539, durationMinutes: 470, seat: "50E", cabin: "Economy" },
    { id: "lb-11", flightNumber: "DL1", airlineIata: "DL", airlineName: "Delta Air Lines", aircraftType: "Airbus A330-900neo", aircraftRegistration: "N402DX", originIata: "JFK", originCity: "New York", destinationIata: "LHR", destinationCity: "London", departureDate: "2024-08-03", distanceKm: 5539, durationMinutes: 440, seat: "1A", cabin: "Delta One" },
    { id: "lb-12", flightNumber: "UA931", airlineIata: "UA", airlineName: "United Airlines", aircraftType: "Boeing 767-300ER", aircraftRegistration: "N641UA", originIata: "LHR", originCity: "London", destinationIata: "SFO", destinationCity: "San Francisco", departureDate: "2024-07-15", distanceKm: 8620, durationMinutes: 645, cabin: "Business" },
  ];
}

export function computeLogbookStatistics(entries: LogbookEntry[]): LogbookStatistics {
  const totalFlights = entries.length;
  const totalDistanceKm = entries.reduce((sum, e) => sum + e.distanceKm, 0);
  const totalFlightTimeMinutes = entries.reduce((sum, e) => sum + e.durationMinutes, 0);

  const airlineMap = new Map<string, { iata: string; name: string; count: number; distanceKm: number }>();
  for (const e of entries) {
    const existing = airlineMap.get(e.airlineIata) ?? { iata: e.airlineIata, name: e.airlineName, count: 0, distanceKm: 0 };
    existing.count++;
    existing.distanceKm += e.distanceKm;
    airlineMap.set(e.airlineIata, existing);
  }
  const airlinesFlown = Array.from(airlineMap.values()).sort((a, b) => b.count - a.count);

  const aircraftMap = new Map<string, { type: string; count: number; distanceKm: number }>();
  for (const e of entries) {
    const existing = aircraftMap.get(e.aircraftType) ?? { type: e.aircraftType, count: 0, distanceKm: 0 };
    existing.count++;
    existing.distanceKm += e.distanceKm;
    aircraftMap.set(e.aircraftType, existing);
  }
  const aircraftFlown = Array.from(aircraftMap.values()).sort((a, b) => b.count - a.count);

  const airportMap = new Map<string, { iata: string; city: string; count: number }>();
  for (const e of entries) {
    for (const [iata, city] of [[e.originIata, e.originCity], [e.destinationIata, e.destinationCity]] as const) {
      const existing = airportMap.get(iata) ?? { iata, city, count: 0 };
      existing.count++;
      airportMap.set(iata, existing);
    }
  }
  const airportsVisited = Array.from(airportMap.values()).sort((a, b) => b.count - a.count);

  const routeMap = new Map<string, { origin: string; destination: string; count: number }>();
  for (const e of entries) {
    const key = `${e.originIata}-${e.destinationIata}`;
    const existing = routeMap.get(key) ?? { origin: e.originIata, destination: e.destinationIata, count: 0 };
    existing.count++;
    routeMap.set(key, existing);
  }
  const routes = Array.from(routeMap.values()).sort((a, b) => b.count - a.count);

  const mostFlownAirline = airlinesFlown[0] ?? { iata: "--", name: "None", count: 0 };
  const mostVisitedAirport = airportsVisited[0] ?? { iata: "---", city: "None", count: 0 };
  const mostFlownAircraft = aircraftFlown[0] ?? { type: "None", count: 0 };
  const longestFlight = entries.reduce((max, e) => e.distanceKm > max.distanceKm ? e : max, entries[0]);
  const shortestFlight = entries.reduce((min, e) => e.distanceKm < min.distanceKm ? e : min, entries[0]);
  const mostFrequentRoute = routes[0] ?? { origin: "---", destination: "---", count: 0 };

  return {
    totalFlights,
    totalDistanceKm,
    totalFlightTimeMinutes,
    airlinesFlown,
    aircraftFlown,
    airportsVisited,
    countriesVisited: [
      { name: "United States", count: 5 },
      { name: "United Kingdom", count: 6 },
      { name: "France", count: 2 },
      { name: "Germany", count: 2 },
      { name: "Japan", count: 2 },
      { name: "United Arab Emirates", count: 1 },
      { name: "Qatar", count: 1 },
    ],
    routes,
    mostFlownAirline,
    mostVisitedAirport,
    mostFlownAircraft,
    longestFlight,
    shortestFlight,
    mostFrequentRoute,
  };
}
