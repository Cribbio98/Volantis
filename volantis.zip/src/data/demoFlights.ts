import { findAircraftSpecs } from "@/data/aircraft";
import { resolveAirline } from "@/data/airlines";
import { findAirport } from "@/data/airports";
import { bearingDegrees, calculateTemporalProgress, greatCircleInterpolate, haversineDistanceKm } from "@/lib/geo";
import type { Flight, FlightStatus, FlightTimelineEvent } from "@/types/volantis";

function isoOffset(minutesFromNow: number, now: Date) {
  return new Date(now.getTime() + minutesFromNow * 60_000).toISOString();
}

function timeline(status: FlightStatus, scheduledDeparture: string, scheduledArrival: string): FlightTimelineEvent[] {
  return [
    { label: "Scheduled", at: scheduledDeparture, state: "complete", detail: "Flight plan created" },
    { label: "Check-in", at: isoRelative(scheduledDeparture, -180), state: status === "CheckIn" ? "active" : "complete" },
    { label: "Boarding", at: isoRelative(scheduledDeparture, -45), state: status === "Boarding" ? "active" : status === "Expected" ? "upcoming" : "complete" },
    { label: "Pushback", at: scheduledDeparture, state: ["EnRoute", "Departed", "Approaching", "Arrived"].includes(status) ? "complete" : "upcoming" },
    { label: "Cruise", at: isoRelative(scheduledDeparture, 55), state: status === "EnRoute" ? "active" : status === "Arrived" ? "complete" : "upcoming" },
    { label: "Arrival", at: scheduledArrival, state: status === "Arrived" ? "complete" : "upcoming" },
  ];
}

function isoRelative(iso: string, minutes: number) {
  return new Date(new Date(iso).getTime() + minutes * 60_000).toISOString();
}

function createFlight(input: {
  id: string;
  airlineIata: string;
  flightNumber: string;
  originIata: string;
  destinationIata: string;
  departOffsetMinutes: number;
  arrivalOffsetMinutes: number;
  status: FlightStatus;
  terminal?: string;
  gate?: string;
  aircraftType: string;
  registration?: string;
  now: Date;
}): Flight {
  const airline = resolveAirline({ iata: input.airlineIata });
  const origin = findAirport(input.originIata)!;
  const destination = findAirport(input.destinationIata)!;
  const scheduledDeparture = isoOffset(input.departOffsetMinutes, input.now);
  const scheduledArrival = isoOffset(input.arrivalOffsetMinutes, input.now);
  const distanceKm = haversineDistanceKm(origin, destination);
  const durationMinutes = Math.round((new Date(scheduledArrival).getTime() - new Date(scheduledDeparture).getTime()) / 60_000);
  const progress = calculateTemporalProgress(scheduledDeparture, scheduledArrival, input.now);
  const position = greatCircleInterpolate(origin, destination, progress);
  const heading = bearingDegrees(position, destination);
  const specs = findAircraftSpecs(input.aircraftType);
  const estimatedArrival = input.status === "Delayed" ? isoRelative(scheduledArrival, 35) : scheduledArrival;
  const actualDeparture = input.status === "EnRoute" || input.status === "Departed" || input.status === "Approaching" ? isoRelative(scheduledDeparture, 8) : undefined;

  return {
    id: input.id,
    airline,
    flightNumber: input.flightNumber,
    callSign: `${airline.icao}${input.flightNumber.replace(/\D/g, "")}`,
    status: input.status,
    origin,
    destination,
    scheduledDeparture,
    scheduledArrival,
    estimatedDeparture: input.status === "Delayed" ? isoRelative(scheduledDeparture, 35) : scheduledDeparture,
    estimatedArrival,
    actualDeparture,
    terminal: input.terminal,
    gate: input.gate,
    boarding: {
      startsAt: isoRelative(scheduledDeparture, -45),
      closesAt: isoRelative(scheduledDeparture, -12),
      group: "Group 2",
      notes: input.status === "Boarding" ? "Boarding active at gate" : "Boarding time will update when airport feed is available",
    },
    aircraft: {
      type: input.aircraftType,
      family: specs?.model.includes("787") ? "Boeing 787" : specs?.model.includes("777") ? "Boeing 777" : specs?.model.includes("A350") ? "Airbus A350" : "Airbus A320",
      manufacturer: specs?.manufacturer ?? "Unknown",
      registration: input.registration,
      specs,
    },
    telemetry:
      input.status === "EnRoute"
        ? {
            latitude: position.latitude,
            longitude: position.longitude,
            altitudeFt: 37000,
            groundSpeedKt: 472,
            headingDeg: heading,
            reportedAt: input.now.toISOString(),
            freshnessSeconds: 18,
            source: "DEMO_DATA",
          }
        : undefined,
    lastUpdatedUtc: input.now.toISOString(),
    dataSource: "DEMO_DATA",
    distanceKm,
    durationMinutes,
    progressPercent: Math.round(progress * 100),
    remainingDistanceKm: Math.max(0, distanceKm * (1 - progress)),
    eta: estimatedArrival,
    routeCoordinates: undefined,
    timeline: timeline(input.status, scheduledDeparture, estimatedArrival),
  };
}

export function createDemoFlights(now = new Date()): Flight[] {
  return [
    createFlight({
      id: "demo-ba112",
      airlineIata: "BA",
      flightNumber: "BA112",
      originIata: "JFK",
      destinationIata: "LHR",
      departOffsetMinutes: -92,
      arrivalOffsetMinutes: 286,
      status: "EnRoute",
      terminal: "8",
      gate: "14",
      aircraftType: "Boeing 777-300ER",
      registration: "G-STBF",
      now,
    }),
    createFlight({
      id: "demo-ua875",
      airlineIata: "UA",
      flightNumber: "UA875",
      originIata: "SFO",
      destinationIata: "HND",
      departOffsetMinutes: 318,
      arrivalOffsetMinutes: 1008,
      status: "Expected",
      terminal: "International",
      gate: "G92",
      aircraftType: "Boeing 787-9 Dreamliner",
      registration: "N24979",
      now,
    }),
    createFlight({
      id: "demo-af11",
      airlineIata: "AF",
      flightNumber: "AF11",
      originIata: "JFK",
      destinationIata: "CDG",
      departOffsetMinutes: 1260,
      arrivalOffsetMinutes: 1695,
      status: "Expected",
      terminal: "1",
      gate: "A6",
      aircraftType: "Airbus A350-900",
      registration: "F-HTYH",
      now,
    }),
  ].sort((a, b) => {
    const aActive = a.status === "EnRoute" ? -1 : 0;
    const bActive = b.status === "EnRoute" ? -1 : 0;
    if (aActive !== bActive) return aActive - bActive;
    return new Date(a.scheduledDeparture).getTime() - new Date(b.scheduledDeparture).getTime();
  });
}
