import type { Airport } from "@/types/volantis";

export const airportRegistry: Airport[] = [
  {
    iata: "JFK",
    icao: "KJFK",
    name: "John F. Kennedy International Airport",
    city: "New York",
    country: "United States",
    latitude: 40.6413,
    longitude: -73.7781,
    timezone: "America/New_York",
    terminals: ["1", "4", "5", "7", "8"],
    runways: [
      { name: "04L/22R", lengthMeters: 3682, surface: "Asphalt", headingDeg: 44 },
      { name: "13R/31L", lengthMeters: 4423, surface: "Concrete", headingDeg: 134 },
    ],
    airlines: ["BA", "DL", "AF", "LH", "QR", "EK"],
  },
  {
    iata: "LHR",
    icao: "EGLL",
    name: "London Heathrow Airport",
    city: "London",
    country: "United Kingdom",
    latitude: 51.47,
    longitude: -0.4543,
    timezone: "Europe/London",
    terminals: ["2", "3", "4", "5"],
    runways: [
      { name: "09L/27R", lengthMeters: 3902, surface: "Asphalt", headingDeg: 90 },
      { name: "09R/27L", lengthMeters: 3660, surface: "Asphalt", headingDeg: 90 },
    ],
    airlines: ["BA", "UA", "DL", "AF", "LH", "EK", "QR"],
  },
  {
    iata: "SFO",
    icao: "KSFO",
    name: "San Francisco International Airport",
    city: "San Francisco",
    country: "United States",
    latitude: 37.6213,
    longitude: -122.379,
    timezone: "America/Los_Angeles",
    terminals: ["1", "2", "3", "International"],
    runways: [
      { name: "28L/10R", lengthMeters: 3618, surface: "Asphalt", headingDeg: 284 },
      { name: "28R/10L", lengthMeters: 3231, surface: "Asphalt", headingDeg: 284 },
    ],
    airlines: ["UA", "DL", "BA", "NH"],
  },
  {
    iata: "HND",
    icao: "RJTT",
    name: "Tokyo Haneda Airport",
    city: "Tokyo",
    country: "Japan",
    latitude: 35.5494,
    longitude: 139.7798,
    timezone: "Asia/Tokyo",
    terminals: ["1", "2", "3"],
    runways: [
      { name: "16R/34L", lengthMeters: 3000, surface: "Asphalt", headingDeg: 160 },
      { name: "05/23", lengthMeters: 2500, surface: "Asphalt", headingDeg: 50 },
    ],
    airlines: ["NH", "UA", "BA"],
  },
  {
    iata: "CDG",
    icao: "LFPG",
    name: "Paris Charles de Gaulle Airport",
    city: "Paris",
    country: "France",
    latitude: 49.0097,
    longitude: 2.5479,
    timezone: "Europe/Paris",
    terminals: ["1", "2", "3"],
    runways: [
      { name: "08L/26R", lengthMeters: 4215, surface: "Asphalt", headingDeg: 80 },
      { name: "09R/27L", lengthMeters: 2700, surface: "Asphalt", headingDeg: 90 },
    ],
    airlines: ["AF", "DL", "BA", "LH", "EK", "QR"],
  },
  {
    iata: "FRA",
    icao: "EDDF",
    name: "Frankfurt Airport",
    city: "Frankfurt",
    country: "Germany",
    latitude: 50.0379,
    longitude: 8.5622,
    timezone: "Europe/Berlin",
    terminals: ["1", "2"],
    runways: [
      { name: "07C/25C", lengthMeters: 4000, surface: "Asphalt", headingDeg: 70 },
      { name: "18", lengthMeters: 4000, surface: "Concrete", headingDeg: 180 },
    ],
    airlines: ["LH", "UA", "BA", "AF"],
  },
  {
    iata: "DXB",
    icao: "OMDB",
    name: "Dubai International Airport",
    city: "Dubai",
    country: "United Arab Emirates",
    latitude: 25.2532,
    longitude: 55.3657,
    timezone: "Asia/Dubai",
    terminals: ["1", "2", "3"],
    runways: [
      { name: "12L/30R", lengthMeters: 4447, surface: "Asphalt", headingDeg: 120 },
      { name: "12R/30L", lengthMeters: 4000, surface: "Asphalt", headingDeg: 120 },
    ],
    airlines: ["EK", "QR", "BA", "LH", "AF"],
  },
  {
    iata: "DOH",
    icao: "OTHH",
    name: "Hamad International Airport",
    city: "Doha",
    country: "Qatar",
    latitude: 25.2731,
    longitude: 51.6081,
    timezone: "Asia/Qatar",
    terminals: ["Main"],
    runways: [
      { name: "16L/34R", lengthMeters: 4850, surface: "Asphalt", headingDeg: 160 },
      { name: "16R/34L", lengthMeters: 4250, surface: "Asphalt", headingDeg: 160 },
    ],
    airlines: ["QR", "BA", "AF", "LH"],
  },
];

export function findAirport(identifier?: string | null) {
  if (!identifier) {
    return undefined;
  }

  const normalized = identifier.trim().toUpperCase();
  return airportRegistry.find(
    (airport) => airport.iata.toUpperCase() === normalized || airport.icao.toUpperCase() === normalized,
  );
}

export function resolveAirport(input: Partial<Airport> & { iata?: string | null; icao?: string | null; name?: string | null }) {
  const registryAirport = findAirport(input.iata ?? input.icao);
  return {
    ...registryAirport,
    iata: input.iata?.trim().toUpperCase() || registryAirport?.iata || "---",
    icao: input.icao?.trim().toUpperCase() || registryAirport?.icao || "----",
    name: input.name?.trim() || registryAirport?.name || "Unknown Airport",
    city: input.city?.trim() || registryAirport?.city || "Unknown City",
    country: input.country?.trim() || registryAirport?.country || "Unknown Country",
    latitude: typeof input.latitude === "number" ? input.latitude : registryAirport?.latitude ?? 0,
    longitude: typeof input.longitude === "number" ? input.longitude : registryAirport?.longitude ?? 0,
    timezone: input.timezone || registryAirport?.timezone,
    terminals: input.terminals || registryAirport?.terminals,
    runways: input.runways || registryAirport?.runways,
    airlines: input.airlines || registryAirport?.airlines,
  } satisfies Airport;
}
