import type { Airline } from "@/types/volantis";

export const airlineRegistry: Airline[] = [
  {
    name: "British Airways",
    iata: "BA",
    icao: "BAW",
    logo: {
      kind: "brand-safe-mark",
      label: "BA",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#2E5C99", secondary: "#D71920", accent: "#FFFFFF" },
    alliance: "oneworld",
    country: "United Kingdom",
  },
  {
    name: "United Airlines",
    iata: "UA",
    icao: "UAL",
    logo: {
      kind: "brand-safe-mark",
      label: "UA",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#005DAA", secondary: "#002244", accent: "#FFFFFF" },
    alliance: "Star Alliance",
    country: "United States",
  },
  {
    name: "Delta Air Lines",
    iata: "DL",
    icao: "DAL",
    logo: {
      kind: "brand-safe-mark",
      label: "DL",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#C8102E", secondary: "#003A70", accent: "#FFFFFF" },
    alliance: "SkyTeam",
    country: "United States",
  },
  {
    name: "Air France",
    iata: "AF",
    icao: "AFR",
    logo: {
      kind: "brand-safe-mark",
      label: "AF",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#002157", secondary: "#ED2939", accent: "#FFFFFF" },
    alliance: "SkyTeam",
    country: "France",
  },
  {
    name: "Lufthansa",
    iata: "LH",
    icao: "DLH",
    logo: {
      kind: "brand-safe-mark",
      label: "LH",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#05164D", secondary: "#F9BA00", accent: "#FFFFFF" },
    alliance: "Star Alliance",
    country: "Germany",
  },
  {
    name: "All Nippon Airways",
    iata: "NH",
    icao: "ANA",
    logo: {
      kind: "brand-safe-mark",
      label: "NH",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#004EA2", secondary: "#00A0E9", accent: "#FFFFFF" },
    alliance: "Star Alliance",
    country: "Japan",
  },
  {
    name: "Emirates",
    iata: "EK",
    icao: "UAE",
    logo: {
      kind: "brand-safe-mark",
      label: "EK",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#D71920", secondary: "#007A3D", accent: "#FFFFFF" },
    alliance: "Independent",
    country: "United Arab Emirates",
  },
  {
    name: "Qatar Airways",
    iata: "QR",
    icao: "QTR",
    logo: {
      kind: "brand-safe-mark",
      label: "QR",
      licensingNote: "Brand-safe in-app mark. Replace with an official licensed asset when available.",
    },
    brandColors: { primary: "#5C0632", secondary: "#B08A57", accent: "#FFFFFF" },
    alliance: "oneworld",
    country: "Qatar",
  },
];

export function findAirline(identifier?: string | null) {
  if (!identifier) {
    return undefined;
  }

  const normalized = identifier.trim().toUpperCase();
  return airlineRegistry.find(
    (airline) =>
      airline.iata.toUpperCase() === normalized ||
      airline.icao.toUpperCase() === normalized ||
      airline.name.toUpperCase() === normalized,
  );
}

export function resolveAirline(input: { name?: string | null; iata?: string | null; icao?: string | null }) {
  return (
    findAirline(input.iata) ??
    findAirline(input.icao) ??
    findAirline(input.name) ?? {
      name: input.name?.trim() || "Unknown Airline",
      iata: input.iata?.trim().toUpperCase() || "--",
      icao: input.icao?.trim().toUpperCase() || "---",
      logo: {
        kind: "text-lockup",
        label: input.iata?.trim().toUpperCase() || "AIR",
        licensingNote: "Fallback text lockup until a licensed airline logo is available.",
      },
      brandColors: { primary: "#FACC15", secondary: "#0F172A", accent: "#FFFFFF" },
      alliance: "Independent" as const,
      country: "Unknown",
    }
  );
}
