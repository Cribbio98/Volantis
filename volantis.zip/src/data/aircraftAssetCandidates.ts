/**
 * AircraftAssetCandidateRegistry — research registry only.
 *
 * Policy: no asset is bundled unless (a) the license is verified from the source
 * repository itself, (b) the model visually resembles the specific aircraft family,
 * and (c) the format works in WebGL (GLB/GLTF). Candidates below are documented
 * findings from provider research. They are NOT bundled in the app.
 */

export type AssetCandidate = {
  targetFamily: string;
  provider: string;
  sourceUrl: string;
  license: string;
  licenseVerified: boolean;
  attributionRequired: boolean;
  commercialUse: boolean;
  formats: string[];
  suitability: "high" | "medium" | "low" | "rejected";
  rejectionReason?: string;
  notes: string;
};

export const aircraftAssetCandidates: AssetCandidate[] = [
  {
    targetFamily: "Multiple (B777, B747, A320, A380, …)",
    provider: "FlightGear aircraft hangar",
    sourceUrl: "https://www.flightgear.org/download/aircraft-v2-12/",
    license: "GPL-2.0 (per aircraft; varies)",
    licenseVerified: false,
    attributionRequired: true,
    commercialUse: true,
    formats: ["AC3D (.ac)", "XML"],
    suitability: "medium",
    notes:
      "Large selection of type-specific models (777, 747, A380, etc.) with correct silhouettes. GPL-2.0 permits commercial use but imposes source-availability obligations when redistributed. Models are in AC3D format and require offline conversion to GLB plus manual quality audit before use.",
  },
  {
    targetFamily: "Generic jets (not family-specific)",
    provider: "Poly Pizza (archived Google Poly)",
    sourceUrl: "https://poly.pizza/",
    license: "CC-BY-3.0 (per asset)",
    licenseVerified: false,
    attributionRequired: true,
    commercialUse: true,
    formats: ["GLTF", "OBJ"],
    suitability: "low",
    notes:
      "Free CC-BY low-poly airplanes in GLTF, but they are stylized generic jets that do not resemble specific families (e.g. never the double-deck A380 or winglet-span B787). Rejected as a default because Volantis requires recognizable family silhouettes.",
  },
  {
    targetFamily: "Multiple",
    provider: "Meshy gallery",
    sourceUrl: "https://www.meshy.ai/",
    license: "CC0 (pre-made gallery), CC-BY-4.0 (user-generated)",
    licenseVerified: false,
    attributionRequired: false,
    commercialUse: true,
    formats: ["GLB", "FBX", "OBJ", "STL"],
    suitability: "rejected",
    rejectionReason: "AI-generated geometry",
    notes:
      "Gallery assets are AI-generated, which violates Volantis policy against AI-substitute aircraft. Also requires platform account and ToS review for redistribution.",
  },
  {
    targetFamily: "Generic",
    provider: "FetchCFD",
    sourceUrl: "https://fetchcfd.com/",
    license: "\"Educational use only\" (site statement)",
    licenseVerified: false,
    attributionRequired: true,
    commercialUse: false,
    formats: ["GLB", "GLTF"],
    suitability: "rejected",
    rejectionReason: "License forbids commercial use",
    notes: "Remixed content marked educational-only. Not compatible with Volantis commercial/consumer use.",
  },
];

export function getBundledAssetReport() {
  return {
    bundledAssetCount: 0,
    candidateCount: aircraftAssetCandidates.length,
    policy:
      "No aircraft model is bundled: no candidate has passed all three gates (verified license file, family-accurate silhouette, WebGL-ready GLB). The AircraftAssetRepository remains intentionally empty; the CSS silhouette renderer is clearly labeled as fallback, never as a real model.",
  };
}
