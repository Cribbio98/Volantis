import { createDemoFlights } from "@/data/demoFlights";
import type { TravelPassport, Trip } from "@/types/volantis";

export function createDemoPassport(): TravelPassport {
  const flights = createDemoFlights();
  const airports = Array.from(new Map(flights.flatMap((flight) => [flight.origin, flight.destination]).map((airport) => [airport.iata, airport])).values());
  const countries = Array.from(new Set(airports.map((airport) => airport.country)));

  return {
    countriesVisited: countries,
    airportsVisited: airports,
    flightCount: 42,
    totalDistanceKm: 286_420,
    totalFlightTimeMinutes: 34_860,
    routes: [
      { origin: "JFK", destination: "LHR", count: 8 },
      { origin: "SFO", destination: "HND", count: 3 },
      { origin: "CDG", destination: "FRA", count: 5 },
    ],
    stamps: [
      { country: "United Kingdom", airport: "LHR", date: "2025-11-14" },
      { country: "Japan", airport: "HND", date: "2025-09-02" },
      { country: "France", airport: "CDG", date: "2025-06-20" },
      { country: "United Arab Emirates", airport: "DXB", date: "2024-12-18" },
    ],
  };
}

export function createDemoTrips(): Trip[] {
  const flights = createDemoFlights();
  const first = flights[0];
  const second = flights[1];

  return [
    {
      id: "trip-atlantic-briefing",
      name: "London Strategy Week",
      origin: first.origin,
      destination: first.destination,
      startsAt: first.scheduledDeparture,
      endsAt: first.scheduledArrival,
      flights: [first],
      totalDistanceKm: first.distanceKm,
      totalDurationMinutes: first.durationMinutes,
    },
    {
      id: "trip-pacific-connection",
      name: "Tokyo Product Review",
      origin: second.origin,
      destination: second.destination,
      startsAt: second.scheduledDeparture,
      endsAt: second.scheduledArrival,
      flights: [second],
      totalDistanceKm: second.distanceKm,
      totalDurationMinutes: second.durationMinutes,
    },
  ];
}
