import type { AircraftFamily, AircraftSpecs } from "@/types/volantis";

export interface DetailedAircraftSpecs extends AircraftSpecs {
  icaoCode: string;
  iataCode: string;
  family: AircraftFamily;
  lengthM: number;
  wingspanM: number;
  heightM: number;
  maxSpeedKt: number;
  firstFlightYear: number;
  engineCount: number;
  engineType: string;
}

export const aircraftFleetDirectory: AircraftSpecs[] = [
  { manufacturer: "Airbus", model: "Airbus A220-100", typicalCruiseKt: 447, rangeKm: 5460, ceilingFt: 41000, typicalSeats: "100–125", engines: "2 × PW1521G" },
  { manufacturer: "Airbus", model: "Airbus A220-300", typicalCruiseKt: 447, rangeKm: 6297, ceilingFt: 41000, typicalSeats: "120–160", engines: "2 × Pratt & Whitney PW1500G" },
  { manufacturer: "Airbus", model: "Airbus A319neo", typicalCruiseKt: 450, rangeKm: 6850, ceilingFt: 39000, typicalSeats: "120–160", engines: "2 × CFM LEAP-1A" },
  { manufacturer: "Airbus", model: "Airbus A320neo", typicalCruiseKt: 450, rangeKm: 6300, ceilingFt: 39000, typicalSeats: "150–194", engines: "2 × CFM LEAP-1A or PW1100G" },
  { manufacturer: "Airbus", model: "Airbus A321neo", typicalCruiseKt: 450, rangeKm: 7400, ceilingFt: 39000, typicalSeats: "180–244", engines: "2 × CFM LEAP-1A or PW1100G" },
  { manufacturer: "Airbus", model: "Airbus A330-300", typicalCruiseKt: 470, rangeKm: 11750, ceilingFt: 41450, typicalSeats: "250–440", engines: "2 × Trent 700 or PW4168" },
  { manufacturer: "Airbus", model: "Airbus A330-900neo", typicalCruiseKt: 470, rangeKm: 13350, ceilingFt: 41450, typicalSeats: "260–440", engines: "2 × Trent 7000" },
  { manufacturer: "Airbus", model: "Airbus A340-600", typicalCruiseKt: 475, rangeKm: 14600, ceilingFt: 41450, typicalSeats: "300–440", engines: "4 × Trent 500" },
  { manufacturer: "Airbus", model: "Airbus A350-900", typicalCruiseKt: 488, rangeKm: 15000, ceilingFt: 43100, typicalSeats: "300–350", engines: "2 × Rolls-Royce Trent XWB" },
  { manufacturer: "Airbus", model: "Airbus A350-1000", typicalCruiseKt: 488, rangeKm: 16100, ceilingFt: 43100, typicalSeats: "350–410", engines: "2 × Trent XWB-97" },
  { manufacturer: "Airbus", model: "Airbus A380-800", typicalCruiseKt: 488, rangeKm: 14800, ceilingFt: 43100, typicalSeats: "500–853", engines: "4 × Trent 900 or GP7200" },
  { manufacturer: "Boeing", model: "Boeing 737-800", typicalCruiseKt: 453, rangeKm: 5760, ceilingFt: 41000, typicalSeats: "162–189", engines: "2 × CFM56-7B" },
  { manufacturer: "Boeing", model: "Boeing 737 MAX 8", typicalCruiseKt: 453, rangeKm: 6570, ceilingFt: 41000, typicalSeats: "162–210", engines: "2 × CFM LEAP-1B" },
  { manufacturer: "Boeing", model: "Boeing 737 MAX 9", typicalCruiseKt: 453, rangeKm: 6570, ceilingFt: 41000, typicalSeats: "178–220", engines: "2 × CFM LEAP-1B" },
  { manufacturer: "Boeing", model: "Boeing 747-8I", typicalCruiseKt: 492, rangeKm: 14815, ceilingFt: 43000, typicalSeats: "410–467", engines: "4 × GEnx-2B" },
  { manufacturer: "Boeing", model: "Boeing 757-200", typicalCruiseKt: 460, rangeKm: 7222, ceilingFt: 42000, typicalSeats: "200–239", engines: "2 × RB211-535 or PW2037" },
  { manufacturer: "Boeing", model: "Boeing 767-300ER", typicalCruiseKt: 460, rangeKm: 11307, ceilingFt: 43100, typicalSeats: "218–350", engines: "2 × CF6-80C2 or PW4062" },
  { manufacturer: "Boeing", model: "Boeing 777-300ER", typicalCruiseKt: 488, rangeKm: 13650, ceilingFt: 43100, typicalSeats: "365–550", engines: "2 × GE90-115B" },
  { manufacturer: "Boeing", model: "Boeing 777-9", typicalCruiseKt: 490, rangeKm: 15000, ceilingFt: 43100, typicalSeats: "400–426", engines: "2 × GE9X" },
  { manufacturer: "Boeing", model: "Boeing 787-8 Dreamliner", typicalCruiseKt: 488, rangeKm: 13621, ceilingFt: 43000, typicalSeats: "242–335", engines: "2 × GEnx-1B or Trent 1000" },
  { manufacturer: "Boeing", model: "Boeing 787-9 Dreamliner", typicalCruiseKt: 488, rangeKm: 14140, ceilingFt: 43000, typicalSeats: "250–290", engines: "2 × GEnx or Trent 1000" },
  { manufacturer: "Boeing", model: "Boeing 787-10 Dreamliner", typicalCruiseKt: 488, rangeKm: 11910, ceilingFt: 43000, typicalSeats: "318–336", engines: "2 × GEnx-1B or Trent 1000TEN" },
  { manufacturer: "Embraer", model: "Embraer E170", typicalCruiseKt: 447, rangeKm: 3889, ceilingFt: 41000, typicalSeats: "70–78", engines: "2 × GE CF34-8E" },
  { manufacturer: "Embraer", model: "Embraer E175", typicalCruiseKt: 447, rangeKm: 4027, ceilingFt: 41000, typicalSeats: "78–88", engines: "2 × GE CF34-8E" },
  { manufacturer: "Embraer", model: "Embraer E190", typicalCruiseKt: 447, rangeKm: 4537, ceilingFt: 41000, typicalSeats: "96–106", engines: "2 × GE CF34-10E" },
  { manufacturer: "Embraer", model: "Embraer E195", typicalCruiseKt: 447, rangeKm: 4815, ceilingFt: 41000, typicalSeats: "116–122", engines: "2 × GE CF34-10E" },
  { manufacturer: "Embraer", model: "Embraer E195-E2", typicalCruiseKt: 447, rangeKm: 4815, ceilingFt: 41000, typicalSeats: "120–146", engines: "2 × Pratt & Whitney PW1900G" },
  { manufacturer: "ATR", model: "ATR 42-600", typicalCruiseKt: 275, rangeKm: 1528, ceilingFt: 25000, typicalSeats: "40–50", engines: "2 × PW127XT" },
  { manufacturer: "ATR", model: "ATR 72-600", typicalCruiseKt: 275, rangeKm: 1528, ceilingFt: 25000, typicalSeats: "68–78", engines: "2 × Pratt & Whitney Canada PW127XT" },
];

export const detailedAircraftSpecs: DetailedAircraftSpecs[] = [
  { manufacturer: "Airbus", model: "Airbus A220-300", icaoCode: "BCS3", iataCode: "223", family: "Airbus A220", typicalCruiseKt: 447, rangeKm: 6297, ceilingFt: 41000, typicalSeats: "120–160", engines: "2 × PW1500G", lengthM: 38.7, wingspanM: 35.1, heightM: 11.5, maxSpeedKt: 470, firstFlightYear: 2013, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Airbus", model: "Airbus A320neo", icaoCode: "A320", iataCode: "320", family: "Airbus A320", typicalCruiseKt: 450, rangeKm: 6300, ceilingFt: 39000, typicalSeats: "150–194", engines: "2 × CFM LEAP-1A or PW1100G", lengthM: 37.6, wingspanM: 35.8, heightM: 11.8, maxSpeedKt: 490, firstFlightYear: 2014, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Airbus", model: "Airbus A321neo", icaoCode: "A321", iataCode: "321", family: "Airbus A321", typicalCruiseKt: 450, rangeKm: 7400, ceilingFt: 39000, typicalSeats: "180–244", engines: "2 × CFM LEAP-1A or PW1100G", lengthM: 44.5, wingspanM: 35.8, heightM: 11.8, maxSpeedKt: 490, firstFlightYear: 2016, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Airbus", model: "Airbus A330-900neo", icaoCode: "A339", iataCode: "339", family: "Airbus A330", typicalCruiseKt: 470, rangeKm: 13350, ceilingFt: 41450, typicalSeats: "260–440", engines: "2 × Trent 7000", lengthM: 63.7, wingspanM: 64.0, heightM: 16.8, maxSpeedKt: 511, firstFlightYear: 2017, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Airbus", model: "Airbus A350-900", icaoCode: "A359", iataCode: "359", family: "Airbus A350", typicalCruiseKt: 488, rangeKm: 15000, ceilingFt: 43100, typicalSeats: "300–350", engines: "2 × Rolls-Royce Trent XWB", lengthM: 66.8, wingspanM: 64.8, heightM: 17.1, maxSpeedKt: 510, firstFlightYear: 2013, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Airbus", model: "Airbus A380-800", icaoCode: "A388", iataCode: "380", family: "Airbus A380", typicalCruiseKt: 488, rangeKm: 14800, ceilingFt: 43100, typicalSeats: "500–853", engines: "4 × Trent 900 or GP7200", lengthM: 72.7, wingspanM: 79.8, heightM: 24.1, maxSpeedKt: 510, firstFlightYear: 2005, engineCount: 4, engineType: "Turbofan" },
  { manufacturer: "Boeing", model: "Boeing 737 MAX 8", icaoCode: "B38M", iataCode: "738", family: "Boeing 737", typicalCruiseKt: 453, rangeKm: 6570, ceilingFt: 41000, typicalSeats: "162–210", engines: "2 × CFM LEAP-1B", lengthM: 39.5, wingspanM: 35.9, heightM: 12.3, maxSpeedKt: 490, firstFlightYear: 2016, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Boeing", model: "Boeing 747-8I", icaoCode: "B748", iataCode: "747", family: "Boeing 747", typicalCruiseKt: 492, rangeKm: 14815, ceilingFt: 43000, typicalSeats: "410–467", engines: "4 × GEnx-2B", lengthM: 76.3, wingspanM: 68.4, heightM: 19.4, maxSpeedKt: 516, firstFlightYear: 2010, engineCount: 4, engineType: "Turbofan" },
  { manufacturer: "Boeing", model: "Boeing 777-300ER", icaoCode: "B77W", iataCode: "777", family: "Boeing 777", typicalCruiseKt: 488, rangeKm: 13650, ceilingFt: 43100, typicalSeats: "365–550", engines: "2 × GE90-115B", lengthM: 73.9, wingspanM: 64.8, heightM: 18.5, maxSpeedKt: 512, firstFlightYear: 2003, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Boeing", model: "Boeing 787-9 Dreamliner", icaoCode: "B789", iataCode: "789", family: "Boeing 787", typicalCruiseKt: 488, rangeKm: 14140, ceilingFt: 43000, typicalSeats: "250–290", engines: "2 × GEnx or Trent 1000", lengthM: 56.7, wingspanM: 60.1, heightM: 16.9, maxSpeedKt: 510, firstFlightYear: 2013, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "Embraer", model: "Embraer E195-E2", icaoCode: "E295", iataCode: "195", family: "Embraer E-Jets", typicalCruiseKt: 447, rangeKm: 4815, ceilingFt: 41000, typicalSeats: "120–146", engines: "2 × Pratt & Whitney PW1900G", lengthM: 41.5, wingspanM: 35.6, heightM: 10.7, maxSpeedKt: 470, firstFlightYear: 2017, engineCount: 2, engineType: "Turbofan" },
  { manufacturer: "ATR", model: "ATR 72-600", icaoCode: "AT76", iataCode: "AT7", family: "ATR", typicalCruiseKt: 275, rangeKm: 1528, ceilingFt: 25000, typicalSeats: "68–78", engines: "2 × PW127XT", lengthM: 27.2, wingspanM: 27.0, heightM: 8.0, maxSpeedKt: 310, firstFlightYear: 1988, engineCount: 2, engineType: "Turboprop" },
];

export function aircraftFamilyFromType(type?: string | null): AircraftFamily {
  const normalized = (type ?? "").toUpperCase();
  if (normalized.includes("A220") || normalized.includes("BCS")) return "Airbus A220";
  if (normalized.includes("A319") || normalized.includes("A320")) return "Airbus A320";
  if (normalized.includes("A321")) return "Airbus A321";
  if (normalized.includes("A330") || normalized.includes("A340")) return "Airbus A330";
  if (normalized.includes("A350")) return "Airbus A350";
  if (normalized.includes("A380")) return "Airbus A380";
  if (normalized.includes("737") || normalized.includes("B38") || normalized.includes("B73")) return "Boeing 737";
  if (normalized.includes("747") || normalized.includes("B74")) return "Boeing 747";
  if (normalized.includes("757")) return "Boeing 777";
  if (normalized.includes("767")) return "Boeing 777";
  if (normalized.includes("777") || normalized.includes("B77")) return "Boeing 777";
  if (normalized.includes("787") || normalized.includes("B78")) return "Boeing 787";
  if (normalized.includes("E17") || normalized.includes("E19") || normalized.includes("E29") || normalized.includes("EMB")) return "Embraer E-Jets";
  if (normalized.includes("AT7") || normalized.includes("AT4") || normalized.includes("ATR")) return "ATR";
  return "Unknown";
}

export function findAircraftSpecs(type?: string | null) {
  const normalized = (type ?? "").toUpperCase();
  return detailedAircraftSpecs.find((s) => s.icaoCode === normalized || s.model.toUpperCase().includes(normalized) || normalized.includes(s.icaoCode)) ?? detailedAircraftSpecs.find((s) => s.family === aircraftFamilyFromType(type)) ?? aircraftFleetDirectory[0];
}

export function getAircraftByFamily(family: AircraftFamily) {
  return detailedAircraftSpecs.filter((s) => s.family === family);
}
