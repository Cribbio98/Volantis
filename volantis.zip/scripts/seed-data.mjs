/**
 * Volantis offline data seeding.
 * Sources (all free, no API keys):
 *  - OurAirports airports.csv + runways.csv (CC0-1.0)
 *  - OpenFlights airlines.dat (ODbL-1.0)
 *  - Wikimedia Commons media (per-asset licenses verified against allowlist)
 */
import pg from "pg";
import { readFileSync } from "node:fs";

const env = readFileSync(".env", "utf8");
const dbUrl = env.split("\n").find((l) => l.startsWith("DATABASE_URL="))?.split("=").slice(1).join("=").trim().replace(/^"|"$/g, "");
if (!dbUrl) throw new Error("DATABASE_URL missing");

const client = new pg.Client({ connectionString: dbUrl });
await client.connect();

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return [];
  const parseLine = (line) => {
    const out = [];
    let cur = "", q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) {
        if (c === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else if (c === '"') q = true;
      else if (c === ",") { out.push(cur); cur = ""; }
      else cur += c;
    }
    out.push(cur);
    return out;
  };
  const headers = parseLine(lines[0]).map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const vals = parseLine(line);
    const rec = {};
    headers.forEach((h, i) => (rec[h] = (vals[i] ?? "").trim()));
    return rec;
  });
}

const DATA_SOURCE_INFO = (provider, sourceUrl, license) => JSON.stringify({
  source: provider.toLowerCase().replace(/\s+/g, "-"),
  provider,
  sourceUrl,
  license,
  attribution: `Data from ${provider} (${license})`,
  commercialUse: true,
  sourceUpdatedAt: new Date().toISOString(),
  dataConfidence: "likely",
  cachedAt: new Date().toISOString(),
  retrievedAt: new Date().toISOString(),
});

async function ensureTables() {
  await client.query(`CREATE TABLE IF NOT EXISTS volantis_airport_data (
    iata VARCHAR(3) PRIMARY KEY, icao VARCHAR(8) NOT NULL, name VARCHAR(180) NOT NULL,
    city VARCHAR(120) NOT NULL DEFAULT '', municipality VARCHAR(120), country VARCHAR(96) NOT NULL DEFAULT '',
    country_iso VARCHAR(2), latitude DOUBLE PRECISION NOT NULL, longitude DOUBLE PRECISION NOT NULL,
    elevation_ft INTEGER, timezone VARCHAR(80), airport_type VARCHAR(24), scheduled_service BOOLEAN DEFAULT FALSE,
    home_link TEXT, wikipedia_link TEXT, data_source_info JSONB, runways JSONB DEFAULT '[]',
    runway_count INTEGER DEFAULT 0, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await client.query(`ALTER TABLE volantis_airport_data ALTER COLUMN icao TYPE VARCHAR(8)`).catch(() => {});
  await client.query(`CREATE TABLE IF NOT EXISTS volantis_airline_data (
    iata VARCHAR(3) PRIMARY KEY, icao VARCHAR(6), name VARCHAR(160) NOT NULL, callsign VARCHAR(64),
    country VARCHAR(96), country_iso VARCHAR(2), alliance VARCHAR(40) DEFAULT 'Independent',
    active BOOLEAN DEFAULT TRUE, airline_type VARCHAR(24) DEFAULT 'unknown', logo_url TEXT, logo_license TEXT,
    brand_colors JSONB, website TEXT, wikipedia_link TEXT, data_source_info JSONB,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await client.query(`CREATE TABLE IF NOT EXISTS volantis_media_assets (
    id SERIAL PRIMARY KEY, media_type VARCHAR(32) NOT NULL, subject_code VARCHAR(64) NOT NULL,
    subject_name VARCHAR(180), url TEXT, thumbnail_url TEXT, source_page_url TEXT, author TEXT,
    license VARCHAR(96), attribution TEXT, commercial_use BOOLEAN DEFAULT FALSE, found BOOLEAN DEFAULT FALSE,
    retrieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), UNIQUE(media_type, subject_code))`);
}

async function seedAirports() {
  console.log("Fetching OurAirports airports.csv …");
  const csv = await (await fetch("https://davidmegginson.github.io/ourairports-data/airports.csv")).text();
  const records = parseCsv(csv);
  const dsi = DATA_SOURCE_INFO("OurAirports", "https://davidmegginson.github.io/ourairports-data/", "CC0-1.0");
  let count = 0;
  for (const r of records) {
    const iata = r.iata_code?.trim();
    const icao = r.ident?.trim();
    if (!iata || iata.length !== 3 || !icao || !r.name?.trim() || !r.latitude_deg || !r.longitude_deg) continue;
    await client.query(
      `INSERT INTO volantis_airport_data (iata,icao,name,city,municipality,country,country_iso,latitude,longitude,elevation_ft,airport_type,scheduled_service,home_link,wikipedia_link,data_source_info)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb)
       ON CONFLICT (iata) DO UPDATE SET icao=EXCLUDED.icao,name=EXCLUDED.name,city=EXCLUDED.city,municipality=EXCLUDED.municipality,country=EXCLUDED.country,country_iso=EXCLUDED.country_iso,latitude=EXCLUDED.latitude,longitude=EXCLUDED.longitude,elevation_ft=EXCLUDED.elevation_ft,airport_type=EXCLUDED.airport_type,scheduled_service=EXCLUDED.scheduled_service,home_link=EXCLUDED.home_link,wikipedia_link=EXCLUDED.wikipedia_link,data_source_info=EXCLUDED.data_source_info,updated_at=NOW()`,
      [iata.toUpperCase(), icao.toUpperCase(), r.name, r.municipality ?? "", r.municipality || null, r.iso_country ?? "", r.iso_country?.toUpperCase() || null,
       Number(r.latitude_deg), Number(r.longitude_deg), r.elevation_ft ? parseInt(r.elevation_ft, 10) : null, r.type || null, r.scheduled_service === "1",
       r.home_link || null, r.wikipedia_link || null, dsi],
    );
    count++;
    if (count % 500 === 0) console.log(`  airports: ${count}`);
  }
  console.log(`Seeded ${count} airports.`);

  console.log("Fetching OurAirports runways.csv …");
  const runwayCsv = await (await fetch("https://davidmegginson.github.io/ourairports-data/runways.csv")).text();
  const runwayRecords = parseCsv(runwayCsv);
  const byAirport = new Map();
  for (const r of runwayRecords) {
    const key = r.airport_ident?.trim().toUpperCase();
    if (!key) continue;
    const list = byAirport.get(key) ?? [];
    const base = {
      lengthFt: r.length_ft ? parseInt(r.length_ft, 10) : undefined,
      lengthMeters: r.length_ft ? Math.round(parseInt(r.length_ft, 10) * 0.3048) : undefined,
      surface: r.surface || undefined,
      lighted: r.lighted === "1",
      closed: r.closed === "1",
    };
    if (r.le_ident?.trim()) list.push({ name: r.le_ident.trim(), headingDeg: r.le_heading_degT ? Number(r.le_heading_degT) : undefined, ...base });
    if (r.he_ident?.trim() && r.he_ident.trim() !== r.le_ident?.trim()) list.push({ name: r.he_ident.trim(), headingDeg: r.he_heading_degT ? Number(r.he_heading_degT) : undefined, ...base });
    byAirport.set(key, list);
  }
  let runwayUpdates = 0;
  for (const [icao, runways] of byAirport) {
    if (!runways.length) continue;
    await client.query(`UPDATE volantis_airport_data SET runways=$1::jsonb, runway_count=$2 WHERE icao=$3`, [JSON.stringify(runways), runways.length, icao]);
    runwayUpdates++;
  }
  console.log(`Assigned runway sets to ${runwayUpdates} airports.`);
}

async function seedAirlines() {
  console.log("Fetching OpenFlights airlines.dat …");
  const text = await (await fetch("https://raw.githubusercontent.com/jpatokal/openflights/master/data/airlines.dat")).text();
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  const dsi = DATA_SOURCE_INFO("OpenFlights", "https://github.com/jpatokal/openflights", "ODbL-1.0");
  let count = 0;
  for (const line of lines) {
    const rec = parseCsv(`id,name,alias,iata,icao,callsign,country,active\n${line}`)[0];
    if (!rec) continue;
    const clean = (v) => (v && v !== "\\N" ? v : null);
    const iata = clean(rec.iata)?.toUpperCase();
    if (!iata || iata.length !== 2 || !clean(rec.name)) continue;
    await client.query(
      `INSERT INTO volantis_airline_data (iata,icao,name,callsign,country,active,data_source_info)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)
       ON CONFLICT (iata) DO UPDATE SET icao=COALESCE(EXCLUDED.icao,volantis_airline_data.icao),name=EXCLUDED.name,callsign=COALESCE(EXCLUDED.callsign,volantis_airline_data.callsign),country=COALESCE(EXCLUDED.country,volantis_airline_data.country),active=EXCLUDED.active,data_source_info=EXCLUDED.data_source_info,updated_at=NOW()`,
      [iata, clean(rec.icao)?.toUpperCase() || null, clean(rec.name), clean(rec.callsign) || null, clean(rec.country) || null, rec.active === "Y", dsi],
    );
    count++;
  }
  console.log(`Seeded ${count} airlines.`);
}

const LICENSES_ALLOWED = ["CC0", "PUBLIC DOMAIN", "CC-BY", "CC BY", "PD", "CC BY-SA", "CC BY-SA 4.0", "CC BY 4.0"];

async function wikimediaSearch(query, limit = 3) {
  const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=${limit}&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=900&format=json&origin=*`;
  const res = await fetch(url, { headers: { "User-Agent": "Volantis/1.0 (aviation data seeding)" } });
  if (!res.ok) return null;
  const data = await res.json();
  const pages = Object.values(data.pages ?? {}).filter((p) => p.imageinfo?.length);
  if (!pages.length) return null;
  const info = pages[0].imageinfo[0];
  const license = info.extmetadata?.LicenseShortName?.value ?? "Unknown";
  const normalized = license.toUpperCase().replace(/[^A-Z0-9. ]/g, "");
  const allowed = LICENSES_ALLOWED.some((l) => normalized.includes(l));
  return {
    url: info.thumburl ?? info.url ?? "",
    thumbnail: info.thumburl ?? null,
    pageUrl: info.descriptionurl ?? null,
    author: info.extmetadata?.Artist?.value?.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim() || null,
    license,
    allowed,
  };
}

async function cacheMedia(mediaType, code, name, asset) {
  await client.query(
    `INSERT INTO volantis_media_assets (media_type,subject_code,subject_name,url,thumbnail_url,source_page_url,author,license,attribution,commercial_use,found,retrieved_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
     ON CONFLICT (media_type,subject_code) DO UPDATE SET url=EXCLUDED.url,thumbnail_url=EXCLUDED.thumbnail_url,source_page_url=EXCLUDED.source_page_url,author=EXCLUDED.author,license=EXCLUDED.license,attribution=EXCLUDED.attribution,commercial_use=EXCLUDED.commercial_use,found=EXCLUDED.found,retrieved_at=NOW()`,
    [mediaType, code.toUpperCase(), name, asset?.url ?? null, asset?.thumbnail ?? null, asset?.pageUrl ?? null, asset?.author ?? null, asset?.license ?? null, asset?.author ?? null, asset?.allowed ?? false, asset !== null && asset.allowed],
  );
}

const PRIORITY_AIRPORTS = ["JFK","LHR","CDG","FRA","HND","DXB","SFO","DOH","FCO","MAD","AMS","SIN","ICN","ORD","LAX","PEK","SYD","YYZ","ATL","GRU","JNB","IST","DEL","BKK","HKG","EWR","MUC","ZRH","VIE","CPH","ARN","HEL","DUB","LIS","ATH","PRG","WAW","BRU","GVA","KIX"];
const PRIORITY_AIRLINES = [["BA","British Airways"],["UA","United Airlines"],["DL","Delta Air Lines"],["AF","Air France"],["LH","Lufthansa"],["NH","All Nippon Airways"],["EK","Emirates"],["QR","Qatar Airways"],["IT","ITA Airways"],["LX","Swiss International Air Lines"],["KL","KLM"],["IB","Iberia"],["AZ","ITA Airways"],["TK","Turkish Airlines"],["SQ","Singapore Airlines"],["CX","Cathay Pacific"],["AC","Air Canada"],["Q","Qantas"],["VS","Virgin Atlantic"],["AA","American Airlines"]];
const PRIORITY_AIRCRAFT = [["Airbus","Airbus A320 family"],["Airbus","Airbus A350 XWB"],["Airbus","Airbus A380"],["Airbus","Airbus A330"],["Boeing","Boeing 737"],["Boeing","Boeing 787 Dreamliner"],["Boeing","Boeing 777"],["Boeing","Boeing 747"]];

async function seedMedia() {
  let foundPhotos = 0, foundLogos = 0, foundAircraft = 0;

  console.log("Resolving airport photos from Wikimedia Commons (major hubs first)…");
  for (const iata of PRIORITY_AIRPORTS) {
    const { rows } = await client.query(`SELECT iata,name FROM volantis_airport_data WHERE iata=$1`, [iata]);
    const airport = rows[0];
    if (!airport) continue;
    const asset = await wikimediaSearch(`${airport.name} airport`);
    await cacheMedia("airport-photo", iata, airport.name, asset?.allowed ? asset : null);
    if (asset?.allowed) foundPhotos++;
    await sleep(350);
  }
  console.log(`  airport photos resolved with verified-free license: ${foundPhotos}`);

  console.log("Resolving airline logos from Wikimedia Commons…");
  for (const [iata, name] of PRIORITY_AIRLINES) {
    const asset = await wikimediaSearch(`${name} logo`);
    await cacheMedia("airline-logo", iata, name, asset?.allowed ? asset : null);
    if (asset?.allowed) foundLogos++;
    await sleep(350);
  }
  console.log(`  airline logos resolved with verified-free license: ${foundLogos}`);

  console.log("Resolving aircraft photos from Wikimedia Commons…");
  for (const [manufacturer, model] of PRIORITY_AIRCRAFT) {
    const asset = await wikimediaSearch(`${model} aircraft`);
    await cacheMedia("aircraft-photo", `${manufacturer}-${model}`.replace(/[^A-Z0-9-]/gi, "-").toUpperCase(), `${manufacturer} ${model}`, asset?.allowed ? asset : null);
    if (asset?.allowed) foundAircraft++;
    await sleep(350);
  }
  console.log(`  aircraft photos resolved with verified-free license: ${foundAircraft}`);
}

await ensureTables();
const onlyMedia = process.argv.includes("--only-media");
if (!onlyMedia) {
  await seedAirports();
  await seedAirlines();
}
await seedMedia();

const stats = await client.query(`SELECT (SELECT COUNT(*) FROM volantis_airport_data) AS airports, (SELECT COUNT(*) FROM volantis_airline_data) AS airlines, (SELECT COUNT(*) FILTER (WHERE found AND media_type='airport-photo') FROM volantis_media_assets) AS photos, (SELECT COUNT(*) FILTER (WHERE found AND media_type='airline-logo') FROM volantis_media_assets) AS logos, (SELECT COUNT(*) FILTER (WHERE found AND media_type='aircraft-photo') FROM volantis_media_assets) AS aircraft_photos`);
console.log("FINAL COUNTS:", stats.rows[0]);
await client.end();
